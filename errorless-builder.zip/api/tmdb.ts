import type { Request, Response } from 'express';

// Vercel Serverless Function Proxy for TMDB API
export default async function handler(req: any, res: any) {
  const { path } = req.query;
  const endpoint = Array.isArray(path) ? path.join('/') : path || '';
  const apiKey = process.env.TMDB_API_KEY || '15d2ea6d0dc1d476efbca3eba2b9bbfb';

  const queryParams = new URLSearchParams(req.query);
  queryParams.delete('path');
  queryParams.set('api_key', apiKey);

  try {
    const tmdbRes = await fetch(`https://api.themoviedb.org/3/${endpoint}?${queryParams.toString()}`);
    const data = await tmdbRes.json();
    res.status(tmdbRes.status).json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to proxy request to TMDB' });
  }
}
