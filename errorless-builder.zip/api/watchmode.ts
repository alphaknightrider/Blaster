// Vercel Serverless Function Proxy for Watchmode API
export default async function handler(req: any, res: any) {
  const { endpoint, ...params } = req.query;
  const apiKey = process.env.WATCHMODE_API_KEY || '';

  if (!apiKey) {
    return res.status(200).json([]);
  }

  const queryParams = new URLSearchParams({
    ...params,
    apiKey,
  });

  try {
    const wmRes = await fetch(`https://api.watchmode.com/v1/${endpoint || 'status'}/?${queryParams.toString()}`);
    const data = await wmRes.json();
    res.status(wmRes.status).json(data);
  } catch (error: any) {
    res.status(500).json({ error: error.message || 'Failed to proxy request to Watchmode' });
  }
}
