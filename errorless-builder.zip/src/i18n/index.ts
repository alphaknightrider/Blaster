import { en } from './en';
import { hi } from './hi';

export type TranslationKey = typeof en;

export const translations = {
  en,
  hi,
};

export function getTranslation(lang: 'en' | 'hi'): TranslationKey {
  return translations[lang] || translations.en;
}
