export type MediaType = 'movie' | 'tv' | 'anime' | 'cartoon' | 'documentary' | 'short';

export type ProviderId =
  | 'tmdb'
  | 'tvmaze'
  | 'anilist'
  | 'kitsu'
  | 'jikan'
  | 'archive'
  | 'vegamovies'
  | 'peertube'
  | 'wikimedia'
  | 'wikidata'
  | 'watchmode'
  | 'youtube'
  | 'openlibrary';

export interface Genre {
  id: number | string;
  name: string;
}

export interface WatchProviderItem {
  providerName: string;
  logoUrl?: string;
  type: 'flatrate' | 'rent' | 'buy' | 'free';
  url: string;
}

export interface DownloadOption {
  format: string;
  quality?: string;
  size?: string;
  url: string;
  license?: string;
  source: string;
}

export interface AvailabilityInfo {
  free?: boolean;
  publicDomain?: boolean;
  streamUrl?: string;
  downloadOptions?: DownloadOption[];
  watchProviders?: WatchProviderItem[];
  officialPage?: string;
}

export interface CastMember {
  id?: number | string;
  name: string;
  character?: string;
  profilePath?: string;
}

export interface CrewMember {
  id?: number | string;
  name: string;
  job: string;
}

export interface VideoItem {
  id: string;
  key: string;
  name: string;
  site: string;
  type: string;
  official: boolean;
}

export interface TVEpisode {
  id: number | string;
  episodeNumber: number;
  seasonNumber: number;
  title: string;
  overview: string;
  stillPath?: string;
  airDate?: string;
  runtime?: number;
  rating?: number;
}

export interface TVSeason {
  id: number | string;
  seasonNumber: number;
  name: string;
  overview?: string;
  posterPath?: string;
  episodeCount?: number;
  episodes?: TVEpisode[];
}

export interface NormalizedTitle {
  id: string; // Qualified ID, e.g. "tmdb:movie:550" or "ia:night_of_the_living_dead_1968"
  rawId: string | number;
  provider: ProviderId;
  mediaType: MediaType;
  title: string;
  originalTitle?: string;
  tagline?: string;
  overview: string;
  poster: string;
  backdrop: string;
  releaseDate: string;
  year?: number;
  genres: Genre[];
  rating: number; // 0-10
  voteCount?: number;
  language: string;
  runtime?: number; // in minutes
  status?: string;
  director?: string;
  cast?: CastMember[];
  crew?: CrewMember[];
  productionCompanies?: string[];
  videos?: VideoItem[];
  trailer?: VideoItem;
  availability?: AvailabilityInfo;
  seasonsCount?: number;
  episodesCount?: number;
  seasons?: TVSeason[];
  similarTitles?: NormalizedTitle[];
  recommendations?: NormalizedTitle[];
  externalIds?: {
    imdbId?: string;
    tmdbId?: number;
    tvmazeId?: number;
    anilistId?: number;
    malId?: number | string;
    kitsuId?: string;
    archiveId?: string;
    peertubeId?: string;
    wikidataId?: string;
    wikipediaUrl?: string;
  };
}

export interface PlaybackProgress {
  id: string; // Qualified title id
  title: string;
  poster: string;
  mediaType: MediaType;
  currentTime: number;
  duration: number;
  percentage: number;
  lastWatched: number; // timestamp
  completed: boolean;
  streamUrl?: string;
  seasonNumber?: number;
  episodeNumber?: number;
}

export interface WatchlistItem {
  id: string;
  title: string;
  poster: string;
  backdrop?: string;
  mediaType: MediaType;
  releaseDate: string;
  rating: number;
  genres: Genre[];
  addedAt: number;
}

export interface HistoryItem {
  id: string;
  title: string;
  poster: string;
  mediaType: MediaType;
  viewedAt: number;
}

export interface AppSettings {
  language: 'en' | 'hi';
  lowBandwidth: boolean;
  autoResume: boolean;
  defaultQuality: 'auto' | '1080p' | '720p' | '480p';
  tmdbApiKey: string;
  watchmodeApiKey: string;
  youtubeApiKey: string;
  contentRegion: string;
  announcementDismissed: boolean;
}

export interface ProviderHealth {
  provider: ProviderId;
  name: string;
  status: 'online' | 'degraded' | 'offline' | 'unconfigured';
  latencyMs: number;
  lastChecked: number;
  requestsCount: number;
  errorCount: number;
  details?: string;
}

export interface LogEntry {
  id: string;
  timestamp: number;
  level: 'info' | 'warn' | 'error';
  provider?: ProviderId;
  message: string;
  context?: string;
}
