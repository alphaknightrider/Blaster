import { AppSettings, HistoryItem, LogEntry, PlaybackProgress, WatchlistItem } from '../types';

const STORAGE_VERSION = 1;
const VERSION_KEY = 'cyrus_storage_version';
const WATCHLIST_KEY = 'cyrus_watchlist';
const HISTORY_KEY = 'cyrus_history';
const PROGRESS_KEY = 'cyrus_progress';
const SETTINGS_KEY = 'cyrus_settings';
const SEARCH_HISTORY_KEY = 'cyrus_search_history';
const LOGS_KEY = 'cyrus_session_logs';

export const DEFAULT_SETTINGS: AppSettings = {
  language: 'en',
  lowBandwidth: false,
  autoResume: true,
  defaultQuality: 'auto',
  tmdbApiKey: '',
  watchmodeApiKey: '',
  youtubeApiKey: '',
  contentRegion: 'US',
  announcementDismissed: false,
};

// Safe localStorage wrapper
export class StorageManager {
  static init(): void {
    try {
      const currentVersion = parseInt(localStorage.getItem(VERSION_KEY) || '0', 10);
      if (currentVersion < STORAGE_VERSION) {
        // Run migration if needed in future
        localStorage.setItem(VERSION_KEY, STORAGE_VERSION.toString());
      }
    } catch (e) {
      console.warn('LocalStorage unavailable or restricted:', e);
    }
  }

  // --- Watchlist ---
  static getWatchlist(): WatchlistItem[] {
    try {
      const data = localStorage.getItem(WATCHLIST_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static toggleWatchlist(item: Omit<WatchlistItem, 'addedAt'>): boolean {
    const list = this.getWatchlist();
    const existingIndex = list.findIndex((i) => i.id === item.id);
    let added = false;
    if (existingIndex >= 0) {
      list.splice(existingIndex, 1);
    } else {
      list.unshift({ ...item, addedAt: Date.now() });
      added = true;
    }
    try {
      localStorage.setItem(WATCHLIST_KEY, JSON.stringify(list));
    } catch (e) {
      console.error('Failed to save watchlist:', e);
    }
    return added;
  }

  static isInWatchlist(id: string): boolean {
    const list = this.getWatchlist();
    return list.some((i) => i.id === id);
  }

  static removeFromWatchlist(id: string): void {
    const list = this.getWatchlist().filter((i) => i.id !== id);
    localStorage.setItem(WATCHLIST_KEY, JSON.stringify(list));
  }

  // --- Playback Progress & Continue Watching ---
  static getContinueWatching(): PlaybackProgress[] {
    try {
      const data = localStorage.getItem(PROGRESS_KEY);
      const list: PlaybackProgress[] = data ? JSON.parse(data) : [];
      // Filter out completed (>95%) or invalid
      return list.sort((a, b) => b.lastWatched - a.lastWatched);
    } catch {
      return [];
    }
  }

  static getProgress(id: string): PlaybackProgress | null {
    const list = this.getContinueWatching();
    return list.find((item) => item.id === id) || null;
  }

  static saveProgress(progress: Omit<PlaybackProgress, 'lastWatched' | 'percentage'>): void {
    if (progress.duration <= 0) return;
    const percentage = Math.min(100, Math.round((progress.currentTime / progress.duration) * 100));
    const completed = percentage >= 95;

    const list = this.getContinueWatching().filter((i) => i.id !== progress.id);
    
    // Only store if progress has at least 5 seconds and not completed, or keep in history
    const item: PlaybackProgress = {
      ...progress,
      percentage,
      completed,
      lastWatched: Date.now(),
    };

    list.unshift(item);
    // Keep max 50 items
    const trimmed = list.slice(0, 50);
    try {
      localStorage.setItem(PROGRESS_KEY, JSON.stringify(trimmed));
    } catch (e) {
      console.error('Failed to save playback progress:', e);
    }
  }

  static removeProgress(id: string): void {
    const list = this.getContinueWatching().filter((i) => i.id !== id);
    localStorage.setItem(PROGRESS_KEY, JSON.stringify(list));
  }

  // --- View History ---
  static getHistory(): HistoryItem[] {
    try {
      const data = localStorage.getItem(HISTORY_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static addHistory(item: Omit<HistoryItem, 'viewedAt'>): void {
    const list = this.getHistory().filter((i) => i.id !== item.id);
    list.unshift({ ...item, viewedAt: Date.now() });
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, 100)));
    } catch (e) {
      console.error('Failed to save history:', e);
    }
  }

  static clearHistory(): void {
    localStorage.removeItem(HISTORY_KEY);
  }

  // --- Search History ---
  static getSearchHistory(): string[] {
    try {
      const data = localStorage.getItem(SEARCH_HISTORY_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static addSearchQuery(query: string): void {
    const trimmed = query.trim();
    if (!trimmed) return;
    const list = this.getSearchHistory().filter((q) => q.toLowerCase() !== trimmed.toLowerCase());
    list.unshift(trimmed);
    localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(list.slice(0, 10)));
  }

  static clearSearchHistory(): void {
    localStorage.removeItem(SEARCH_HISTORY_KEY);
  }

  // --- App Settings ---
  static getSettings(): AppSettings {
    try {
      const data = localStorage.getItem(SETTINGS_KEY);
      if (!data) return DEFAULT_SETTINGS;
      return { ...DEFAULT_SETTINGS, ...JSON.parse(data) };
    } catch {
      return DEFAULT_SETTINGS;
    }
  }

  static updateSettings(partial: Partial<AppSettings>): AppSettings {
    const current = this.getSettings();
    const updated = { ...current, ...partial };
    localStorage.setItem(SETTINGS_KEY, JSON.stringify(updated));
    return updated;
  }

  // --- Logs for Admin Diagnostics ---
  static getLogs(): LogEntry[] {
    try {
      const data = localStorage.getItem(LOGS_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  static addLog(level: 'info' | 'warn' | 'error', message: string, provider?: any, context?: string): void {
    const logs = this.getLogs();
    logs.unshift({
      id: Math.random().toString(36).substring(2, 9),
      timestamp: Date.now(),
      level,
      message,
      provider,
      context,
    });
    try {
      localStorage.setItem(LOGS_KEY, JSON.stringify(logs.slice(0, 100)));
    } catch {}
  }

  static clearLogs(): void {
    localStorage.removeItem(LOGS_KEY);
  }

  // --- Backup, Export & Recovery ---
  static exportAllData(): string {
    const data = {
      version: STORAGE_VERSION,
      timestamp: Date.now(),
      watchlist: this.getWatchlist(),
      history: this.getHistory(),
      progress: this.getContinueWatching(),
      settings: this.getSettings(),
      searchHistory: this.getSearchHistory(),
    };
    return JSON.stringify(data, null, 2);
  }

  static importData(jsonString: string): boolean {
    try {
      const data = JSON.parse(jsonString);
      if (data.watchlist) localStorage.setItem(WATCHLIST_KEY, JSON.stringify(data.watchlist));
      if (data.history) localStorage.setItem(HISTORY_KEY, JSON.stringify(data.history));
      if (data.progress) localStorage.setItem(PROGRESS_KEY, JSON.stringify(data.progress));
      if (data.settings) localStorage.setItem(SETTINGS_KEY, JSON.stringify(data.settings));
      if (data.searchHistory) localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(data.searchHistory));
      return true;
    } catch (e) {
      console.error('Import failed:', e);
      return false;
    }
  }

  static clearAllData(): void {
    localStorage.removeItem(WATCHLIST_KEY);
    localStorage.removeItem(HISTORY_KEY);
    localStorage.removeItem(PROGRESS_KEY);
    localStorage.removeItem(SETTINGS_KEY);
    localStorage.removeItem(SEARCH_HISTORY_KEY);
    localStorage.removeItem(LOGS_KEY);
  }
}
