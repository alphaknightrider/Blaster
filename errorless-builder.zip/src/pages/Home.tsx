import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { VegaMoviesProvider } from '../services/providers/vegamovies';
import { ShortDramaService } from '../services/providers/shortDrama';
import { CURATED_PUBLIC_DOMAIN_CINEMA } from '../services/providers/archive';
import { TitleNormalizer } from '../services/normalizer';
import { NormalizedTitle } from '../types';
import { HeroBanner } from '../components/movie/HeroBanner';
import { MovieRow } from '../components/movie/MovieRow';
import { ContinueWatchingRow } from '../components/movie/ContinueWatchingRow';
import { useApp } from '../context/AppContext';
import { Flame } from 'lucide-react';
import { Link } from 'react-router-dom';

export const Home: React.FC = () => {
  const { t } = useApp();

  const [heroTitle, setHeroTitle] = useState<NormalizedTitle | undefined>(() =>
    TitleNormalizer.normalizeArchive(CURATED_PUBLIC_DOMAIN_CINEMA[0])
  );
  const [trendingMovies, setTrendingMovies] = useState<NormalizedTitle[]>([]);
  const [vegaMovies, setVegaMovies] = useState<NormalizedTitle[]>([]);
  const [animeCatalog, setAnimeCatalog] = useState<NormalizedTitle[]>([]);
  const [classicCartoons, setClassicCartoons] = useState<NormalizedTitle[]>([]);
  const [popularMovies, setPopularMovies] = useState<NormalizedTitle[]>([]);
  const [trendingTv, setTrendingTv] = useState<NormalizedTitle[]>([]);
  const [topRated, setTopRated] = useState<NormalizedTitle[]>([]);
  const [publicDomain, setPublicDomain] = useState<NormalizedTitle[]>([]);
  const [upcoming, setUpcoming] = useState<NormalizedTitle[]>([]);

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadData = async () => {
    setLoading(true);
    setError(null);
    try {
      const [
        trendingM,
        vegaRes,
        animeRes,
        tvRes,
        cartoonRes,
        popularM,
        topR,
        upc,
        pubDomain,
      ] = await Promise.allSettled([
        ApiClient.getTrending('movie'),
        VegaMoviesProvider.getBollywoodReleases(1),
        ApiClient.getAnimeCatalog(1),
        ApiClient.getTrending('tv'),
        ApiClient.getClassicCartoons(),
        ApiClient.getPopular('movie', 2), // Page 2 ensures distinct from trending
        ApiClient.getTopRated('movie', 2), // Page 2 ensures distinct
        ApiClient.getUpcoming(1),
        ApiClient.getPublicDomainCinema(),
      ]);

      // Global Deduplication Set across the entire homepage
      const seenTitles = new Set<string>();
      const dedupe = (items: NormalizedTitle[]): NormalizedTitle[] => {
        return items.filter((item) => {
          const cleanName = (item.title || '').toLowerCase().trim();
          if (!cleanName || seenTitles.has(cleanName) || seenTitles.has(item.id)) {
            return false;
          }
          seenTitles.add(cleanName);
          seenTitles.add(item.id);
          return true;
        });
      };

      const rawTrending = trendingM.status === 'fulfilled' ? trendingM.value : [];
      const cleanTrending = dedupe(rawTrending);
      setTrendingMovies(cleanTrending);

      const rawVega = vegaRes.status === 'fulfilled' ? vegaRes.value : [];
      setVegaMovies(dedupe(rawVega));

      const rawAnime = animeRes.status === 'fulfilled' ? animeRes.value : [];
      setAnimeCatalog(dedupe(rawAnime));

      const rawTv = tvRes.status === 'fulfilled' ? tvRes.value : [];
      setTrendingTv(dedupe(rawTv));

      const rawCartoons = cartoonRes.status === 'fulfilled' ? cartoonRes.value : [];
      setClassicCartoons(dedupe(rawCartoons));

      const rawPopular = popularM.status === 'fulfilled' ? popularM.value : [];
      setPopularMovies(dedupe(rawPopular));

      const rawTopRated = topR.status === 'fulfilled' ? topR.value : [];
      setTopRated(dedupe(rawTopRated));

      const rawUpcoming = upc.status === 'fulfilled' ? upc.value : [];
      setUpcoming(dedupe(rawUpcoming));

      const rawArchive = pubDomain.status === 'fulfilled' ? pubDomain.value : [];
      setPublicDomain(dedupe(rawArchive));

      // Select featured hero premiere
      if (cleanTrending.length > 0) {
        setHeroTitle(cleanTrending[0]);
      } else if (rawPopular.length > 0) {
        setHeroTitle(rawPopular[0]);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load content feed');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const shortDramas = ShortDramaService.getAll();

  return (
    <div className="min-h-screen pb-12">
      {/* Featured Hero Premiere */}
      <HeroBanner title={heroTitle} />

      {/* Continue Watching for current browser session */}
      <ContinueWatchingRow />

      {/* Rows with ZERO repetitions */}
      <div className="space-y-6">
        {/* Row 1: Trending Movies */}
        <MovieRow
          title={t.home.trendingMovies}
          items={trendingMovies}
          loading={loading}
          error={error}
          onRetry={loadData}
          viewAllLink="/trending"
        />

        {/* Row 2: Short Drama & Reels Portal (Indian MicroTV & Desi Dramas) */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-rose-500 uppercase tracking-wider">
                <Flame className="w-3.5 h-3.5 fill-current" />
                <span>New.MicroTV.st · Indian Desi & Hindi Micro-Dramas</span>
              </div>
              <h3 className="text-xl sm:text-2xl font-extrabold text-white font-['Manrope']">
                🔥 MicroTV Indian Short Dramas & Reels (देसी नाटक)
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Binge-watch 1-minute viral Indian episodes: Chhupa Hua Crorepati Jamai, 18+ Desi Romance, Bahu Ka Badla, and Thakur Haveli sagas.
              </p>
            </div>
            <Link
              to="/reels"
              className="text-xs font-bold text-rose-400 hover:text-rose-300 flex items-center gap-1"
            >
              <span>View All Indian Reels</span>
              <span>→</span>
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 pt-1">
            {shortDramas.slice(0, 6).map((drama) => (
              <Link
                key={drama.id}
                to="/reels"
                className="group relative rounded-xl overflow-hidden bg-[#181B27] border border-[#292D3A] hover:border-rose-500 transition-all duration-300 aspect-[9/13]"
              >
                <img
                  src={drama.cover}
                  alt={drama.title}
                  onError={(e) => {
                    (e.currentTarget as HTMLImageElement).src =
                      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80';
                  }}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {drama.isIndian && (
                  <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-emerald-950/80 border border-emerald-600 text-emerald-300 text-[8px] font-bold">
                    🇮🇳 HINDI
                  </span>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent p-2.5 flex flex-col justify-end">
                  <span className="text-[10px] text-rose-400 font-bold line-clamp-1">
                    {drama.categoryLabel}
                  </span>
                  <h4 className="text-xs font-extrabold text-white line-clamp-1 group-hover:text-rose-300">
                    {drama.hindiTitle || drama.title}
                  </h4>
                  <span className="text-[9px] text-slate-400 mt-0.5">
                    {drama.totalEpisodes} भाग · {drama.views}
                  </span>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Row 3: VegaMovies Dual Audio & Bollywood */}
        <MovieRow
          title="⚡ VegaMovies 100K+ Dual Audio & Bollywood Releases"
          subtitle="Direct fast streaming & multi-cloud mirrors (4K, 1080p, 720p, 480p)"
          items={vegaMovies}
          loading={loading}
          viewAllLink="/vegamovies"
        />

        {/* Row 4: Trending Anime */}
        {animeCatalog.length > 0 && (
          <MovieRow
            title="🌸 Anime & Japanese Animation (AniList & Kitsu)"
            subtitle="Trending shonen, seinen, and seasonal anime releases"
            items={animeCatalog}
            loading={loading}
            viewAllLink="/anime"
          />
        )}

        {/* Row 5: TV Series */}
        <MovieRow
          title={t.home.trendingTv}
          subtitle="Serialized broadcast dramas, comedies, and network releases"
          items={trendingTv}
          loading={loading}
          viewAllLink="/tv"
        />

        {/* Row 6: Classic Cartoons */}
        {classicCartoons.length > 0 && (
          <MovieRow
            title="🌟 Classic Golden-Age Cartoons"
            subtitle="Superman (1941), Popeye, Betty Boop, Steamboat Willie — 100% Free"
            items={classicCartoons}
            loading={loading}
            viewAllLink="/cartoons"
          />
        )}

        {/* Row 7: Popular Blockbusters */}
        {popularMovies.length > 0 && (
          <MovieRow
            title={t.home.popularMovies}
            subtitle="Audience favorite feature films across global cinema"
            items={popularMovies}
            loading={loading}
            viewAllLink="/popular"
          />
        )}

        {/* Row 8: Top Rated Masterpieces */}
        {topRated.length > 0 && (
          <MovieRow
            title={t.home.topRated}
            subtitle="Critically acclaimed cinema rated 8.0+ by global audiences"
            items={topRated}
            loading={loading}
            viewAllLink="/top-rated"
          />
        )}

        {/* Row 9: Upcoming Theatrical Premieres */}
        {upcoming.length > 0 && (
          <MovieRow
            title={t.home.upcoming}
            subtitle="Teasers, trailers, and upcoming release dates"
            items={upcoming}
            loading={loading}
            viewAllLink="/upcoming"
          />
        )}

        {/* Row 10: Public Domain Masterpieces */}
        {publicDomain.length > 0 && (
          <MovieRow
            title={t.home.publicDomainRows}
            subtitle="Direct streaming & downloads from Internet Archive"
            items={publicDomain}
            loading={loading}
            viewAllLink="/discover?provider=archive"
          />
        )}
      </div>
    </div>
  );
};
