import React from 'react';
import { DatabaseZap, ShieldCheck, Film, Globe } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      <div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight">
          About Cyrus Movies
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Your World of Cinema — High-Performance Zero-Database Discovery & Streaming Platform.
        </p>
      </div>

      <div className="space-y-6 text-sm text-slate-300 leading-relaxed">
        <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2 font-['Manrope']">
            <DatabaseZap className="w-5 h-5 text-[#8B5CF6]" />
            The Zero-Database Philosophy
          </h2>
          <p>
            Cyrus Movies is engineered from first principles without a centralized backend database. Instead of requiring users to register cloud accounts, submit email addresses, or store viewing behaviors on remote servers, all personal state—including Watchlists, Viewing History, and Resume Progress—is kept 100% locally in your browser’s isolated storage sandbox.
          </p>
          <p>
            This architecture guarantees zero tracking, near-zero server overhead, instant load times, and true client data sovereignty.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2 font-['Manrope']">
            <Globe className="w-5 h-5 text-[#38BDF8]" />
            Multi-API Federation
          </h2>
          <p>
            Catalog discovery is powered dynamically through a multi-provider federation:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-xs text-slate-400">
            <li><strong>The Movie Database (TMDB):</strong> Global metadata, high-resolution theatrical artwork, cast credits, and trailers.</li>
            <li><strong>Internet Archive:</strong> Authorized public-domain feature films, silent era masterpieces, and direct open-access MP4 video streams.</li>
            <li><strong>Watchmode:</strong> Real-time regional streaming availability across licensed providers like Netflix, Apple TV, Prime Video, and Disney+.</li>
            <li><strong>Wikidata:</strong> Semantic facts, director lineages, and open knowledge validation.</li>
          </ul>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3">
          <h2 className="text-lg font-bold text-white flex items-center gap-2 font-['Manrope']">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            Copyright & Authorized Streaming Policy
          </h2>
          <p>
            Cyrus Movies strictly respects global intellectual property and digital rights. Direct playback and downloads are provided exclusively for materials in the public domain or under open cultural licenses. For commercial and studio-copyrighted films, Cyrus Movies provides verified links to authorized streaming providers rather than hosting unauthorized media.
          </p>
        </div>
      </div>
    </div>
  );
};
