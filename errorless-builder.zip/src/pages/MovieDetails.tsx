import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { useApp } from '../context/AppContext';
import { StorageManager } from '../storage';
import { MovieCard } from '../components/movie/MovieCard';
import { DownloadCenter } from '../components/player/DownloadCenter';
import { VegaDownloadWidget } from '../components/player/VegaDownloadWidget';
import {
  Play,
  Bookmark,
  Share2,
  Star,
  Clock,
  Calendar,
  Film,
  User,
  ExternalLink,
  ChevronLeft,
  Check,
} from 'lucide-react';
import { DEFAULT_BACKDROP, DEFAULT_POSTER } from '../services/normalizer';
import { AnimeUniverseService } from '../services/providers/animeUniverse';

export const MovieDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, isInWatchlist, toggleWatchlist } = useApp();

  const [title, setTitle] = useState<NormalizedTitle | null>(null);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!id) return;
    const fetchTitle = async () => {
      setLoading(true);
      try {
        const decodedId = decodeURIComponent(id);
        const data = await ApiClient.getTitleDetails(decodedId);
        setTitle(data);
        if (data) {
          // Record view history locally
          StorageManager.addHistory({
            id: data.id,
            title: data.title,
            poster: data.poster,
            mediaType: data.mediaType,
          });
        }
      } catch (err) {
        setTitle(null);
      } finally {
        setLoading(false);
      }
    };
    fetchTitle();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen pt-32 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-96 rounded-2xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
      </div>
    );
  }

  if (!title) {
    return (
      <div className="min-h-screen pt-36 pb-16 max-w-xl mx-auto px-4 text-center">
        <Film className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <h2 className="text-xl font-bold text-white font-['Manrope']">Title Unavailable</h2>
        <p className="text-xs text-slate-400 mt-2 mb-6">
          The requested movie metadata could not be retrieved from active providers.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Return to Homepage</span>
        </Link>
      </div>
    );
  }

  const inWatchlist = isInWatchlist(title.id);
  const watchPath = `/watch/${title.mediaType}/${encodeURIComponent(title.id)}`;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: title.title,
        text: `Watch ${title.title} on Cyrus Movies`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="min-h-screen pb-20">
      {/* Backdrop Header */}
      <div className="relative w-full h-[50vh] min-h-[420px] max-h-[600px] overflow-hidden">
        <img
          src={title.backdrop || title.poster || DEFAULT_BACKDROP}
          alt={title.title}
          onError={(e) => {
            e.currentTarget.src = title.poster || DEFAULT_BACKDROP;
          }}
          className="w-full h-full object-cover filter brightness-[0.6] contrast-[1.05]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-[#090A0F]/70 to-transparent" />
      </div>

      {/* Main Content Area */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-44 relative z-10 space-y-12">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Poster Column */}
          <div className="w-48 sm:w-60 md:w-72 shrink-0 rounded-2xl overflow-hidden bg-[#181B27] border border-[#292D3A] shadow-2xl mx-auto md:mx-0">
            <img
              src={title.poster || DEFAULT_POSTER}
              alt={title.title}
              onError={(e) => {
                e.currentTarget.src = DEFAULT_POSTER;
              }}
              className="w-full aspect-[2/3] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Details Column */}
          <div className="flex-1 space-y-5">
            {/* Top Metadata Line (Zero-Pill Discipline) */}
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-slate-400 font-medium">
              <span className="text-[#38BDF8] uppercase tracking-wider font-semibold">
                Feature Film
              </span>
              {title.year && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{title.year}</span>
                  </span>
                </>
              )}
              {title.runtime && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span>{title.runtime} {t.common.minutes}</span>
                  </span>
                </>
              )}
              {title.rating > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1 text-amber-300 font-semibold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" />
                    <span className="tabular-nums">{title.rating.toFixed(1)}</span>
                    {title.voteCount && <span className="text-slate-500 font-normal">({title.voteCount.toLocaleString()} votes)</span>}
                  </span>
                </>
              )}
            </div>

            {/* Title & Tagline */}
            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight leading-tight">
                {title.title}
              </h1>
              {title.tagline && (
                <p className="text-slate-400 text-sm sm:text-base italic mt-1">&ldquo;{title.tagline}&rdquo;</p>
              )}
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => navigate(watchPath)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#8B5CF6] hover:bg-[#7c4def] text-white font-semibold text-sm transition-all shadow-lg shadow-[#8B5CF6]/20 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>{t.common.watchNow}</span>
              </button>

              <button
                onClick={() =>
                  toggleWatchlist({
                    id: title.id,
                    title: title.title,
                    poster: title.poster,
                    backdrop: title.backdrop,
                    mediaType: title.mediaType,
                    releaseDate: title.releaseDate,
                    rating: title.rating,
                    genres: title.genres,
                  })
                }
                className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium transition-all ${
                  inWatchlist
                    ? 'bg-[#8B5CF6] border-[#8B5CF6] text-white'
                    : 'bg-[#181B27] border-[#292D3A] text-slate-300 hover:text-white'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${inWatchlist ? 'fill-current' : ''}`} />
                <span>{inWatchlist ? t.common.inWatchlist : t.common.addToWatchlist}</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-sm transition-colors"
                title="Share this title"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span>{copied ? 'Copied' : t.common.share}</span>
              </button>
            </div>

            {/* Overview */}
            <div className="pt-2">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                {t.common.overview}
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-3xl">
                {title.overview}
              </p>
            </div>

            {/* Director & Details Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-3 border-t border-[#292D3A]/60 text-xs">
              {title.director && (
                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">
                    {t.common.director}
                  </span>
                  <span className="text-white font-medium text-sm mt-0.5 block">{title.director}</span>
                </div>
              )}
              <div>
                <span className="text-slate-500 block uppercase tracking-wider text-[10px]">
                  Original Language
                </span>
                <span className="text-white font-medium text-sm mt-0.5 block">{title.language}</span>
              </div>
              {title.genres && title.genres.length > 0 && (
                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">
                    {t.common.genres}
                  </span>
                  <span className="text-white font-medium text-sm mt-0.5 block">
                    {title.genres.map((g) => g.name).join(', ')}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Streaming & Authorized Viewing Options */}
        {title.availability?.watchProviders && title.availability.watchProviders.length > 0 && (
          <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
            <h3 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
              <ExternalLink className="w-4 h-4 text-[#8B5CF6]" />
              {t.common.streamingOptions}
            </h3>
            <div className="flex flex-wrap gap-3">
              {title.availability.watchProviders.map((wp, idx) => (
                <a
                  key={idx}
                  href={wp.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 px-3 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] text-xs font-semibold text-white transition-colors"
                >
                  {wp.logoUrl && (
                    <img src={wp.logoUrl} alt={wp.providerName} className="w-5 h-5 rounded object-cover" />
                  )}
                  <span>{wp.providerName}</span>
                  <span className="text-[10px] text-slate-400 capitalize">({wp.type})</span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* External Anime Databases & Cross-References */}
        {(title.mediaType === 'anime' ||
          title.genres?.some((g) => g.name.toLowerCase() === 'animation') ||
          title.language?.toLowerCase() === 'ja') && (
          <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
                  <Film className="w-4 h-4 text-[#8B5CF6]" />
                  <span>Anime Databases & Metadata Cross-References</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verified external entries across global anime intelligence networks.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
              {AnimeUniverseService.getExternalDatabaseLinks(
                title.title,
                title.externalIds?.anilistId,
                title.externalIds?.malId
              ).map((db) => (
                <a
                  key={db.name}
                  href={db.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] transition-all flex flex-col justify-between group hover:shadow-md"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#11131B] text-[#A78BFA] border border-[#292D3A]">
                      {db.badge}
                    </span>
                    <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-xs font-bold text-slate-200 group-hover:text-white transition-colors">
                    {db.name}
                  </span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Cast Members */}
        {title.cast && title.cast.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white font-['Manrope'] flex items-center gap-2">
              <User className="w-5 h-5 text-[#8B5CF6]" />
              {t.common.cast}
            </h2>
            <div className="flex gap-4 overflow-x-auto no-scrollbar py-1">
              {title.cast.map((actor, idx) => (
                <div key={idx} className="w-28 shrink-0 text-center space-y-1.5">
                  <div className="w-24 h-24 mx-auto rounded-full overflow-hidden bg-[#181B27] border border-[#292D3A]">
                    {actor.profilePath ? (
                      <img src={actor.profilePath} alt={actor.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-500 font-bold text-lg">
                        {actor.name.charAt(0)}
                      </div>
                    )}
                  </div>
                  <p className="text-xs font-semibold text-white truncate">{actor.name}</p>
                  <p className="text-[11px] text-slate-400 truncate">{actor.character}</p>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* VegaMovies Fast Download & Cloud Mirrors */}
        <VegaDownloadWidget title={title} />

        {/* Download Center for Eligible Content */}
        <DownloadCenter title={title} />

        {/* Similar Titles */}
        {title.similarTitles && title.similarTitles.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white font-['Manrope']">{t.common.similarTitles}</h2>
            <div className="flex gap-4 overflow-x-auto no-scrollbar py-1">
              {title.similarTitles.map((sim) => (
                <div key={sim.id} className="w-[150px] sm:w-[170px] shrink-0">
                  <MovieCard title={sim} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
