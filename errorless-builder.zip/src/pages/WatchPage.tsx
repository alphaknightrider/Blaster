import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { CinematicPlayer } from '../components/player/CinematicPlayer';
import { DownloadCenter } from '../components/player/DownloadCenter';
import { VegaDownloadWidget } from '../components/player/VegaDownloadWidget';
import { MovieCard } from '../components/movie/MovieCard';
import { useApp } from '../context/AppContext';
import { ChevronLeft, ShieldCheck, Film, ExternalLink } from 'lucide-react';

export const WatchPage: React.FC = () => {
  const { type, id } = useParams<{ type: string; id: string }>();
  const { t } = useApp();

  const [title, setTitle] = useState<NormalizedTitle | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!id) return;
    let cancelled = false;

    const fetchTitle = async () => {
      setLoading(true);
      try {
        const decodedId = decodeURIComponent(id);
        let data = await ApiClient.getTitleDetails(decodedId);

        if (!data) {
          // Fallback with explicit tmdb prefix
          const clean = decodedId.replace(/^[a-z]+:[a-z]+:/i, '').replace(/^[a-z]+:/i, '');
          const fallbackType = (type as 'movie' | 'tv') || 'movie';
          data = await ApiClient.getTitleDetails(`tmdb:${fallbackType}:${clean}`);
        }

        if (!data && !cancelled) {
          // Universal streamable title object so player can still play online
          const clean = decodedId.replace(/^[a-z]+:[a-z]+:/i, '').replace(/^[a-z]+:/i, '');
          data = {
            id: decodedId,
            rawId: clean,
            provider: 'tmdb',
            mediaType: (type as any) || 'movie',
            title: `Feature Presentation (${clean})`,
            overview: 'Streaming online with multi-server playback.',
            poster: '/assets/images/cyrus_brand_logo_1790781674754.jpg',
            backdrop: '/assets/images/cyrus_hero_backdrop_1790781652435.jpg',
            releaseDate: '2025',
            year: 2025,
            rating: 8.5,
            language: 'EN / DUAL AUDIO',
            genres: [{ id: 'cinema', name: 'Cinema' }],
          };
        }

        if (!cancelled) {
          setTitle(data);
        }
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchTitle();
    window.scrollTo({ top: 0, behavior: 'smooth' });

    return () => {
      cancelled = true;
    };
  }, [id, type]);

  if (loading) {
    return (
      <div className="min-h-screen pt-28 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="aspect-video w-full rounded-2xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
      </div>
    );
  }

  if (!title) {
    return (
      <div className="min-h-screen pt-36 pb-16 max-w-xl mx-auto px-4 text-center">
        <Film className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <h2 className="text-xl font-bold text-white font-['Manrope']">Playback Source Not Found</h2>
        <p className="text-xs text-slate-400 mt-2 mb-6">
          The requested title is not currently available for streaming.
        </p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Return Home</span>
        </Link>
      </div>
    );
  }

  const detailPath = title.mediaType === 'tv' ? `/tv/${encodeURIComponent(title.id)}` : `/movie/${encodeURIComponent(title.id)}`;

  return (
    <div className="min-h-screen pt-24 pb-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Navigation Breadcrumb */}
        <div className="flex items-center justify-between">
          <Link
            to={detailPath}
            className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-400 hover:text-white transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>{t.player.backToDetails}</span>
          </Link>

          {title.availability?.publicDomain && (
            <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 bg-emerald-950/70 border border-emerald-800/60 px-2.5 py-1 rounded-lg">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Public Domain Film</span>
            </div>
          )}
        </div>

        {/* Video Player Box */}
        <CinematicPlayer title={title} />

        {/* Title & Metadata Box */}
        <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white font-['Manrope'] tracking-tight">
              {title.title}
            </h1>
            <div className="flex items-center gap-2 text-xs text-slate-400">
              {title.year && <span>{title.year}</span>}
              {title.runtime && (
                <>
                  <span aria-hidden="true">·</span>
                  <span>{title.runtime} {t.common.minutes}</span>
                </>
              )}
              {title.rating > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="text-amber-300 font-semibold tabular-nums">{title.rating.toFixed(1)} ★</span>
                </>
              )}
            </div>
          </div>

          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-4xl">
            {title.overview}
          </p>

          {title.availability?.publicDomain && (
            <div className="pt-2 text-xs text-slate-400 border-t border-[#292D3A]/60">
              <p>
                <strong>Source Notice:</strong> {t.player.sourceNotice}
              </p>
            </div>
          )}
        </div>

        {/* Official streaming options if present */}
        {title.availability?.watchProviders && title.availability.watchProviders.length > 0 && (
          <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2 font-['Manrope']">
              <ExternalLink className="w-4 h-4 text-[#8B5CF6]" />
              Authorized Commercial Streaming Providers
            </h3>
            <div className="flex flex-wrap gap-2.5">
              {title.availability.watchProviders.map((p, i) => (
                <a
                  key={i}
                  href={p.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3.5 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] text-xs font-semibold text-white transition-colors"
                >
                  Watch on {p.providerName}
                </a>
              ))}
            </div>
          </div>
        )}

        {/* VegaMovies Instant Download & Cloud Mirrors */}
        <VegaDownloadWidget title={title} />

        {/* Download Center */}
        <DownloadCenter title={title} />

        {/* Similar Titles */}
        {title.similarTitles && title.similarTitles.length > 0 && (
          <div className="space-y-4 pt-6">
            <h2 className="text-xl font-bold text-white font-['Manrope']">{t.common.similarTitles}</h2>
            <div className="flex gap-4 overflow-x-auto no-scrollbar py-1">
              {title.similarTitles.map((sim) => (
                <div key={sim.id} className="w-[150px] sm:w-[170px] shrink-0">
                  <MovieCard title={sim} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
