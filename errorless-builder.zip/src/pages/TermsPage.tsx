import React from 'react';
import { FileText, ShieldAlert } from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-6">
      <div>
        <h1 className="text-3xl font-extrabold text-white font-['Manrope'] tracking-tight">
          Terms of Service & Licensing
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Open culture federation, public domain verification, and intellectual property terms.
        </p>
      </div>

      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4 text-sm text-slate-300 leading-relaxed">
        <h2 className="text-base font-bold text-white font-['Manrope']">1. Permitted Usage</h2>
        <p>
          Cyrus Movies is an educational and discovery platform for cataloging global cinematography and streaming public-domain media. Use of the service is subject to compliance with local copyright regulations.
        </p>

        <h2 className="text-base font-bold text-white font-['Manrope']">2. Public Domain & Open Media</h2>
        <p>
          Public-domain films supplied via Internet Archive are believed to be free of copyright restrictions in the United States and jurisdictions observing the rule of the shorter term. Users outside these jurisdictions are responsible for verifying local legal status prior to downloading or distributing media.
        </p>

        <h2 className="text-base font-bold text-white font-['Manrope']">3. API Attribution</h2>
        <p>
          Film and television metadata, posters, and cast descriptions are delivered courtesy of The Movie Database (TMDB) in accordance with the TMDB API terms of service. Cyrus Movies does not claim ownership of studio copyrighted imagery or trade names.
        </p>
      </div>
    </div>
  );
};
