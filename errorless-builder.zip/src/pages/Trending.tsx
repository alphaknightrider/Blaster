import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Flame } from 'lucide-react';

export const Trending: React.FC = () => {
  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [filter, setFilter] = useState<'movie' | 'tv'>('movie');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await ApiClient.getTrending(filter);
        setItems(res);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [filter]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Flame className="w-8 h-8 text-amber-500" />
            Trending Entertainment
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Real-time viral sensations and audience surges across global streaming and box offices.
          </p>
        </div>

        <div className="flex items-center gap-1 p-1 bg-[#181B27] rounded-xl border border-[#292D3A] self-start sm:self-auto">
          <button
            onClick={() => setFilter('movie')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filter === 'movie' ? 'bg-[#8B5CF6] text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            Movies
          </button>
          <button
            onClick={() => setFilter('tv')}
            className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
              filter === 'tv' ? 'bg-[#8B5CF6] text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            TV Series
          </button>
        </div>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      )}
    </div>
  );
};
