import React, { useState, useRef, useEffect, memo } from 'react';
import {
  ShortDramaService,
  ShortDrama,
  ShortDramaEpisode,
} from '../services/providers/shortDrama';
import {
  Play,
  Pause,
  SkipForward,
  SkipBack,
  Volume2,
  VolumeX,
  Maximize2,
  Layers,
  Sparkles,
  Flame,
  Star,
  Eye,
  Check,
  Share2,
  Search,
  Heart,
  ChevronRight,
  ChevronLeft,
  Tv,
  Globe,
  Gauge,
  Lock,
  Unlock,
  Film,
} from 'lucide-react';

const ShortDramaCardItem: React.FC<{
  drama: ShortDrama;
  isActive: boolean;
  onSelect: (drama: ShortDrama) => void;
}> = ({ drama, isActive, onSelect }) => {
  const [attempt, setAttempt] = useState(0);

  const fallbackList = [
    drama.cover,
    `https://wsrv.nl/?url=${encodeURIComponent(drama.cover)}&w=600&q=80`,
    'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80',
    'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
  ];

  const currentPoster = attempt < fallbackList.length ? fallbackList[attempt] : null;

  return (
    <div
      onClick={() => onSelect(drama)}
      className={`group cursor-pointer rounded-2xl overflow-hidden bg-[#181B27] border transition-all duration-300 flex flex-col ${
        isActive
          ? 'border-rose-500 shadow-lg shadow-rose-500/20 scale-[1.02]'
          : 'border-[#292D3A] hover:border-slate-500'
      }`}
    >
      <div className="relative aspect-[9/14] w-full overflow-hidden bg-[#0d0f18] flex items-center justify-center">
        {currentPoster ? (
          <img
            src={currentPoster}
            alt={drama.title}
            referrerPolicy="no-referrer"
            onError={() => setAttempt((p) => p + 1)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-3 text-center bg-gradient-to-br from-rose-950/60 via-[#181B27] to-black border border-rose-900/30">
            <Film className="w-8 h-8 text-rose-500 mb-2 opacity-70" />
            <h4 className="text-xs font-bold text-white line-clamp-2">
              {drama.hindiTitle || drama.title}
            </h4>
            <span className="text-[10px] text-rose-400 mt-1">{drama.totalEpisodes} भाग</span>
          </div>
        )}

        {drama.badge && (
          <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-rose-600/90 text-white text-[10px] font-bold backdrop-blur-md shadow-md">
            {drama.badge}
          </span>
        )}

        {drama.isIndian && (
          <span className="absolute top-2 right-2 px-1.5 py-0.5 rounded bg-emerald-950/90 border border-emerald-600 text-emerald-300 text-[9px] font-bold shadow-md">
            🇮🇳 HINDI
          </span>
        )}

        <div className="absolute bottom-2 right-2 px-1.5 py-0.5 rounded bg-black/75 backdrop-blur-md text-amber-300 text-[10px] font-bold flex items-center gap-1 shadow-md">
          <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
          <span>{drama.rating}</span>
        </div>
      </div>

      <div className="p-3 flex-1 flex flex-col justify-between">
        <div>
          <h4 className="font-bold text-white text-xs line-clamp-1 group-hover:text-rose-400 transition-colors">
            {drama.hindiTitle || drama.title}
          </h4>
          <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
            {drama.categoryLabel}
          </p>
        </div>
        <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-[#292D3A]/60 mt-2">
          <span>{drama.totalEpisodes} भाग</span>
          <span>{drama.views}</span>
        </div>
      </div>
    </div>
  );
};

// Isolated Hero Banner Showcase Carousel so its auto-timer NEVER re-renders the video player
const OfficialDramaHeroBannerShowcase = memo(({
  banners,
  onSelectDrama,
  onOpenEpisodes,
}: {
  banners: ShortDrama[];
  onSelectDrama: (drama: ShortDrama) => void;
  onOpenEpisodes: (drama: ShortDrama) => void;
}) => {
  const [index, setIndex] = useState(0);
  const [imgAttempt, setImgAttempt] = useState(0);

  const active = banners[index] || banners[0];

  useEffect(() => {
    setImgAttempt(0);
  }, [index]);

  // Auto-cycle official banners every 8 seconds
  useEffect(() => {
    if (!banners || banners.length === 0) return;
    const timer = setInterval(() => {
      setIndex((prev) => (prev + 1) % banners.length);
    }, 8000);
    return () => clearInterval(timer);
  }, [banners.length]);

  if (!active) return null;

  const rawBanner = active.banner || active.cover;
  const bannerSrc =
    imgAttempt === 0
      ? rawBanner
      : imgAttempt === 1
      ? `https://wsrv.nl/?url=${encodeURIComponent(rawBanner)}&q=80`
      : null;

  return (
    <div className="relative rounded-3xl overflow-hidden bg-[#11131B] border border-rose-900/40 shadow-2xl">
      {/* Wide Official Landscape Banner */}
      <div className="relative w-full aspect-[21/9] sm:aspect-[24/9] md:aspect-[28/9] min-h-[280px] sm:min-h-[340px] overflow-hidden bg-gradient-to-r from-rose-950 via-[#181B27] to-[#090A0F]">
        {bannerSrc ? (
          <img
            key={bannerSrc}
            src={bannerSrc}
            alt={active.title}
            referrerPolicy="no-referrer"
            onError={() => setImgAttempt((p) => p + 1)}
            className="w-full h-full object-cover object-center transform scale-105 transition-all duration-700"
          />
        ) : (
          <div className="w-full h-full flex flex-col justify-end p-8 bg-gradient-to-tr from-rose-950/80 via-[#181B27] to-black">
            <Sparkles className="w-12 h-12 text-rose-500/40 mb-4" />
          </div>
        )}

        {/* Cinematic Shadow Scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-[#090A0F]/65 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#090A0F] via-[#090A0F]/80 to-transparent" />

        {/* Banner Content Overlay */}
        <div className="absolute inset-0 p-5 sm:p-8 flex flex-col justify-end max-w-3xl space-y-2.5 z-10">
          <div className="flex flex-wrap items-center gap-2">
            <span className="px-2.5 py-1 rounded-lg bg-rose-600 text-white font-extrabold text-[10px] tracking-wider uppercase shadow-md flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>OFFICIAL MICROTV BANNER</span>
            </span>
            <span className="px-2 py-0.5 rounded-lg bg-amber-500/20 border border-amber-500/40 text-amber-300 font-bold text-[10px]">
              {active.badge || '🔥 #1 Trending'}
            </span>
            {active.isIndian && (
              <span className="px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-600 text-emerald-300 font-bold text-[10px]">
                🇮🇳 Hindi Dubbed 5.1
              </span>
            )}
            <span className="text-[10px] text-slate-400">
              {active.totalEpisodes} भाग · {active.views} Views · ⭐ {active.rating}
            </span>
          </div>

          <h2 className="text-2xl sm:text-4xl font-extrabold text-white font-['Manrope'] drop-shadow-md leading-tight">
            {active.hindiTitle || active.title}
          </h2>

          <p className="text-xs sm:text-sm text-slate-300 line-clamp-2 max-w-2xl drop-shadow">
            {active.synopsis}
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-1">
            <button
              onClick={() => onSelectDrama(active)}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-rose-600 to-rose-500 text-white font-extrabold text-xs shadow-lg shadow-rose-600/30 hover:scale-105 transition-all cursor-pointer"
            >
              <Play className="w-4 h-4 fill-white" />
              <span>Watch Episode 1 (Free)</span>
            </button>

            <button
              onClick={() => onOpenEpisodes(active)}
              className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#181B27]/80 backdrop-blur-md border border-[#292D3A] text-slate-200 hover:text-white text-xs font-semibold hover:border-slate-500 transition-colors cursor-pointer"
            >
              <Layers className="w-4 h-4 text-amber-400" />
              <span>All {active.totalEpisodes} Episodes</span>
            </button>
          </div>
        </div>
      </div>

      {/* Official Banner Quick-Switch Strip */}
      <div className="p-3 bg-[#0d0f18] border-t border-[#292D3A]/60 flex items-center gap-2 overflow-x-auto scrollbar-none">
        <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-2 shrink-0">
          Official Banners:
        </span>
        {banners.map((b, idx) => (
          <button
            key={b.id}
            onClick={() => setIndex(idx)}
            className={`flex items-center gap-2 px-3 py-1.5 rounded-xl text-xs font-medium shrink-0 transition-all cursor-pointer border ${
              index === idx
                ? 'bg-rose-950/80 border-rose-500 text-white shadow-md'
                : 'bg-[#181B27] border-[#292D3A] text-slate-400 hover:text-white'
            }`}
          >
            <span className={`w-2 h-2 rounded-full ${index === idx ? 'bg-rose-500 animate-pulse' : 'bg-slate-500'}`} />
            <span className="truncate max-w-[140px] sm:max-w-[180px]">
              {b.hindiTitle ? b.hindiTitle.split('(')[0] : b.title}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
});

export const ShortDramaPage: React.FC = () => {
  const [category, setCategory] = useState<string>('indian_only');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // Paginated data from the 1000+ short drama catalog
  const {
    items: dramas,
    totalPages,
    totalCount,
    page,
  } = ShortDramaService.getPaginated(currentPage, 24, category, searchQuery);

  const officialBanners = ShortDramaService.getOfficialBanners();

  const [activeDrama, setActiveDrama] = useState<ShortDrama>(() => dramas[0] || ShortDramaService.getAll()[0]);
  const [currentEpIndex, setCurrentEpIndex] = useState(0);

  // Player state: start muted so browser autoplay policy NEVER blocks video playback!
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1.0);
  const [progress, setProgress] = useState(0);
  const [liked, setLiked] = useState(false);
  const [likeHeartPop, setLikeHeartPop] = useState(false);
  const [copied, setCopied] = useState(false);
  const [showEpisodeDrawer, setShowEpisodeDrawer] = useState(false);
  const [autoNext, setAutoNext] = useState(true);

  // Touch swipe support for vertical reels
  const touchStartY = useRef<number | null>(null);

  // Reset to page 1 on filter or search change
  const handleCategoryChange = (newCat: string) => {
    setCategory(newCat);
    setCurrentPage(1);
  };

  const handleSearchChange = (query: string) => {
    setSearchQuery(query);
    setCurrentPage(1);
  };

  const currentEpisode: ShortDramaEpisode =
    activeDrama.episodes[currentEpIndex] || activeDrama.episodes[0];

  const handleDramaSelect = (drama: ShortDrama) => {
    setActiveDrama(drama);
    setCurrentEpIndex(0);
    setIsPlaying(true);
    setProgress(0);
    window.scrollTo({ top: 400, behavior: 'smooth' });
    if (videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  };

  const handleNextEpisode = () => {
    if (currentEpIndex < activeDrama.episodes.length - 1) {
      setCurrentEpIndex((prev) => prev + 1);
      setProgress(0);
      setIsPlaying(true);
    }
  };

  const handlePrevEpisode = () => {
    if (currentEpIndex > 0) {
      setCurrentEpIndex((prev) => prev - 1);
      setProgress(0);
      setIsPlaying(true);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play().catch(() => {});
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const cycleSpeed = () => {
    const speeds = [1.0, 1.25, 1.5, 2.0];
    const nextIdx = (speeds.indexOf(playbackSpeed) + 1) % speeds.length;
    const nextSpeed = speeds[nextIdx];
    setPlaybackSpeed(nextSpeed);
    if (videoRef.current) {
      videoRef.current.playbackRate = nextSpeed;
    }
  };

  const handleDoubleClick = () => {
    setLiked(true);
    setLikeHeartPop(true);
    setTimeout(() => setLikeHeartPop(false), 800);
  };

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const dur = videoRef.current.duration || 1;
    setProgress((videoRef.current.currentTime / dur) * 100);
  };

  const handleEnded = () => {
    if (autoNext && currentEpIndex < activeDrama.episodes.length - 1) {
      handleNextEpisode();
    } else if (videoRef.current) {
      // Loop current episode if at the end of playlist
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  };

  // Keyboard navigation: Space/Enter = Play/Pause, Up/Down = Next/Prev, M = Mute
  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;

      if (e.code === 'Space' || e.key === 'k') {
        e.preventDefault();
        togglePlay();
      } else if (e.key === 'ArrowDown' || e.key === 'j') {
        e.preventDefault();
        handleNextEpisode();
      } else if (e.key === 'ArrowUp' || e.key === 'l') {
        e.preventDefault();
        handlePrevEpisode();
      } else if (e.key === 'm' || e.key === 'M') {
        toggleMute();
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [currentEpIndex, activeDrama]);

  const handleShare = () => {
    const url = window.location.href;
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartY.current = e.touches[0].clientY;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (touchStartY.current === null) return;
    const deltaY = touchStartY.current - e.changedTouches[0].clientY;
    if (deltaY > 50) {
      handleNextEpisode();
    } else if (deltaY < -50) {
      handlePrevEpisode();
    }
    touchStartY.current = null;
  };

  return (
    <div className="pt-28 pb-16 min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#292D3A] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-rose-400 uppercase tracking-wider mb-1">
            <Flame className="w-4 h-4 text-rose-500 animate-pulse" />
            <span>New.MicroTV.st · 1,100+ Indian & Global Micro-Dramas</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Tv className="w-8 h-8 text-rose-500" />
            MicroTV: 1,000+ Short Dramas & Reels
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Stream over 1,000+ vertical short dramas: Chhupa Hua Crorepati Jamai, 18+ Desi Romance, Bahu Ka Badla, and Thakur Haveli sagas.
          </p>
        </div>

        {/* Global Search across 1000+ dramas */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search 1,000+ Hindi short dramas..."
            value={searchQuery}
            onChange={(e) => handleSearchChange(e.target.value)}
            className="w-full bg-[#181B27] border border-[#292D3A] rounded-2xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-rose-500"
          />
        </div>
      </div>

      {/* Official Short Drama Hero Spotlight Banner Showcase Carousel */}
      <OfficialDramaHeroBannerShowcase
        banners={officialBanners}
        onSelectDrama={handleDramaSelect}
        onOpenEpisodes={(d) => {
          setActiveDrama(d);
          setShowEpisodeDrawer(true);
        }}
      />

      {/* Featured MicroTV Vertical Reel Player */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left: 9:16 Vertical Video Reel Container */}
        <div
          onTouchStart={handleTouchStart}
          onTouchEnd={handleTouchEnd}
          onDoubleClick={handleDoubleClick}
          className="lg:col-span-7 xl:col-span-6 bg-black rounded-3xl overflow-hidden border border-[#292D3A] shadow-2xl relative aspect-[9/14] sm:aspect-[9/13] max-h-[680px] mx-auto w-full max-w-sm sm:max-w-md flex items-center justify-center select-none"
        >
          <video
            ref={videoRef}
            key={currentEpisode.videoUrl + currentEpIndex}
            src={currentEpisode.videoUrl}
            autoPlay
            playsInline
            muted={isMuted}
            onTimeUpdate={handleTimeUpdate}
            onEnded={handleEnded}
            onClick={togglePlay}
            className="w-full h-full object-cover cursor-pointer"
          />

          {/* Unmute Prompt Badge on top if muted */}
          {isMuted && (
            <button
              onClick={toggleMute}
              className="absolute top-16 left-4 z-20 flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-black/80 backdrop-blur-md border border-white/20 text-white text-xs font-bold hover:bg-rose-600 transition-colors cursor-pointer shadow-lg animate-pulse"
            >
              <VolumeX className="w-3.5 h-3.5 text-amber-400" />
              <span>Tap to Unmute Audio</span>
            </button>
          )}

          {/* Double Tap Heart Pop Animation */}
          {likeHeartPop && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-30 animate-ping">
              <Heart className="w-24 h-24 fill-rose-500 text-rose-500 drop-shadow-2xl" />
            </div>
          )}

          {/* Top Scrim with Title & Indian Audio Badge */}
          <div className="absolute top-0 inset-x-0 p-4 bg-gradient-to-b from-black/90 via-black/40 to-transparent pointer-events-none flex items-center justify-between text-white z-10">
            <div>
              <div className="flex items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-full bg-rose-600 text-[10px] font-bold uppercase tracking-wider backdrop-blur-md">
                  भाग {currentEpIndex + 1} / {activeDrama.totalEpisodes}
                </span>
                {activeDrama.isIndian && (
                  <span className="px-2 py-0.5 rounded-full bg-emerald-900/80 border border-emerald-600 text-[10px] font-bold text-emerald-300">
                    🇮🇳 हिंदी ऑडियो (Hindi)
                  </span>
                )}
              </div>
              <h3 className="font-bold text-sm text-white drop-shadow mt-1 line-clamp-1">
                {activeDrama.hindiTitle || activeDrama.title}
              </h3>
            </div>
          </div>

          {/* Right Floating Quick Action Bar */}
          <div className="absolute right-3 bottom-20 flex flex-col items-center gap-3 z-20">
            <button
              onClick={() => setLiked(!liked)}
              className="p-3 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white hover:scale-110 transition-transform cursor-pointer"
              title="Like"
            >
              <Heart className={`w-5 h-5 ${liked ? 'fill-rose-500 text-rose-500' : 'text-white'}`} />
            </button>

            <button
              onClick={() => setShowEpisodeDrawer(!showEpisodeDrawer)}
              className="p-3 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white hover:scale-110 transition-transform cursor-pointer"
              title="All Episodes (एपिसोड सूची)"
            >
              <Layers className="w-5 h-5 text-amber-400" />
            </button>

            <button
              onClick={cycleSpeed}
              className="px-2 py-1.5 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-[10px] font-bold text-white hover:scale-110 transition-transform cursor-pointer"
              title="Playback Speed"
            >
              {playbackSpeed}x
            </button>

            <button
              onClick={toggleMute}
              className="p-3 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white hover:scale-110 transition-transform cursor-pointer"
              title={isMuted ? 'Unmute' : 'Mute'}
            >
              {isMuted ? <VolumeX className="w-5 h-5 text-rose-400" /> : <Volume2 className="w-5 h-5 text-white" />}
            </button>

            <button
              onClick={handleShare}
              className="p-3 rounded-full bg-black/60 backdrop-blur-md border border-white/10 text-white hover:scale-110 transition-transform cursor-pointer"
              title="Share"
            >
              {copied ? <Check className="w-5 h-5 text-emerald-400" /> : <Share2 className="w-5 h-5" />}
            </button>
          </div>

          {/* Center Play/Pause Overlay indicator when paused */}
          {!isPlaying && (
            <div
              onClick={togglePlay}
              className="absolute inset-0 flex items-center justify-center bg-black/40 backdrop-blur-xs cursor-pointer z-10"
            >
              <div className="w-16 h-16 rounded-full bg-rose-600/90 text-white flex items-center justify-center shadow-2xl pl-1 hover:scale-110 transition-transform">
                <Play className="w-8 h-8 fill-current" />
              </div>
            </div>
          )}

          {/* Bottom Episode Info and Progress Slider */}
          <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black via-black/80 to-transparent z-10 space-y-2">
            <div className="flex items-center justify-between text-xs text-white">
              <span className="font-bold text-rose-300 truncate max-w-[200px]">
                {currentEpisode.title}
              </span>
              <div className="flex items-center gap-2">
                <button
                  onClick={handlePrevEpisode}
                  disabled={currentEpIndex === 0}
                  className="p-1 disabled:opacity-40 hover:text-rose-400 cursor-pointer"
                  title="Previous Episode [Up Arrow]"
                >
                  <SkipBack className="w-4 h-4" />
                </button>
                <button
                  onClick={handleNextEpisode}
                  disabled={currentEpIndex >= activeDrama.episodes.length - 1}
                  className="p-1 disabled:opacity-40 hover:text-rose-400 cursor-pointer"
                  title="Next Episode [Down Arrow]"
                >
                  <SkipForward className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Seamless Progress Line */}
            <div className="relative w-full h-1.5 bg-slate-700/60 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-rose-500 to-amber-400 rounded-full transition-all duration-100"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>
        </div>

        {/* Right: Drama Info & MicroTV Episode Selector */}
        <div className="lg:col-span-5 xl:col-span-6 space-y-4">
          {/* Main Info Card */}
          <div className="p-6 rounded-3xl bg-[#11131B] border border-[#292D3A] space-y-4 shadow-xl">
            <div className="flex flex-wrap items-center gap-2">
              <span className="px-2.5 py-1 rounded-lg bg-rose-600/90 text-white text-xs font-bold shadow-sm">
                {activeDrama.categoryLabel}
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-[#181B27] border border-[#292D3A] text-slate-300 text-xs font-semibold">
                {activeDrama.language} Audio
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-amber-950/60 border border-amber-600/60 text-amber-300 text-xs font-bold flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                <span>{activeDrama.rating}</span>
              </span>
              <span className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 text-xs">
                {activeDrama.totalEpisodes} भाग
              </span>
            </div>

            <div>
              <h2 className="text-xl sm:text-2xl font-extrabold text-white font-['Manrope']">
                {activeDrama.hindiTitle || activeDrama.title}
              </h2>
              {activeDrama.hindiTitle && (
                <p className="text-xs text-rose-400 font-semibold mt-0.5">
                  {activeDrama.title}
                </p>
              )}
            </div>

            <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
              {activeDrama.synopsis}
            </p>

            {/* Quick Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => {
                  setCurrentEpIndex(0);
                  setIsPlaying(true);
                  if (videoRef.current) {
                    videoRef.current.currentTime = 0;
                    videoRef.current.play().catch(() => {});
                  }
                }}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs shadow-lg shadow-rose-600/25 transition-all cursor-pointer"
              >
                <Play className="w-4 h-4 fill-white" />
                <span>Episode 1 (Free)</span>
              </button>

              <button
                onClick={() => setAutoNext(!autoNext)}
                className={`flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl border text-xs font-semibold transition-colors cursor-pointer ${
                  autoNext
                    ? 'bg-emerald-950/60 border-emerald-600 text-emerald-300'
                    : 'bg-[#181B27] border-[#292D3A] text-slate-400'
                }`}
              >
                <Gauge className="w-3.5 h-3.5" />
                <span>Auto-Play Next: {autoNext ? 'ON' : 'OFF'}</span>
              </button>
            </div>
          </div>

          {/* MicroTV Episode Selector Grid */}
          <div className="p-6 rounded-3xl bg-[#11131B] border border-[#292D3A] space-y-3 shadow-xl">
            <div className="flex items-center justify-between border-b border-[#292D3A] pb-3">
              <div className="flex items-center gap-2">
                <Layers className="w-4 h-4 text-rose-500" />
                <h3 className="font-bold text-white text-sm font-['Manrope']">
                  Episode List (एपिसोड सूची)
                </h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {activeDrama.totalEpisodes} Total Episodes
              </span>
            </div>

            <div className="grid grid-cols-4 sm:grid-cols-6 md:grid-cols-8 gap-2 max-h-64 overflow-y-auto pr-1">
              {activeDrama.episodes.map((ep, idx) => {
                const isCurrent = currentEpIndex === idx;
                return (
                  <button
                    key={ep.episodeNumber}
                    onClick={() => {
                      setCurrentEpIndex(idx);
                      setIsPlaying(true);
                      setProgress(0);
                    }}
                    className={`py-2 px-1 text-xs font-bold rounded-xl border transition-all cursor-pointer flex flex-col items-center gap-0.5 ${
                      isCurrent
                        ? 'bg-rose-600 text-white border-rose-500 shadow-md shadow-rose-600/30'
                        : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
                    }`}
                  >
                    <span>भाग {ep.episodeNumber}</span>
                    {ep.isFree ? (
                      <span className="text-[8px] text-emerald-400 font-semibold">FREE</span>
                    ) : (
                      <Lock className="w-2.5 h-2.5 text-amber-400" />
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Category Pills Filter Bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none pt-4">
        {[
          { id: 'indian_only', label: '🇮🇳 All Indian & Desi' },
          { id: 'all', label: '🌐 All 1,100+ Dramas' },
          { id: 'indian_desi', label: '🔥 Desi Billionaire' },
          { id: '18_mature', label: '🔞 18+ Desi Romance' },
          { id: 'revenge', label: '⚡ Revenge & Badla' },
          { id: 'palace', label: '👑 Royal Palace' },
          { id: 'billionaire', label: '💋 Contract Love' },
          { id: 'werewolf', label: '🐺 Werewolf & Luna' },
        ].map((cat) => (
          <button
            key={cat.id}
            onClick={() => handleCategoryChange(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all cursor-pointer border ${
              category === cat.id
                ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/20'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* 1,000+ Short Drama Grid with Pagination */}
      <div className="space-y-4">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span>Showing {dramas.length} of {totalCount} Short Dramas</span>
          <span>Page {page} of {totalPages}</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {dramas.map((drama) => (
            <ShortDramaCardItem
              key={drama.id}
              drama={drama}
              isActive={activeDrama.id === drama.id}
              onSelect={handleDramaSelect}
            />
          ))}
        </div>

        {/* Pagination Navigation Controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 pt-6">
            <button
              onClick={() => {
                setCurrentPage((p) => Math.max(1, p - 1));
                window.scrollTo({ top: 600, behavior: 'smooth' });
              }}
              disabled={currentPage <= 1}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold disabled:opacity-40 cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            <span className="px-4 py-2 rounded-xl bg-[#11131B] border border-[#292D3A] text-xs font-bold text-rose-400 font-mono">
              {currentPage} / {totalPages}
            </span>

            <button
              onClick={() => {
                setCurrentPage((p) => Math.min(totalPages, p + 1));
                window.scrollTo({ top: 600, behavior: 'smooth' });
              }}
              disabled={currentPage >= totalPages}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold disabled:opacity-40 cursor-pointer"
            >
              <span>Next</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Slide-out Full Episodes Drawer */}
      {showEpisodeDrawer && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fadeIn">
          <div className="bg-[#11131B] border border-[#292D3A] rounded-3xl max-w-xl w-full p-6 space-y-4 max-h-[85vh] flex flex-col shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#292D3A] pb-3">
              <div>
                <h3 className="text-base font-bold text-white font-['Manrope']">
                  {activeDrama.hindiTitle || activeDrama.title}
                </h3>
                <span className="text-xs text-rose-400 font-medium">
                  All {activeDrama.totalEpisodes} Episodes
                </span>
              </div>
              <button
                onClick={() => setShowEpisodeDrawer(false)}
                className="p-2 rounded-xl bg-[#181B27] text-slate-400 hover:text-white cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {activeDrama.episodes.map((ep, idx) => (
                <div
                  key={ep.episodeNumber}
                  onClick={() => {
                    setCurrentEpIndex(idx);
                    setShowEpisodeDrawer(false);
                    setIsPlaying(true);
                  }}
                  className={`p-3 rounded-xl border flex items-center justify-between cursor-pointer transition-colors ${
                    currentEpIndex === idx
                      ? 'bg-rose-950/60 border-rose-500 text-white'
                      : 'bg-[#181B27] border-[#292D3A] text-slate-300 hover:border-slate-500'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="w-7 h-7 rounded-lg bg-rose-600/30 text-rose-400 text-xs font-bold flex items-center justify-center">
                      {ep.episodeNumber}
                    </span>
                    <span className="text-xs font-medium">{ep.title}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] text-slate-500 font-mono">{ep.duration}</span>
                    {ep.isFree ? (
                      <span className="px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-600 text-emerald-300 text-[9px] font-bold">
                        FREE
                      </span>
                    ) : (
                      <Lock className="w-3.5 h-3.5 text-amber-400" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
