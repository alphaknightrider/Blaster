import React, { useRef, useState } from 'react';
import { useApp } from '../context/AppContext';
import { StorageManager } from '../storage';
import {
  Settings,
  HardDrive,
  Key,
  Globe,
  Sliders,
  Download,
  Upload,
  Trash2,
  Check,
  AlertTriangle,
} from 'lucide-react';

export const SettingsPage: React.FC = () => {
  const { settings, updateSettings, language, setLanguage, t, watchlist, continueWatching } = useApp();

  const [tmdbKey, setTmdbKey] = useState(settings.tmdbApiKey);
  const [watchmodeKey, setWatchmodeKey] = useState(settings.watchmodeApiKey);
  const [youtubeKey, setYoutubeKey] = useState(settings.youtubeApiKey);
  const [savedSuccess, setSavedSuccess] = useState(false);
  const [confirmClear, setConfirmClear] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleSaveApiKeys = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      tmdbApiKey: tmdbKey.trim(),
      watchmodeApiKey: watchmodeKey.trim(),
      youtubeApiKey: youtubeKey.trim(),
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 2500);
  };

  const handleExportData = () => {
    const json = StorageManager.exportAllData();
    const blob = new Blob([json], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cyrus_movies_backup_${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleImportClick = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      if (text) {
        const success = StorageManager.importData(text);
        if (success) {
          window.location.reload();
        } else {
          alert('Failed to parse backup file. Please ensure it is valid JSON.');
        }
      }
    };
    reader.readAsText(file);
  };

  const handleClearAll = () => {
    StorageManager.clearAllData();
    window.location.reload();
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
          <Settings className="w-8 h-8 text-[#8B5CF6]" />
          {t.settings.title}
        </h1>
        <p className="text-sm text-slate-400 mt-1">{t.settings.subtitle}</p>
      </div>

      {/* Language Preference */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
          <Globe className="w-4 h-4 text-[#38BDF8]" />
          {t.settings.languageSelect}
        </h2>
        <div className="flex gap-3">
          <button
            onClick={() => setLanguage('en')}
            className={`px-4 py-2.5 rounded-xl text-xs font-semibold transition-all border ${
              language === 'en'
                ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            English (Global)
          </button>
          <button
            onClick={() => setLanguage('hi')}
            className={`px-4 py-2.5 rounded-xl text-xs font-semibold transition-all border ${
              language === 'hi'
                ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            हिंदी (Hindi)
          </button>
        </div>
      </div>

      {/* Playback & Bandwidth */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
          <Sliders className="w-4 h-4 text-[#8B5CF6]" />
          Playback & Bandwidth Options
        </h2>

        <div className="space-y-4">
          <label className="flex items-center justify-between cursor-pointer">
            <div>
              <p className="text-sm font-semibold text-white">{t.settings.autoResume}</p>
              <p className="text-xs text-slate-400">{t.settings.autoResumeDesc}</p>
            </div>
            <input
              type="checkbox"
              checked={settings.autoResume}
              onChange={(e) => updateSettings({ autoResume: e.target.checked })}
              className="w-4 h-4 accent-[#8B5CF6] rounded"
            />
          </label>

          <label className="flex items-center justify-between cursor-pointer pt-3 border-t border-[#292D3A]/60">
            <div>
              <p className="text-sm font-semibold text-white">{t.settings.lowBandwidth}</p>
              <p className="text-xs text-slate-400">{t.settings.lowBandwidthDesc}</p>
            </div>
            <input
              type="checkbox"
              checked={settings.lowBandwidth}
              onChange={(e) => updateSettings({ lowBandwidth: e.target.checked })}
              className="w-4 h-4 accent-[#8B5CF6] rounded"
            />
          </label>
        </div>
      </div>

      {/* API Configuration */}
      <form onSubmit={handleSaveApiKeys} className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
            <Key className="w-4 h-4 text-amber-400" />
            {t.settings.apiConfiguration}
          </h2>
          {savedSuccess && (
            <span className="flex items-center gap-1 text-xs text-emerald-400 font-semibold">
              <Check className="w-3.5 h-3.5" />
              {t.settings.savedSuccess}
            </span>
          )}
        </div>
        <p className="text-xs text-slate-400">{t.settings.apiDesc}</p>

        <div className="space-y-3 pt-2 text-xs">
          <div>
            <label className="block text-slate-300 mb-1 font-medium">{t.settings.tmdbKey}</label>
            <input
              type="password"
              value={tmdbKey}
              onChange={(e) => setTmdbKey(e.target.value)}
              placeholder="Leave empty to use built-in public access key"
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-1 font-medium">{t.settings.watchmodeKey}</label>
            <input
              type="password"
              value={watchmodeKey}
              onChange={(e) => setWatchmodeKey(e.target.value)}
              placeholder="Optional: for real-time commercial streaming availability"
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <div>
            <label className="block text-slate-300 mb-1 font-medium">{t.settings.youtubeKey}</label>
            <input
              type="password"
              value={youtubeKey}
              onChange={(e) => setYoutubeKey(e.target.value)}
              placeholder="Optional: for trailer lookups"
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>
        </div>

        <button
          type="submit"
          className="px-5 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7c4def] text-white text-xs font-semibold transition-colors"
        >
          {t.settings.saveSettings}
        </button>
      </form>

      {/* Local Storage & Backup Center */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
        <h2 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
          <HardDrive className="w-4 h-4 text-emerald-400" />
          {t.settings.dataManagement}
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs bg-[#181B27] p-3 rounded-xl border border-[#292D3A]/60">
          <div>
            <span className="text-slate-400">Watchlist Items</span>
            <p className="text-white font-bold text-sm mt-0.5 tabular-nums">{watchlist.length}</p>
          </div>
          <div>
            <span className="text-slate-400">Active Checkpoints</span>
            <p className="text-white font-bold text-sm mt-0.5 tabular-nums">{continueWatching.length}</p>
          </div>
          <div>
            <span className="text-slate-400">Database Connection</span>
            <p className="text-emerald-400 font-bold text-sm mt-0.5">None (Zero DB)</p>
          </div>
        </div>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            onClick={handleExportData}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] text-xs font-semibold text-slate-200 transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>{t.settings.exportBackup}</span>
          </button>

          <button
            onClick={handleImportClick}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] text-xs font-semibold text-slate-200 transition-colors"
          >
            <Upload className="w-3.5 h-3.5 text-[#8B5CF6]" />
            <span>{t.settings.importBackup}</span>
          </button>
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".json"
            className="hidden"
          />

          {!confirmClear ? (
            <button
              onClick={() => setConfirmClear(true)}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-red-950/40 border border-red-900/60 hover:bg-red-900/60 text-xs font-semibold text-red-300 transition-colors ml-auto"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{t.settings.clearAllData}</span>
            </button>
          ) : (
            <div className="flex items-center gap-2 ml-auto">
              <span className="text-xs text-red-400 font-medium">Are you sure?</span>
              <button
                onClick={handleClearAll}
                className="px-3 py-1.5 rounded-lg bg-red-600 hover:bg-red-700 text-white text-xs font-bold transition-colors"
              >
                Yes, Wipe
              </button>
              <button
                onClick={() => setConfirmClear(false)}
                className="px-3 py-1.5 rounded-lg bg-[#292D3A] text-slate-300 text-xs transition-colors"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
