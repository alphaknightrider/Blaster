import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { StorageManager } from '../storage';
import { HistoryItem } from '../types';
import { History, Trash2, Film, Clock } from 'lucide-react';
import { DEFAULT_POSTER } from '../services/normalizer';

export const HistoryPage: React.FC = () => {
  const [history, setHistory] = useState<HistoryItem[]>(() => StorageManager.getHistory());

  const handleClear = () => {
    StorageManager.clearHistory();
    setHistory([]);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <History className="w-8 h-8 text-[#38BDF8]" />
            Viewing History
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Chronological records of titles viewed on this browser.
          </p>
        </div>

        {history.length > 0 && (
          <button
            onClick={handleClear}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#181B27] border border-[#292D3A] text-xs font-semibold text-slate-300 hover:text-red-400 hover:border-red-400/50 transition-colors self-start sm:self-auto"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear History</span>
          </button>
        )}
      </div>

      {history.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400 space-y-3">
          <Film className="w-12 h-12 mx-auto text-slate-600" />
          <h2 className="text-lg font-bold text-white font-['Manrope']">No History Recorded</h2>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Titles you open will automatically be recorded here for fast access.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {history.map((item, idx) => (
            <Link
              key={idx}
              to={item.mediaType === 'tv' ? `/tv/${encodeURIComponent(item.id)}` : `/movie/${encodeURIComponent(item.id)}`}
              className="group flex flex-col rounded-xl overflow-hidden bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all p-2.5"
            >
              <img
                src={item.poster || DEFAULT_POSTER}
                alt={item.title}
                className="w-full aspect-[2/3] object-cover rounded-lg bg-[#11131B]"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <h3 className="font-semibold text-white text-xs mt-2 truncate group-hover:text-[#38BDF8] transition-colors">
                {item.title}
              </h3>
              <span className="text-[10px] text-slate-400 flex items-center gap-1 mt-0.5">
                <Clock className="w-3 h-3" />
                <span>{new Date(item.viewedAt).toLocaleDateString()}</span>
              </span>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
};
