import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Globe2 } from 'lucide-react';

const LANGUAGE_LIST = [
  { code: 'hi', label: 'Hindi (हिंदी)', region: 'Bollywood & Hindi Cinema' },
  { code: 'ta', label: 'Tamil (தமிழ்)', region: 'Kollywood Cinema' },
  { code: 'te', label: 'Telugu (తెలుగు)', region: 'Tollywood Cinema' },
  { code: 'en', label: 'English', region: 'Hollywood & Global English' },
  { code: 'ja', label: 'Japanese (日本語)', region: 'Japanese Cinema & Anime' },
  { code: 'ko', label: 'Korean (한국어)', region: 'K-Drama & Korean New Wave' },
  { code: 'es', label: 'Spanish (Español)', region: 'Latin American & Spanish Cinema' },
  { code: 'fr', label: 'French (Français)', region: 'French New Wave & European Art' },
];

export const Languages: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const selectedCode = searchParams.get('code') || 'hi';

  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  const currentLang = LANGUAGE_LIST.find((l) => l.code === selectedCode) || LANGUAGE_LIST[0];

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await ApiClient.getByLanguage(selectedCode, 'movie', 1);
        setItems(res);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [selectedCode]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
          <Globe2 className="w-8 h-8 text-[#38BDF8]" />
          World Languages & Regional Cinema
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Explore movies filtered directly by their authentic original language and cultural regions.
        </p>
      </div>

      {/* Language Buttons */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-4 mb-6">
        {LANGUAGE_LIST.map((l) => (
          <button
            key={l.code}
            onClick={() => setSearchParams({ code: l.code })}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-all border ${
              selectedCode === l.code
                ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            {l.label}
          </button>
        ))}
      </div>

      {/* Spotlight */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] mb-8">
        <h2 className="text-xl font-bold text-white font-['Manrope']">{currentLang.label}</h2>
        <p className="text-xs text-slate-400 mt-1">{currentLang.region}</p>
      </div>

      {/* Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      )}
    </div>
  );
};
