import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { MovieRow } from '../components/movie/MovieRow';
import { Tv, Sparkles, ChevronLeft, ChevronRight, SlidersHorizontal } from 'lucide-react';

export const TvShows: React.FC = () => {
  const [trending, setTrending] = useState<NormalizedTitle[]>([]);
  const [tvmaze, setTvmaze] = useState<NormalizedTitle[]>([]);
  const [popular, setPopular] = useState<NormalizedTitle[]>([]);
  const [topRated, setTopRated] = useState<NormalizedTitle[]>([]);
  const [loadingRows, setLoadingRows] = useState(true);

  // 100,000+ Series Catalog State
  const [catalogPage, setCatalogPage] = useState(1);
  const [catalogSort, setCatalogSort] = useState<'popularity.desc' | 'vote_average.desc' | 'first_air_date.desc'>('popularity.desc');
  const [catalogTitles, setCatalogTitles] = useState<NormalizedTitle[]>([]);
  const [loadingCatalog, setLoadingCatalog] = useState(true);

  useEffect(() => {
    const loadCuratedRows = async () => {
      setLoadingRows(true);
      try {
        const [tr, tvm, pop, top] = await Promise.allSettled([
          ApiClient.getTrending('tv'),
          ApiClient.getTvmazeShows(0),
          ApiClient.getPopular('tv', 1),
          ApiClient.getTopRated('tv', 1),
        ]);

        if (tr.status === 'fulfilled') setTrending(tr.value);
        if (tvm.status === 'fulfilled') setTvmaze(tvm.value);
        if (pop.status === 'fulfilled') setPopular(pop.value);
        if (top.status === 'fulfilled') setTopRated(top.value);
      } finally {
        setLoadingRows(false);
      }
    };
    loadCuratedRows();
  }, []);

  useEffect(() => {
    let cancelled = false;
    const fetchCatalog = async () => {
      setLoadingCatalog(true);
      try {
        const res = await ApiClient.discover({
          type: 'tv',
          page: catalogPage,
          sortBy: catalogSort,
        });
        if (!cancelled) setCatalogTitles(res);
      } finally {
        if (!cancelled) setLoadingCatalog(false);
      }
    };
    fetchCatalog();
    return () => {
      cancelled = true;
    };
  }, [catalogPage, catalogSort]);

  return (
    <div className="pt-28 pb-16 min-h-screen space-y-10">
      {/* Header */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#292D3A] pb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#38BDF8] uppercase tracking-wider mb-1">
              <Sparkles className="w-4 h-4 text-[#38BDF8]" />
              <span>Broadcast & Streaming Network</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
              <Tv className="w-8 h-8 text-[#38BDF8]" />
              100,000+ Television Series
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              Prestige drama serials, episodic comedy, and broadcast network releases with episode selection.
            </p>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#11131B] border border-[#292D3A] text-xs font-bold text-slate-300">
            <span className="w-2 h-2 rounded-full bg-[#38BDF8] animate-pulse" />
            <span>100,000+ Series Online</span>
          </div>
        </div>
      </div>

      {/* Featured Curated Carousels */}
      <div className="space-y-4">
        <MovieRow title="Trending TV Shows" items={trending} loading={loadingRows} />
        {tvmaze.length > 0 && (
          <MovieRow
            title="📺 TVmaze Broadcast Television Catalog"
            subtitle="Free open television network broadcasts and serial schedules"
            items={tvmaze}
            loading={loadingRows}
          />
        )}
        <MovieRow title="Popular Ongoing Series" items={popular} loading={loadingRows} />
        <MovieRow title="Highest Rated Television Series" items={topRated} loading={loadingRows} />
      </div>

      {/* 100,000+ Complete TV Catalog Grid with Unlimited Pagination */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6 pt-6 border-t border-[#292D3A]">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white font-['Manrope']">
              Browse Complete TV Series (Page {catalogPage} of 500+)
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Access the complete episodic catalog across worldwide networks.
            </p>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={catalogSort}
              onChange={(e) => {
                setCatalogSort(e.target.value as any);
                setCatalogPage(1);
              }}
              className="bg-[#181B27] border border-[#292D3A] text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#38BDF8] cursor-pointer"
            >
              <option value="popularity.desc">Most Popular</option>
              <option value="vote_average.desc">Highest Rated</option>
              <option value="first_air_date.desc">Latest Airing Date</option>
            </select>
          </div>
        </div>

        {/* TV Grid */}
        {loadingCatalog ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {Array.from({ length: 20 }).map((_, i) => (
              <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
            {catalogTitles.map((title) => (
              <MovieCard key={title.id} title={title} />
            ))}
          </div>
        )}

        {/* Pagination Bar */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
          <button
            onClick={() => {
              setCatalogPage((p) => Math.max(1, p - 1));
              window.scrollTo({ top: 600, behavior: 'smooth' });
            }}
            disabled={catalogPage <= 1 || loadingCatalog}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-semibold disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {[1, 2, 3, 4, 5].map((pageNum) => (
            <button
              key={pageNum}
              onClick={() => {
                setCatalogPage(pageNum);
                window.scrollTo({ top: 600, behavior: 'smooth' });
              }}
              className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                catalogPage === pageNum
                  ? 'bg-[#38BDF8] text-slate-900 shadow-md shadow-[#38BDF8]/20 font-extrabold'
                  : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
              }`}
            >
              {pageNum}
            </button>
          ))}

          {catalogPage > 5 && (
            <span className="w-9 h-9 flex items-center justify-center text-xs font-bold text-slate-900 bg-[#38BDF8] rounded-xl">
              {catalogPage}
            </span>
          )}

          <span className="text-slate-500 text-xs px-1">...</span>

          <button
            onClick={() => {
              setCatalogPage(500);
              window.scrollTo({ top: 600, behavior: 'smooth' });
            }}
            className="px-3 h-9 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
          >
            500+
          </button>

          <button
            onClick={() => {
              setCatalogPage((p) => p + 1);
              window.scrollTo({ top: 600, behavior: 'smooth' });
            }}
            disabled={loadingCatalog}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#38BDF8] text-slate-900 text-xs font-bold hover:bg-[#0284c7] disabled:opacity-50 transition-colors shadow-md shadow-[#38BDF8]/20 cursor-pointer"
          >
            <span>Next Page</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
