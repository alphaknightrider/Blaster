import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Bookmark, Trash2, Film, Star, Play } from 'lucide-react';
import { DEFAULT_POSTER } from '../services/normalizer';

export const WatchlistPage: React.FC = () => {
  const { watchlist, toggleWatchlist, t } = useApp();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Bookmark className="w-8 h-8 text-[#8B5CF6]" />
            Your Cinema Watchlist
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Persisted 100% locally in your current browser without cloud sign-in.
          </p>
        </div>

        <span className="text-xs font-semibold px-3 py-1.5 rounded-lg bg-[#181B27] border border-[#292D3A] text-slate-300 self-start sm:self-auto">
          {watchlist.length} {watchlist.length === 1 ? 'Title' : 'Titles'} Saved
        </span>
      </div>

      {watchlist.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400 space-y-4">
          <Film className="w-12 h-12 mx-auto text-slate-600" />
          <h2 className="text-lg font-bold text-white font-['Manrope']">Your Watchlist is Empty</h2>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            Browse through trending films, classics, or anime and tap the bookmark icon to save titles here.
          </p>
          <Link
            to="/discover"
            className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] transition-colors"
          >
            <span>Discover Titles</span>
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {watchlist.map((item) => (
            <div
              key={item.id}
              className="group relative flex flex-col rounded-xl overflow-hidden bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all shadow-md"
            >
              <Link
                to={item.mediaType === 'tv' ? `/tv/${encodeURIComponent(item.id)}` : `/movie/${encodeURIComponent(item.id)}`}
                className="relative aspect-[2/3] w-full bg-[#11131B] overflow-hidden"
              >
                <img
                  src={item.poster || DEFAULT_POSTER}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />

                {/* Rating */}
                {item.rating > 0 && (
                  <div className="absolute top-2 left-2 flex items-center gap-1 bg-[#090A0F]/80 backdrop-blur-md px-1.5 py-0.5 rounded text-[11px] font-semibold text-amber-300">
                    <Star className="w-3 h-3 fill-amber-300" />
                    <span className="tabular-nums">{item.rating.toFixed(1)}</span>
                  </div>
                )}
              </Link>

              <div className="p-3 flex flex-col justify-between flex-1">
                <div>
                  <h3 className="font-semibold text-white text-xs sm:text-sm truncate" title={item.title}>
                    {item.title}
                  </h3>
                  <p className="text-[11px] text-slate-400 mt-0.5 capitalize">
                    {item.mediaType === 'tv' ? 'TV Series' : 'Movie'}
                  </p>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#292D3A]/60 mt-2">
                  <Link
                    to={`/watch/${item.mediaType}/${encodeURIComponent(item.id)}`}
                    className="flex items-center gap-1 text-[11px] font-semibold text-[#8B5CF6] hover:text-[#38BDF8]"
                  >
                    <Play className="w-3 h-3 fill-current" />
                    <span>Watch</span>
                  </Link>

                  <button
                    onClick={() => toggleWatchlist(item)}
                    className="p-1 rounded text-slate-400 hover:text-red-400 transition-colors"
                    title={t.common.removeFromWatchlist}
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
