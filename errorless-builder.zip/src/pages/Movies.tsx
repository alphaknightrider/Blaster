import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { MovieRow } from '../components/movie/MovieRow';
import {
  Film,
  Sparkles,
  ChevronLeft,
  ChevronRight,
  SlidersHorizontal,
  Flame,
  ShieldAlert,
  Headphones,
  Zap,
} from 'lucide-react';

interface MovieCategory {
  id: string;
  name: string;
  genreId?: number | string;
  includeAdult?: boolean;
  language?: string;
  badge?: string;
}

const VEGAMOVIES_CATEGORIES: MovieCategory[] = [
  { id: 'all', name: '⚡ All Movies' },
  { id: 'dual_audio', name: '🎧 Dual Audio (Hindi Dubbed)', language: 'hi', badge: 'Hindi 5.1' },
  { id: 'bollywood', name: '🇮🇳 Bollywood Cinema', language: 'hi', badge: 'Pure Hindi' },
  { id: '18_adult', name: '🔞 18+ Adult & Erotic', genreId: 10749, includeAdult: true, badge: '18+ Mature' },
  { id: 'action', name: '💥 Action & Thrillers', genreId: 28 },
  { id: 'horror', name: '🩸 Horror & Suspense', genreId: 27 },
  { id: 'scifi', name: '🚀 Sci-Fi & Fantasy', genreId: 878 },
  { id: 'animation', name: '🌸 Animated & Anime', genreId: 16, badge: 'Dual Audio' },
  { id: 'comedy', name: '😂 Comedy Blockbusters', genreId: 35 },
];

export const Movies: React.FC = () => {
  const [trending, setTrending] = useState<NormalizedTitle[]>([]);
  const [popular, setPopular] = useState<NormalizedTitle[]>([]);
  const [topRated, setTopRated] = useState<NormalizedTitle[]>([]);
  const [loadingRows, setLoadingRows] = useState(true);

  // Active Category & 100,000+ Catalog Pagination State
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [catalogPage, setCatalogPage] = useState(1);
  const [catalogSort, setCatalogSort] = useState<
    'popularity.desc' | 'vote_average.desc' | 'primary_release_date.desc' | 'revenue.desc'
  >('popularity.desc');
  const [catalogTitles, setCatalogTitles] = useState<NormalizedTitle[]>([]);
  const [loadingCatalog, setLoadingCatalog] = useState(true);

  // Load curated rows only once for Page 1
  useEffect(() => {
    const loadCuratedRows = async () => {
      setLoadingRows(true);
      try {
        const [tr, pop, top] = await Promise.allSettled([
          ApiClient.getTrending('movie'),
          ApiClient.getPopular('movie', 2),
          ApiClient.getTopRated('movie', 3),
        ]);

        const seen = new Set<string>();
        const dedupe = (items: NormalizedTitle[]): NormalizedTitle[] => {
          return items.filter((item) => {
            const key = (item.title || '').toLowerCase().trim();
            if (!key || seen.has(key) || seen.has(item.id)) return false;
            seen.add(key);
            seen.add(item.id);
            return true;
          });
        };

        if (tr.status === 'fulfilled') setTrending(dedupe(tr.value));
        if (pop.status === 'fulfilled') setPopular(dedupe(pop.value));
        if (top.status === 'fulfilled') setTopRated(dedupe(top.value));
      } finally {
        setLoadingRows(false);
      }
    };
    loadCuratedRows();
  }, []);

  // Fetch paginated catalog
  useEffect(() => {
    let cancelled = false;
    const fetchCatalog = async () => {
      setLoadingCatalog(true);
      try {
        const selectedCat = VEGAMOVIES_CATEGORIES.find((c) => c.id === activeCategory);
        const res = await ApiClient.discover({
          type: 'movie',
          page: catalogPage,
          sortBy: catalogSort,
          genreId: selectedCat?.genreId,
          language: selectedCat?.language,
          includeAdult: selectedCat?.includeAdult,
        } as any);

        if (!cancelled) {
          // Strict deduplication so no title repeats on the current page
          const seen = new Set<string>();
          const dedupedCatalog = res.filter((item) => {
            const key = (item.title || '').toLowerCase().trim();
            if (!key || seen.has(key) || seen.has(item.id)) return false;
            seen.add(key);
            seen.add(item.id);
            return true;
          });
          setCatalogTitles(dedupedCatalog);
        }
      } finally {
        if (!cancelled) setLoadingCatalog(false);
      }
    };
    fetchCatalog();
    return () => {
      cancelled = true;
    };
  }, [activeCategory, catalogPage, catalogSort]);

  const activeCatObj =
    VEGAMOVIES_CATEGORIES.find((c) => c.id === activeCategory) || VEGAMOVIES_CATEGORIES[0];

  return (
    <div className="pt-28 pb-16 min-h-screen space-y-8">
      {/* Page Header (VegaMovies Style) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#292D3A] pb-6">
          <div>
            <div className="flex items-center gap-2 text-xs font-bold text-[#A78BFA] uppercase tracking-wider mb-1">
              <Zap className="w-4 h-4 text-amber-400" />
              <span>VegaMovies High-Speed Mirror Engine</span>
            </div>
            <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
              <Film className="w-8 h-8 text-[#8B5CF6]" />
              100,000+ Movies & Dual Audio Hub
            </h1>
            <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
              Authentic VegaMovies experience: 1080p, 720p, 480p, Dual Audio (Hindi 5.1), 18+ adult cinema, and direct cloud links.
            </p>
          </div>

          <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#11131B] border border-[#292D3A] text-xs font-bold text-slate-300">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
            <span>100,000+ Titles Online · Zero Repeats</span>
          </div>
        </div>
      </div>

      {/* VegaMovies Category Filter Tabs Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
          {VEGAMOVIES_CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => {
                setActiveCategory(cat.id);
                setCatalogPage(1);
              }}
              className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border cursor-pointer flex items-center gap-1.5 ${
                activeCategory === cat.id
                  ? cat.id === '18_adult'
                    ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/30'
                    : 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/30'
                  : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
              }`}
            >
              <span>{cat.name}</span>
              {cat.badge && (
                <span
                  className={`text-[9px] px-1.5 py-0.2 rounded font-extrabold ${
                    cat.id === '18_adult'
                      ? 'bg-black/50 text-rose-300'
                      : 'bg-black/40 text-amber-300'
                  }`}
                >
                  {cat.badge}
                </span>
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Featured Curated Carousels: Shown ONLY on Page 1 when category is 'all' so movies don't repeat on other pages! */}
      {catalogPage === 1 && activeCategory === 'all' && (
        <div className="space-y-6">
          <MovieRow
            title="🔥 Trending Blockbusters (Hindi Dual Audio)"
            subtitle="Top theatrical feature films worldwide"
            items={trending}
            loading={loadingRows}
          />
          <MovieRow
            title="🍿 Audience Favorites & Popular Theatricals"
            subtitle="High-rated cinema releases"
            items={popular}
            loading={loadingRows}
          />
          <MovieRow
            title="⭐ Critically Acclaimed Masterpieces (8.0+)"
            subtitle="Cinephile approved cinematic masterworks"
            items={topRated}
            loading={loadingRows}
          />
        </div>
      )}

      {/* Main 100,000+ Deep Catalog Grid with Zero Repeating Titles */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-6">
        {/* Subheader & Sort Selector */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#11131B] border border-[#292D3A]">
          <div>
            <h3 className="text-lg font-bold text-white font-['Manrope'] flex items-center gap-2">
              <span>{activeCatObj.name}</span>
              <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#181B27] text-slate-400 border border-[#292D3A]">
                Page {catalogPage} of 500+
              </span>
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Exact VegaMovies dual audio tags, 1080p Web-DL, and instant download mirrors.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-4 h-4 text-slate-400" />
            <select
              value={catalogSort}
              onChange={(e) => {
                setCatalogSort(e.target.value as any);
                setCatalogPage(1);
              }}
              className="bg-[#181B27] border border-[#292D3A] text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#8B5CF6] cursor-pointer"
            >
              <option value="popularity.desc">Most Popular</option>
              <option value="vote_average.desc">Highest Rated</option>
              <option value="primary_release_date.desc">Latest Release</option>
              <option value="revenue.desc">Top Box Office</option>
            </select>
          </div>
        </div>

        {/* Catalog Grid */}
        {loadingCatalog ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 24 }).map((_, i) => (
              <div
                key={i}
                className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]"
              />
            ))}
          </div>
        ) : catalogTitles.length === 0 ? (
          <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
            <Film className="w-12 h-12 mx-auto text-slate-600 mb-2" />
            <h4 className="text-base font-bold text-white">No Movies Found in This Category</h4>
            <p className="text-xs text-slate-400 mt-1">Please select another category or reset filters.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {catalogTitles.map((title) => (
              <MovieCard key={title.id} title={title} />
            ))}
          </div>
        )}

        {/* 500+ Page Fast Pagination Controls */}
        <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
          <button
            onClick={() => {
              setCatalogPage((p) => Math.max(1, p - 1));
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
            disabled={catalogPage <= 1 || loadingCatalog}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-semibold disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {[1, 2, 3, 4, 5].map((pageNum) => (
            <button
              key={pageNum}
              onClick={() => {
                setCatalogPage(pageNum);
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                catalogPage === pageNum
                  ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/30'
                  : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
              }`}
            >
              {pageNum}
            </button>
          ))}

          {catalogPage > 5 && (
            <span className="w-9 h-9 flex items-center justify-center text-xs font-bold text-white bg-[#8B5CF6] rounded-xl shadow-md">
              {catalogPage}
            </span>
          )}

          <span className="text-slate-500 text-xs px-1">...</span>

          <button
            onClick={() => {
              setCatalogPage(500);
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
            className="px-3 h-9 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
          >
            500+
          </button>

          <button
            onClick={() => {
              setCatalogPage((p) => p + 1);
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
            disabled={loadingCatalog}
            className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-md shadow-[#8B5CF6]/30 cursor-pointer"
          >
            <span>Next Page</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
