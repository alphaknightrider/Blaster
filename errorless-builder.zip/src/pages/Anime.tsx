import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { StudioGhibliVault } from '../components/anime/StudioGhibliVault';
import { AnimeScheduleView } from '../components/anime/AnimeScheduleView';
import { AnimeUniversesView } from '../components/anime/AnimeUniversesView';
import { WhatAnimeSearch } from '../components/anime/WhatAnimeSearch';
import { AnimeQuotesFactsView } from '../components/anime/AnimeQuotesFactsView';
import { MangaAdaptationsView } from '../components/anime/MangaAdaptationsView';
import {
  Sparkles,
  Flame,
  Star,
  Film,
  Tv,
  Calendar,
  Compass,
  Zap,
  Search,
  Quote,
  Layers,
  BookOpen,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';

type MainSection = 'catalog' | 'schedule' | 'ghibli' | 'universes' | 'manga' | 'whatanime' | 'quotes';

export const Anime: React.FC = () => {
  const [activeSection, setActiveSection] = useState<MainSection>('catalog');
  const [catalogTab, setCatalogTab] = useState<'trending' | 'top_rated' | 'movies' | 'tv'>('trending');
  const [catalogPage, setCatalogPage] = useState(1);
  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (activeSection !== 'catalog') return;
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      try {
        let res: NormalizedTitle[] = [];
        if (catalogTab === 'trending') {
          res = await ApiClient.getAnimeCatalog(catalogPage);
        } else if (catalogTab === 'top_rated') {
          res = await ApiClient.getTopRatedAnime(catalogPage);
        } else if (catalogTab === 'movies') {
          res = await ApiClient.discover({
            type: 'movie',
            genreId: 16,
            language: 'ja',
            sortBy: 'vote_average.desc',
            page: catalogPage,
          });
        } else {
          res = await ApiClient.discover({
            type: 'tv',
            genreId: 16,
            language: 'ja',
            sortBy: 'popularity.desc',
            page: catalogPage,
          });
        }
        if (!cancelled) setItems(res);
      } catch {
        if (!cancelled) setItems([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [catalogTab, catalogPage, activeSection]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#292D3A] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#A78BFA] uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
            <span>Federated Anime Intelligence Ecosystem</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight">
            Anime Universe & Databases
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Live integration of AniList GraphQL, Jikan / MyAnimeList, Kitsu, AniDB, Shikimori, Anime-Planet, Studio Ghibli, Dattebayo Naruto, Dragon Ball, Trace.moe reverse scene search, and Anime Quotes.
          </p>
        </div>

        {/* Database Badges Bar */}
        <div className="flex flex-wrap gap-1.5 self-start md:self-auto text-[10px] font-semibold text-slate-400">
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">AniList</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Jikan / MAL</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Kitsu</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">AniDB</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Ghibli API</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Dragon Ball API</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Dattebayo API</span>
          <span className="px-2 py-0.5 rounded-md bg-[#181B27] border border-[#292D3A]">Trace.moe</span>
        </div>
      </div>

      {/* Main Feature Tabs Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-[#292D3A]">
        {[
          { id: 'catalog', label: 'Anime Catalog', icon: Layers },
          { id: 'schedule', label: 'Broadcast Schedule', icon: Calendar },
          { id: 'ghibli', label: 'Studio Ghibli Vault', icon: Sparkles },
          { id: 'universes', label: 'Dragon Ball & Naruto DB', icon: Zap },
          { id: 'manga', label: 'Manga & Books (MangaDex)', icon: BookOpen },
          { id: 'whatanime', label: 'What Anime (Trace.moe)', icon: Search },
          { id: 'quotes', label: 'Quotes & Facts', icon: Quote },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSection === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSection(tab.id as MainSection)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all whitespace-nowrap cursor-pointer ${
                isActive
                  ? 'bg-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/20'
                  : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Section 1: Main Anime Catalog (AniList, Kitsu, Jikan) */}
      {activeSection === 'catalog' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <h3 className="text-lg font-bold text-white font-['Manrope']">
              Explore Anime Series & Films (AniList GraphQL & Kitsu)
            </h3>

            {/* Catalog Subtabs */}
            <div className="flex items-center gap-1.5 p-1 bg-[#11131B] border border-[#292D3A] rounded-xl self-start sm:self-auto">
              <button
                onClick={() => setCatalogTab('trending')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  catalogTab === 'trending' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Flame className="w-3.5 h-3.5" />
                <span>Trending</span>
              </button>

              <button
                onClick={() => setCatalogTab('top_rated')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  catalogTab === 'top_rated' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Star className="w-3.5 h-3.5" />
                <span>Top Rated</span>
              </button>

              <button
                onClick={() => setCatalogTab('movies')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  catalogTab === 'movies' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Film className="w-3.5 h-3.5" />
                <span>Movies</span>
              </button>

              <button
                onClick={() => setCatalogTab('tv')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  catalogTab === 'tv' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
                }`}
              >
                <Tv className="w-3.5 h-3.5" />
                <span>Broadcast TV</span>
              </button>
            </div>
          </div>

          {loading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {Array.from({ length: 15 }).map((_, i) => (
                <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
              ))}
            </div>
          ) : items.length === 0 ? (
            <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
              <Film className="w-12 h-12 mx-auto text-slate-600 mb-2" />
              <h2 className="text-lg font-bold text-white">No Anime Found</h2>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {items.map((item) => (
                <MovieCard key={item.id} title={item} />
              ))}
            </div>
          )}

          {/* Deep Anime Pagination (10,000+ Titles) */}
          <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
            <button
              onClick={() => {
                setCatalogPage((p) => Math.max(1, p - 1));
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              disabled={catalogPage <= 1 || loading}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-semibold disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-4 h-4" />
              <span>Previous</span>
            </button>

            {[1, 2, 3, 4, 5].map((pageNum) => (
              <button
                key={pageNum}
                onClick={() => {
                  setCatalogPage(pageNum);
                  window.scrollTo({ top: 300, behavior: 'smooth' });
                }}
                className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  catalogPage === pageNum
                    ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/30'
                    : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
                }`}
              >
                {pageNum}
              </button>
            ))}

            {catalogPage > 5 && (
              <span className="w-9 h-9 flex items-center justify-center text-xs font-bold text-white bg-[#8B5CF6] rounded-xl shadow-md">
                {catalogPage}
              </span>
            )}

            <span className="text-slate-500 text-xs px-1">...</span>

            <button
              onClick={() => {
                setCatalogPage(100);
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              className="px-3 h-9 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
            >
              100+
            </button>

            <button
              onClick={() => {
                setCatalogPage((p) => p + 1);
                window.scrollTo({ top: 300, behavior: 'smooth' });
              }}
              disabled={loading}
              className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-md shadow-[#8B5CF6]/30 cursor-pointer"
            >
              <span>Next Page</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* Section 2: Anime Broadcast Schedule (AnimeSchedule & Jikan) */}
      {activeSection === 'schedule' && <AnimeScheduleView />}

      {/* Section 3: Studio Ghibli Vault (Studio Ghibli API) */}
      {activeSection === 'ghibli' && <StudioGhibliVault />}

      {/* Section 4: Anime Universes (Dragon Ball & Dattebayo Naruto API) */}
      {activeSection === 'universes' && <AnimeUniversesView />}

      {/* Section 5: MangaDex & OpenLibrary Adaptations */}
      {activeSection === 'manga' && <MangaAdaptationsView />}

      {/* Section 6: What Anime (Trace.moe Reverse Image Search) */}
      {activeSection === 'whatanime' && <WhatAnimeSearch />}

      {/* Section 7: Anime Quotes & Facts (Animechan, AOT Quotes, Kyoko, Facts API) */}
      {activeSection === 'quotes' && <AnimeQuotesFactsView />}
    </div>
  );
};
