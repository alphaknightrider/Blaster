import React, { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle, TVSeason } from '../types';
import { useApp } from '../context/AppContext';
import { StorageManager } from '../storage';
import { MovieCard } from '../components/movie/MovieCard';
import { DownloadCenter } from '../components/player/DownloadCenter';
import { VegaDownloadWidget } from '../components/player/VegaDownloadWidget';
import {
  Play,
  Bookmark,
  Share2,
  Star,
  Tv,
  Calendar,
  Layers,
  ChevronLeft,
  Check,
  ExternalLink,
} from 'lucide-react';
import { DEFAULT_BACKDROP, DEFAULT_POSTER } from '../services/normalizer';
import { AnimeUniverseService } from '../services/providers/animeUniverse';

export const TvDetails: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { t, isInWatchlist, toggleWatchlist } = useApp();

  const [title, setTitle] = useState<NormalizedTitle | null>(null);
  const [selectedSeason, setSelectedSeason] = useState<number>(1);
  const [loading, setLoading] = useState(true);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!id) return;
    const fetchTitle = async () => {
      setLoading(true);
      try {
        const decodedId = decodeURIComponent(id);
        const data = await ApiClient.getTitleDetails(decodedId);
        setTitle(data);
        if (data) {
          StorageManager.addHistory({
            id: data.id,
            title: data.title,
            poster: data.poster,
            mediaType: data.mediaType,
          });
          if (data.seasons && data.seasons.length > 0) {
            setSelectedSeason(data.seasons[0].seasonNumber);
          }
        }
      } finally {
        setLoading(false);
      }
    };
    fetchTitle();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen pt-32 pb-16 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="h-96 rounded-2xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
      </div>
    );
  }

  if (!title) {
    return (
      <div className="min-h-screen pt-36 pb-16 max-w-xl mx-auto px-4 text-center">
        <Tv className="w-12 h-12 mx-auto text-slate-600 mb-3" />
        <h2 className="text-xl font-bold text-white font-['Manrope']">TV Show Unavailable</h2>
        <p className="text-xs text-slate-400 mt-2 mb-6">
          The requested episodic metadata could not be found.
        </p>
        <Link
          to="/tv"
          className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Browse TV Shows</span>
        </Link>
      </div>
    );
  }

  const inWatchlist = isInWatchlist(title.id);
  const watchPath = `/watch/${title.mediaType}/${encodeURIComponent(title.id)}`;

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: title.title,
        text: `Watch ${title.title} on Cyrus Movies`,
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const currentSeason = title.seasons?.find((s) => s.seasonNumber === selectedSeason);

  return (
    <div className="min-h-screen pb-20">
      {/* Backdrop Header */}
      <div className="relative w-full h-[50vh] min-h-[420px] max-h-[600px] overflow-hidden">
        <img
          src={title.backdrop || title.poster || DEFAULT_BACKDROP}
          alt={title.title}
          onError={(e) => {
            e.currentTarget.src = title.poster || DEFAULT_BACKDROP;
          }}
          className="w-full h-full object-cover filter brightness-[0.6] contrast-[1.05]"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-[#090A0F]/70 to-transparent" />
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-44 relative z-10 space-y-12">
        <div className="flex flex-col md:flex-row gap-8 items-start">
          {/* Poster */}
          <div className="w-48 sm:w-60 md:w-72 shrink-0 rounded-2xl overflow-hidden bg-[#181B27] border border-[#292D3A] shadow-2xl mx-auto md:mx-0">
            <img
              src={title.poster || DEFAULT_POSTER}
              alt={title.title}
              onError={(e) => {
                e.currentTarget.src = DEFAULT_POSTER;
              }}
              className="w-full aspect-[2/3] object-cover"
              referrerPolicy="no-referrer"
            />
          </div>

          {/* Details */}
          <div className="flex-1 space-y-5">
            <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-slate-400 font-medium">
              <span className="text-[#8B5CF6] uppercase tracking-wider font-semibold">
                Television Series
              </span>
              {title.seasonsCount && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Layers className="w-3.5 h-3.5" />
                    <span>{title.seasonsCount} {t.common.seasons}</span>
                  </span>
                </>
              )}
              {title.year && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5" />
                    <span>{title.year}</span>
                  </span>
                </>
              )}
              {title.rating > 0 && (
                <>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1 text-amber-300 font-semibold">
                    <Star className="w-3.5 h-3.5 fill-amber-300" />
                    <span className="tabular-nums">{title.rating.toFixed(1)}</span>
                  </span>
                </>
              )}
            </div>

            <div>
              <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight leading-tight">
                {title.title}
              </h1>
              {title.tagline && (
                <p className="text-slate-400 text-sm sm:text-base italic mt-1">&ldquo;{title.tagline}&rdquo;</p>
              )}
            </div>

            {/* Actions */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={() => navigate(watchPath)}
                className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#8B5CF6] hover:bg-[#7c4def] text-white font-semibold text-sm transition-all shadow-lg shadow-[#8B5CF6]/20 hover:scale-[1.02] active:scale-[0.98]"
              >
                <Play className="w-4 h-4 fill-current ml-0.5" />
                <span>{t.common.watchNow}</span>
              </button>

              <button
                onClick={() =>
                  toggleWatchlist({
                    id: title.id,
                    title: title.title,
                    poster: title.poster,
                    backdrop: title.backdrop,
                    mediaType: title.mediaType,
                    releaseDate: title.releaseDate,
                    rating: title.rating,
                    genres: title.genres,
                  })
                }
                className={`flex items-center gap-2 px-5 py-3 rounded-xl border text-sm font-medium transition-all ${
                  inWatchlist
                    ? 'bg-[#8B5CF6] border-[#8B5CF6] text-white'
                    : 'bg-[#181B27] border-[#292D3A] text-slate-300 hover:text-white'
                }`}
              >
                <Bookmark className={`w-4 h-4 ${inWatchlist ? 'fill-current' : ''}`} />
                <span>{inWatchlist ? t.common.inWatchlist : t.common.addToWatchlist}</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-3 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-sm transition-colors"
              >
                {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
                <span>{copied ? 'Copied' : t.common.share}</span>
              </button>
            </div>

            {/* Overview */}
            <div className="pt-2">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                {t.common.overview}
              </h2>
              <p className="text-slate-300 text-sm sm:text-base leading-relaxed max-w-3xl">
                {title.overview}
              </p>
            </div>

            {/* Metadata tags */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-3 border-t border-[#292D3A]/60 text-xs">
              <div>
                <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Total Episodes</span>
                <span className="text-white font-medium text-sm mt-0.5 block">{title.episodesCount || 'Ongoing'}</span>
              </div>
              <div>
                <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Original Language</span>
                <span className="text-white font-medium text-sm mt-0.5 block">{title.language}</span>
              </div>
              {title.genres && title.genres.length > 0 && (
                <div>
                  <span className="text-slate-500 block uppercase tracking-wider text-[10px]">Genres</span>
                  <span className="text-white font-medium text-sm mt-0.5 block">{title.genres.map((g) => g.name).join(', ')}</span>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* External Anime Databases & Cross-References */}
        {(title.mediaType === 'anime' ||
          title.genres?.some((g) => g.name.toLowerCase() === 'animation') ||
          title.language?.toLowerCase() === 'ja') && (
          <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2 font-['Manrope']">
                  <Tv className="w-4 h-4 text-[#8B5CF6]" />
                  <span>Anime Databases & Metadata Cross-References</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">
                  Verified external entries across global anime intelligence networks.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2.5">
              {AnimeUniverseService.getExternalDatabaseLinks(
                title.title,
                title.externalIds?.anilistId,
                title.externalIds?.malId
              ).map((db) => (
                <a
                  key={db.name}
                  href={db.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="p-3 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] transition-all flex flex-col justify-between group hover:shadow-md"
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-[#11131B] text-[#A78BFA] border border-[#292D3A]">
                      {db.badge}
                    </span>
                    <ExternalLink className="w-3 h-3 text-slate-500 group-hover:text-white transition-colors" />
                  </div>
                  <span className="text-xs font-bold text-slate-200 group-hover:text-white transition-colors">
                    {db.name}
                  </span>
                </a>
              ))}
            </div>
          </div>
        )}

        {/* Seasons & Episodes Explorer */}
        {title.seasons && title.seasons.length > 0 && (
          <div className="space-y-6 pt-4">
            <div className="flex items-center justify-between border-b border-[#292D3A] pb-4">
              <h2 className="text-2xl font-bold text-white font-['Manrope']">
                Seasons & Episodes
              </h2>

              {/* Season Selector Tabs */}
              <div className="flex gap-2 overflow-x-auto no-scrollbar">
                {title.seasons.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => setSelectedSeason(s.seasonNumber)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors whitespace-nowrap ${
                      selectedSeason === s.seasonNumber
                        ? 'bg-[#8B5CF6] text-white shadow'
                        : 'bg-[#181B27] border border-[#292D3A] text-slate-400 hover:text-white'
                    }`}
                  >
                    Season {s.seasonNumber}
                  </button>
                ))}
              </div>
            </div>

            {/* Season Details */}
            {currentSeason && (
              <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white font-['Manrope']">
                    {currentSeason.name}
                  </h3>
                  <span className="text-xs text-slate-400">
                    {currentSeason.episodeCount} Episodes
                  </span>
                </div>
                {currentSeason.overview && (
                  <p className="text-xs text-slate-400 leading-relaxed max-w-3xl">
                    {currentSeason.overview}
                  </p>
                )}
              </div>
            )}
          </div>
        )}

        {/* VegaMovies Fast Cloud Download Mirrors */}
        <VegaDownloadWidget title={title} />

        {/* Download Center */}
        <DownloadCenter title={title} />

        {/* Similar Titles */}
        {title.similarTitles && title.similarTitles.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white font-['Manrope']">{t.common.similarTitles}</h2>
            <div className="flex gap-4 overflow-x-auto no-scrollbar py-1">
              {title.similarTitles.map((sim) => (
                <div key={sim.id} className="w-[150px] sm:w-[170px] shrink-0">
                  <MovieCard title={sim} />
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
