import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../context/AppContext';
import { Play, Trash2, Clock, PlayCircle } from 'lucide-react';
import { DEFAULT_POSTER } from '../services/normalizer';

export const ContinueWatchingPage: React.FC = () => {
  const navigate = useNavigate();
  const { continueWatching, removeProgress, t } = useApp();

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
          <PlayCircle className="w-8 h-8 text-[#8B5CF6]" />
          Continue Watching
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Exact playback checkpoints saved locally during your active stream sessions.
        </p>
      </div>

      {continueWatching.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400 space-y-3">
          <Clock className="w-12 h-12 mx-auto text-slate-600" />
          <h2 className="text-lg font-bold text-white font-['Manrope']">No Active Streams in Progress</h2>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            When you stream an authorized title or movie, your timestamp progress will be stored here.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {continueWatching.map((item) => (
            <div
              key={item.id}
              className="group relative rounded-2xl overflow-hidden bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all shadow-lg flex flex-col"
            >
              <div className="relative aspect-video w-full bg-[#11131B] overflow-hidden">
                <img
                  src={item.poster || DEFAULT_POSTER}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  loading="lazy"
                  referrerPolicy="no-referrer"
                />

                <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                  <button
                    onClick={() => navigate(`/watch/${item.mediaType}/${encodeURIComponent(item.id)}`)}
                    className="w-12 h-12 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform"
                    aria-label={`Resume ${item.title}`}
                  >
                    <Play className="w-5 h-5 fill-current ml-0.5" />
                  </button>
                </div>

                {/* Progress bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1.5 bg-black/60">
                  <div
                    className="h-full bg-[#8B5CF6]"
                    style={{ width: `${item.percentage}%` }}
                  />
                </div>
              </div>

              <div className="p-4 flex flex-col justify-between flex-1">
                <div>
                  <h3 className="font-semibold text-white text-sm truncate" title={item.title}>
                    {item.title}
                  </h3>
                  <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
                    <span className="tabular-nums font-mono">
                      {formatTime(item.currentTime)} / {formatTime(item.duration)}
                    </span>
                    <span className="font-semibold text-[#38BDF8] tabular-nums">{item.percentage}%</span>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-[#292D3A]/60 mt-3">
                  <button
                    onClick={() => navigate(`/watch/${item.mediaType}/${encodeURIComponent(item.id)}`)}
                    className="text-xs font-semibold text-[#8B5CF6] hover:text-[#38BDF8] transition-colors"
                  >
                    Resume Playback
                  </button>
                  <button
                    onClick={() => removeProgress(item.id)}
                    className="text-slate-400 hover:text-red-400 transition-colors p-1"
                    title="Remove from Continue Watching"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
