import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { VegaMoviesProvider } from '../services/providers/vegamovies';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import {
  Zap,
  Search,
  SlidersHorizontal,
  Flame,
  ChevronLeft,
  ChevronRight,
  Loader2,
  Sparkles,
  ExternalLink,
} from 'lucide-react';

const CATEGORIES = [
  { id: 'all', label: '⚡ All 100K+ Releases', lang: '' },
  { id: 'bollywood', label: '🇮🇳 Bollywood (Hindi)', lang: 'hi' },
  { id: 'south', label: '🔥 South Hindi Dubbed (Telugu/Tamil)', lang: 'te' },
  { id: 'hollywood', label: '🎬 Hollywood Dual Audio', lang: 'en' },
  { id: 'series', label: '📺 Hindi Web Series', lang: 'hi', type: 'tv' },
  { id: 'anime', label: '🌸 Anime & Animation', genreId: 16 },
];

export const VegaMoviesPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const currentCategory = searchParams.get('cat') || 'all';

  const [titles, setTitles] = useState<NormalizedTitle[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [selectedQuality, setSelectedQuality] = useState<'all' | '4k' | '1080p' | '720p' | '480p'>('all');

  useEffect(() => {
    let cancelled = false;

    const fetchContent = async () => {
      setLoading(true);
      try {
        let results: NormalizedTitle[] = [];

        if (searchQuery.trim()) {
          results = await ApiClient.search(searchQuery.trim());
        } else if (currentCategory === 'bollywood') {
          results = await VegaMoviesProvider.getBollywoodReleases(page);
        } else if (currentCategory === 'south') {
          results = await VegaMoviesProvider.getSouthHindiDubbed(page);
        } else if (currentCategory === 'hollywood') {
          results = await VegaMoviesProvider.getHollywoodDualAudio(page);
        } else if (currentCategory === 'series') {
          results = await VegaMoviesProvider.getWebSeries(page);
        } else if (currentCategory === 'anime') {
          results = await ApiClient.discover({ type: 'movie', genreId: 16, page });
        } else {
          // All releases: popular + trending Bollywood & global
          const [trending, hindi] = await Promise.allSettled([
            ApiClient.getTrending('movie'),
            VegaMoviesProvider.getBollywoodReleases(page),
          ]);
          const trVal = trending.status === 'fulfilled' ? trending.value : [];
          const hiVal = hindi.status === 'fulfilled' ? hindi.value : [];
          results = [...hiVal, ...trVal];
        }

        if (!cancelled) {
          // Remove duplicate IDs
          const seen = new Set<string>();
          const deduped = results.filter((item) => {
            if (seen.has(item.id)) return false;
            seen.add(item.id);
            return true;
          });
          setTitles(deduped);
        }
      } catch {
        if (!cancelled) setTitles([]);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    fetchContent();

    return () => {
      cancelled = true;
    };
  }, [currentCategory, searchQuery, page]);

  const handleCategorySelect = (catId: string) => {
    setSearchParams({ cat: catId });
    setPage(1);
    setSearchQuery('');
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Banner / Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#181B27] via-[#251b3d] to-[#181B27] border border-[#292D3A] p-6 sm:p-10 shadow-2xl">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#8B5CF6]/20 border border-[#8B5CF6]/40 text-[#8B5CF6] text-xs font-bold uppercase tracking-wider">
            <Zap className="w-3.5 h-3.5" />
            <span>VegaMovies Open Source Hub</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white font-['Manrope'] tracking-tight leading-tight">
            100,000+ Movies & TV Shows
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Direct streaming and multi-cloud download mirrors (4K, 1080p, 720p, 480p).
            Bollywood Hindi, South Indian Hindi Dubbed, Hollywood Dual Audio, and Web Series — 100% free and working.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold bg-emerald-950/50 border border-emerald-800/40 px-3 py-1 rounded-lg">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Direct Fast Cloud Mirrors</span>
            </span>
            <span className="flex items-center gap-1.5 text-[#38BDF8] font-semibold bg-[#38BDF8]/10 border border-[#38BDF8]/30 px-3 py-1 rounded-lg">
              <span>Dual Audio [Hindi + English]</span>
            </span>
            <span className="flex items-center gap-1.5 text-amber-300 font-semibold bg-amber-950/50 border border-amber-800/40 px-3 py-1 rounded-lg">
              <span>4K UHD & 1080p Web-DL</span>
            </span>
          </div>
        </div>
      </div>

      {/* Live Search Bar */}
      <div className="relative">
        <div className="flex items-center gap-3 p-4 bg-[#11131B] border border-[#292D3A] rounded-2xl shadow-xl focus-within:border-[#8B5CF6] transition-colors">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search any movie, South Hindi Dubbed, Bollywood, actor or web series in 100,000+ titles..."
            className="w-full bg-transparent text-white text-sm sm:text-base focus:outline-none placeholder:text-slate-500 font-medium"
          />
          {loading && <Loader2 className="w-5 h-5 text-[#8B5CF6] animate-spin shrink-0" />}
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="text-xs text-slate-400 hover:text-white px-2 py-1 rounded bg-[#181B27]"
            >
              Clear
            </button>
          )}
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => handleCategorySelect(cat.id)}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border ${
              currentCategory === cat.id && !searchQuery
                ? 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/30'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Titles Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : titles.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400 space-y-3">
          <Flame className="w-12 h-12 mx-auto text-slate-600" />
          <h2 className="text-lg font-bold text-white font-['Manrope']">No Movies Found</h2>
          <p className="text-xs text-slate-400">Try searching for popular titles like RRR, Pushpa, Animal, or Jawan.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {titles.map((title) => (
            <MovieCard key={title.id} title={title} />
          ))}
        </div>
      )}

      {/* Pagination */}
      {!searchQuery && (
        <div className="flex items-center justify-center gap-4 pt-6">
          <button
            disabled={page <= 1 || loading}
            onClick={() => {
              setPage((prev) => Math.max(1, prev - 1));
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs font-semibold text-slate-300 hover:text-white disabled:opacity-40 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          <span className="text-xs text-slate-400 font-medium">
            Page <strong className="text-white tabular-nums">{page}</strong>
          </span>

          <button
            disabled={loading || titles.length < 10}
            onClick={() => {
              setPage((prev) => prev + 1);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs font-semibold text-slate-300 hover:text-white disabled:opacity-40 transition-colors"
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );
};
