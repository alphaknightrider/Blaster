import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Award } from 'lucide-react';

export const TopRated: React.FC = () => {
  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      setLoading(true);
      try {
        const res = await ApiClient.getTopRated('movie', 1);
        setItems(res);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
          <Award className="w-8 h-8 text-amber-400" />
          Top Rated Cinema of All Time
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Pinnacles of filmmaking craft, storytelling, and cinematic mastery as evaluated by millions.
        </p>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      )}
    </div>
  );
};
