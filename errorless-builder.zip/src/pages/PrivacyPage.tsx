import React from 'react';
import { ShieldCheck, Lock, HardDrive } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-6">
      <div>
        <h1 className="text-3xl font-extrabold text-white font-['Manrope'] tracking-tight">
          Privacy Policy
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Effective Date: {new Date().getFullYear()} — Client-First Data Protection.
        </p>
      </div>

      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4 text-sm text-slate-300 leading-relaxed">
        <div className="flex items-center gap-2 text-emerald-400 font-semibold text-base">
          <Lock className="w-5 h-5" />
          <span>Zero Server Storage & No Tracking</span>
        </div>
        <p>
          Cyrus Movies does not operate an account database, analytics tracking beacons, or cross-site profiling cookies.
        </p>
        <p>
          <strong>What is stored on your device:</strong>
        </p>
        <ul className="list-disc pl-5 text-xs text-slate-400 space-y-1">
          <li>Watchlist items added by you.</li>
          <li>Video timestamp progress for active media sessions.</li>
          <li>Search keywords entered in the search bar.</li>
          <li>Interface preferences such as display language (English/Hindi) and bandwidth modes.</li>
          <li>Optional developer API keys if you decide to supply your own.</li>
        </ul>
        <p>
          All of this information is stored strictly inside your browser’s `localStorage` and `IndexedDB`. It never leaves your device or connects to an unauthorized third-party telemetry server.
        </p>
        <p>
          You have full control to export a portable JSON backup of your records or completely wipe all data via the Settings page at any time.
        </p>
      </div>
    </div>
  );
};
