import React, { useEffect, useRef, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { StorageManager } from '../storage';
import { Search, Loader2, Filter, History } from 'lucide-react';

export const SearchPage: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const [query, setQuery] = useState(initialQuery);
  const [filterType, setFilterType] = useState<'all' | 'movie' | 'tv' | 'archive'>('all');
  const [results, setResults] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchHistory, setSearchHistory] = useState<string[]>(() => StorageManager.getSearchHistory());

  const abortControllerRef = useRef<AbortController | null>(null);

  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);

    const timer = setTimeout(async () => {
      try {
        const data = await ApiClient.search(
          query.trim(),
          { type: filterType },
          controller.signal
        );
        setResults(data);
        StorageManager.addSearchQuery(query.trim());
        setSearchHistory(StorageManager.getSearchHistory());
        setSearchParams({ q: query.trim() });
      } catch (err: any) {
        if (err.name !== 'AbortError') setResults([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, filterType]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold text-white font-['Manrope'] tracking-tight">
          Search Cinema & Television
        </h1>
        <p className="text-xs text-slate-400 mt-1">
          Universal federated query across TMDB metadata and Internet Archive collections.
        </p>
      </div>

      {/* Input box */}
      <div className="relative mb-6">
        <div className="flex items-center gap-3 p-4 bg-[#11131B] border border-[#292D3A] rounded-2xl shadow-xl focus-within:border-[#8B5CF6] transition-colors">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Type any movie title, director, television show, or franchise..."
            className="w-full bg-transparent text-white text-base focus:outline-none placeholder:text-slate-500 font-medium"
          />
          {loading && <Loader2 className="w-5 h-5 text-[#8B5CF6] animate-spin shrink-0" />}
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 mb-8 overflow-x-auto no-scrollbar pb-2">
        {(['all', 'movie', 'tv', 'archive'] as const).map((type) => (
          <button
            key={type}
            onClick={() => setFilterType(type)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              filterType === type
                ? 'bg-[#8B5CF6] text-white shadow-md'
                : 'bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white'
            }`}
          >
            {type === 'all' && 'All Results'}
            {type === 'movie' && 'Movies'}
            {type === 'tv' && 'TV Series'}
            {type === 'archive' && 'Public Domain Cinema'}
          </button>
        ))}
      </div>

      {/* Results grid */}
      {query.trim().length === 0 ? (
        <div className="p-8 rounded-2xl bg-[#11131B] border border-[#292D3A]">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">
            <History className="w-4 h-4 text-[#8B5CF6]" />
            <span>Recent Searches</span>
          </div>
          {searchHistory.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {searchHistory.map((item, idx) => (
                <button
                  key={idx}
                  onClick={() => setQuery(item)}
                  className="px-3 py-1.5 rounded-lg bg-[#181B27] border border-[#292D3A] text-xs text-slate-300 hover:border-[#8B5CF6] hover:text-white transition-colors"
                >
                  {item}
                </button>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500">Your search queries will be saved locally on this browser.</p>
          )}
        </div>
      ) : results.length > 0 ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {results.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      ) : !loading ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
          <Filter className="w-10 h-10 mx-auto text-slate-500 mb-2" />
          <p className="font-semibold text-white text-base">No titles found for &ldquo;{query}&rdquo;</p>
          <p className="text-xs text-slate-400 mt-1">Check spelling or try a broader search term.</p>
        </div>
      ) : null}
    </div>
  );
};
