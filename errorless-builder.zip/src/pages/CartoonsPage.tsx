import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Sparkles, Film, ShieldCheck, Download, Play } from 'lucide-react';

export const CartoonsPage: React.FC = () => {
  const [cartoons, setCartoons] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchCartoons = async () => {
      setLoading(true);
      try {
        const data = await ApiClient.getClassicCartoons();
        setCartoons(data);
      } catch {
        setCartoons([]);
      } finally {
        setLoading(false);
      }
    };
    fetchCartoons();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Header */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-r from-[#1e1b4b] via-[#311042] to-[#1e1b4b] border border-[#292D3A] p-6 sm:p-10 shadow-2xl">
        <div className="max-w-3xl space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-400/20 border border-amber-400/40 text-amber-300 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-3.5 h-3.5" />
            <span>Golden Age Animation & Cartoons</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-black text-white font-['Manrope'] tracking-tight">
            Classic Cartoons & Vintage Animation
          </h1>

          <p className="text-slate-300 text-sm sm:text-base leading-relaxed">
            Preserved historical masterworks from Fleischer Studios, Warner Bros, and Ub Iwerks.
            Featuring Superman (1941), Popeye the Sailor, Betty Boop, Steamboat Willie, and Casper — 100% free streaming and open cultural downloads.
          </p>

          <div className="flex flex-wrap items-center gap-3 pt-2 text-xs">
            <span className="flex items-center gap-1.5 text-emerald-400 font-semibold bg-emerald-950/60 border border-emerald-800/40 px-3 py-1 rounded-lg">
              <ShieldCheck className="w-3.5 h-3.5" />
              <span>Public Domain & Open Culture</span>
            </span>
            <span className="flex items-center gap-1.5 text-[#38BDF8] font-semibold bg-[#38BDF8]/10 border border-[#38BDF8]/30 px-3 py-1 rounded-lg">
              <Play className="w-3.5 h-3.5" />
              <span>Instant High-Quality Embeds</span>
            </span>
          </div>
        </div>
      </div>

      {/* Cartoons Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : cartoons.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
          <Film className="w-12 h-12 mx-auto text-slate-600 mb-2" />
          <h2 className="text-lg font-bold text-white">No Cartoons Available</h2>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {cartoons.map((cartoon) => (
            <MovieCard key={cartoon.id} title={cartoon} />
          ))}
        </div>
      )}
    </div>
  );
};
