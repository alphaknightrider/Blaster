import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Key, Check, Info } from 'lucide-react';

export const AdminApiSettings: React.FC = () => {
  const { settings, updateSettings } = useApp();

  const [tmdbKey, setTmdbKey] = useState(settings.tmdbApiKey);
  const [watchmodeKey, setWatchmodeKey] = useState(settings.watchmodeApiKey);
  const [youtubeKey, setYoutubeKey] = useState(settings.youtubeApiKey);
  const [saved, setSaved] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    updateSettings({
      tmdbApiKey: tmdbKey.trim(),
      watchmodeApiKey: watchmodeKey.trim(),
      youtubeApiKey: youtubeKey.trim(),
    });
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-6">
      {/* Sub-nav */}
      <div className="flex gap-2 border-b border-[#292D3A] pb-3 text-xs font-semibold">
        <Link to="/admin" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Overview
        </Link>
        <Link to="/admin/provider-status" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Provider Status
        </Link>
        <Link to="/admin/api-settings" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-white border border-[#8B5CF6]">
          API Settings
        </Link>
        <Link to="/admin/content-preview" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Catalog Preview
        </Link>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white font-['Manrope']">API Configuration Guide</h1>
          <p className="text-xs text-slate-400 mt-1">Configure and override developer API access keys.</p>
        </div>
        {saved && (
          <span className="flex items-center gap-1 text-xs text-emerald-400 font-semibold">
            <Check className="w-3.5 h-3.5" />
            Saved!
          </span>
        )}
      </div>

      {/* Guide Card */}
      <div className="p-4 rounded-xl bg-[#11131B] border border-[#292D3A] text-xs text-slate-300 space-y-2">
        <div className="flex items-center gap-2 font-semibold text-white">
          <Info className="w-4 h-4 text-[#38BDF8]" />
          <span>How API Keys Are Handled in Zero-Database Mode</span>
        </div>
        <p>
          Keys entered here are kept solely in your browser&apos;s encrypted LocalStorage. They are never sent to a cloud database. If you leave keys blank, Cyrus Movies utilizes its built-in fallback key with public rate-limiting quotas.
        </p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4 text-xs">
        <div>
          <label className="block text-slate-300 mb-1 font-semibold">TMDB API Key (v3 auth)</label>
          <input
            type="password"
            value={tmdbKey}
            onChange={(e) => setTmdbKey(e.target.value)}
            placeholder="e.g. 84142f8832a76f2b467c6999a4c84a86"
            className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
          />
          <span className="text-[11px] text-slate-500 mt-1 block">Free developer key from themoviedb.org/settings/api</span>
        </div>

        <div>
          <label className="block text-slate-300 mb-1 font-semibold">Watchmode API Key</label>
          <input
            type="password"
            value={watchmodeKey}
            onChange={(e) => setWatchmodeKey(e.target.value)}
            placeholder="e.g. apiKey=..."
            className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
          />
          <span className="text-[11px] text-slate-500 mt-1 block">Optional: for commercial streaming sources</span>
        </div>

        <div>
          <label className="block text-slate-300 mb-1 font-semibold">YouTube Data v3 API Key</label>
          <input
            type="password"
            value={youtubeKey}
            onChange={(e) => setYoutubeKey(e.target.value)}
            placeholder="AIzaSy..."
            className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2.5 focus:outline-none focus:border-[#8B5CF6]"
          />
          <span className="text-[11px] text-slate-500 mt-1 block">Optional: official trailers play seamlessly without this key via embedded players</span>
        </div>

        <button
          type="submit"
          className="px-6 py-2.5 rounded-xl bg-[#8B5CF6] hover:bg-[#7c4def] text-white font-semibold transition-colors shadow-md"
        >
          Save Configuration
        </button>
      </form>
    </div>
  );
};
