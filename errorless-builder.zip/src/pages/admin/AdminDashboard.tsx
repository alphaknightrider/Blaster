import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiClient } from '../../services/apiClient';
import { providerRegistry } from '../../services/providerRegistry';
import { StorageManager } from '../../storage';
import { cache } from '../../services/cache';
import { LogEntry, ProviderHealth } from '../../types';
import {
  Activity,
  Key,
  Database,
  Terminal,
  RefreshCw,
  Trash2,
  CheckCircle2,
  AlertCircle,
  Eye,
  ShieldAlert,
} from 'lucide-react';

export const AdminDashboard: React.FC = () => {
  const [providers, setProviders] = useState<ProviderHealth[]>(() => providerRegistry.getAll());
  const [logs, setLogs] = useState<LogEntry[]>(() => StorageManager.getLogs());
  const [pinging, setPinging] = useState(false);
  const [cacheCleared, setCacheCleared] = useState(false);

  const handlePingAll = async () => {
    setPinging(true);
    try {
      const results = await ApiClient.pingAll();
      setProviders([...results]);
    } finally {
      setPinging(false);
    }
  };

  const handleClearCache = async () => {
    await cache.clear();
    setCacheCleared(true);
    setTimeout(() => setCacheCleared(false), 2000);
  };

  const handleClearLogs = () => {
    StorageManager.clearLogs();
    setLogs([]);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Title & Navigation Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Activity className="w-8 h-8 text-[#8B5CF6]" />
            Diagnostic & Provider Console
          </h1>
          <p className="text-xs text-slate-400 mt-1">
            Local browser administrative diagnostics, health pings, and provider telemetry.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePingAll}
            disabled={pinging}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-md"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${pinging ? 'animate-spin' : ''}`} />
            <span>Test All Providers</span>
          </button>
        </div>
      </div>

      {/* Security Disclaimer Notice */}
      <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-800/50 flex items-start gap-3 text-xs text-amber-200">
        <ShieldAlert className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
        <p leading-relaxed>
          <strong>Security Notice:</strong> This admin console operates locally within your client browser for development, key configuration, and federation diagnostics. It does not control server credentials or bypass third-party rate limits.
        </p>
      </div>

      {/* Sub-navigation links */}
      <div className="flex gap-2 border-b border-[#292D3A] pb-3 text-xs font-semibold">
        <Link to="/admin" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-white border border-[#8B5CF6]">
          Overview
        </Link>
        <Link to="/admin/provider-status" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Provider Status
        </Link>
        <Link to="/admin/api-settings" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          API Settings
        </Link>
        <Link to="/admin/content-preview" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Catalog Preview
        </Link>
      </div>

      {/* Providers Status Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {providers.map((p) => (
          <div
            key={p.provider}
            className="p-5 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-3"
          >
            <div className="flex items-center justify-between">
              <span className="font-bold text-white text-sm">{p.name}</span>
              <span
                className={`flex items-center gap-1 text-[11px] font-semibold px-2 py-0.5 rounded capitalize ${
                  p.status === 'online'
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                    : 'bg-red-950/80 text-red-400 border border-red-800'
                }`}
              >
                {p.status === 'online' ? <CheckCircle2 className="w-3 h-3" /> : <AlertCircle className="w-3 h-3" />}
                {p.status}
              </span>
            </div>

            <p className="text-xs text-slate-400 line-clamp-2">{p.details}</p>

            <div className="grid grid-cols-3 gap-2 text-[11px] bg-[#181B27] p-2.5 rounded-xl border border-[#292D3A]/60">
              <div>
                <span className="text-slate-500 block">Latency</span>
                <span className="text-slate-200 font-mono font-medium">{p.latencyMs}ms</span>
              </div>
              <div>
                <span className="text-slate-500 block">Requests</span>
                <span className="text-slate-200 font-mono font-medium">{p.requestsCount}</span>
              </div>
              <div>
                <span className="text-slate-500 block">Errors</span>
                <span className={`font-mono font-medium ${p.errorCount > 0 ? 'text-red-400' : 'text-slate-200'}`}>
                  {p.errorCount}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Cache & Diagnostics Quick Actions */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="font-bold text-white text-sm flex items-center gap-2">
            <Database className="w-4 h-4 text-[#8B5CF6]" />
            Metadata Cache Management
          </h3>
          <p className="text-xs text-slate-400 mt-0.5">
            Flushes client memory and IndexedDB query caches without clearing user watchlist.
          </p>
        </div>

        <button
          onClick={handleClearCache}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6] text-xs font-semibold text-white transition-colors"
        >
          <Trash2 className="w-3.5 h-3.5 text-slate-400" />
          <span>{cacheCleared ? 'Cache Cleared!' : 'Purge API Cache'}</span>
        </button>
      </div>

      {/* Session Error & Event Logs */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-bold text-white text-sm flex items-center gap-2 font-['Manrope']">
            <Terminal className="w-4 h-4 text-[#38BDF8]" />
            Session Logs & Provider Telemetry
          </h3>

          {logs.length > 0 && (
            <button
              onClick={handleClearLogs}
              className="text-[11px] text-slate-400 hover:text-white"
            >
              Clear Logs
            </button>
          )}
        </div>

        {logs.length === 0 ? (
          <p className="text-xs text-slate-500 py-4 text-center">No errors or events logged in the active browser session.</p>
        ) : (
          <div className="space-y-2 max-h-60 overflow-y-auto font-mono text-xs">
            {logs.map((log) => (
              <div
                key={log.id}
                className="p-2.5 rounded-lg bg-[#090A0F] border border-[#292D3A]/60 flex items-start gap-2"
              >
                <span className="text-slate-500 text-[10px]">
                  {new Date(log.timestamp).toLocaleTimeString()}
                </span>
                <span
                  className={`px-1.5 py-0.2 rounded text-[10px] uppercase font-bold ${
                    log.level === 'error' ? 'bg-red-950 text-red-400' : 'bg-blue-950 text-blue-400'
                  }`}
                >
                  {log.level}
                </span>
                <span className="text-slate-300 break-all">{log.message}</span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
