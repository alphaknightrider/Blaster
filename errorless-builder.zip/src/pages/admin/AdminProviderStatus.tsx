import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { ApiClient } from '../../services/apiClient';
import { providerRegistry } from '../../services/providerRegistry';
import { ProviderHealth } from '../../types';
import { Server, RefreshCw, CheckCircle2, AlertCircle, Clock } from 'lucide-react';

export const AdminProviderStatus: React.FC = () => {
  const [providers, setProviders] = useState<ProviderHealth[]>(() => providerRegistry.getAll());
  const [pinging, setPinging] = useState(false);

  const handleTestAll = async () => {
    setPinging(true);
    try {
      const results = await ApiClient.pingAll();
      setProviders([...results]);
    } finally {
      setPinging(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-6">
      {/* Sub-nav */}
      <div className="flex gap-2 border-b border-[#292D3A] pb-3 text-xs font-semibold">
        <Link to="/admin" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Overview
        </Link>
        <Link to="/admin/provider-status" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-white border border-[#8B5CF6]">
          Provider Status
        </Link>
        <Link to="/admin/api-settings" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          API Settings
        </Link>
        <Link to="/admin/content-preview" className="px-3 py-1.5 rounded-lg bg-[#181B27] text-slate-400 hover:text-white border border-[#292D3A]">
          Catalog Preview
        </Link>
      </div>

      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white font-['Manrope']">Provider Connectivity & Latency</h1>
          <p className="text-xs text-slate-400 mt-1">Live ping testing and response latency benchmarks.</p>
        </div>

        <button
          onClick={handleTestAll}
          disabled={pinging}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-md"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${pinging ? 'animate-spin' : ''}`} />
          <span>Execute Live Ping</span>
        </button>
      </div>

      <div className="space-y-4">
        {providers.map((p) => (
          <div
            key={p.provider}
            className="p-5 rounded-2xl bg-[#11131B] border border-[#292D3A] flex flex-col sm:flex-row sm:items-center justify-between gap-4"
          >
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-bold text-white text-sm">{p.name}</span>
                <span className="text-[10px] text-slate-500 uppercase font-mono">[{p.provider}]</span>
              </div>
              <p className="text-xs text-slate-400">{p.details}</p>
              <div className="flex items-center gap-3 text-[11px] text-slate-500 pt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  Checked: {new Date(p.lastChecked).toLocaleTimeString()}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-4 sm:border-l sm:border-[#292D3A] sm:pl-6">
              <div className="text-right">
                <span className="text-[10px] text-slate-500 uppercase block font-semibold">Latency</span>
                <span className="text-sm font-mono font-bold text-slate-200 tabular-nums">
                  {p.latencyMs} ms
                </span>
              </div>

              <div
                className={`flex items-center gap-1 text-xs font-semibold px-2.5 py-1 rounded-lg capitalize shrink-0 ${
                  p.status === 'online'
                    ? 'bg-emerald-950/80 text-emerald-400 border border-emerald-800'
                    : 'bg-red-950/80 text-red-400 border border-red-800'
                }`}
              >
                {p.status === 'online' ? <CheckCircle2 className="w-3.5 h-3.5" /> : <AlertCircle className="w-3.5 h-3.5" />}
                <span>{p.status}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
