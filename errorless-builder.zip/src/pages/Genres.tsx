import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Tag, Sparkles, ChevronLeft, ChevronRight, SlidersHorizontal, Film, Tv, Flame, Heart } from 'lucide-react';

const GENRE_LIST: { id: number | string; name: string; desc: string; badge?: string }[] = [
  { id: 28, name: 'Action', desc: 'Explosive chases, martial arts, high-velocity confrontations' },
  { id: 10749, name: 'Romance & Love', desc: 'Passionate connections, intimate heartbreak, chemistry, and romantic comedies', badge: 'Popular' },
  { id: '18_mature', name: '🔞 18+ Adult & Mature', desc: 'Mature 18+ cinema, sensual encounters, unrated director cuts, psychological desire', badge: '18+ Mature' },
  { id: 12, name: 'Adventure', desc: 'Epic quests, uncharted landscapes, heroic expeditions' },
  { id: 16, name: 'Animation', desc: 'Hand-drawn, CGI, and stop-motion masterworks' },
  { id: 35, name: 'Comedy', desc: 'Satire, screwball humor, dark comedic masteries' },
  { id: 80, name: 'Crime', desc: 'Neo-noir, heist thrillers, mobster syndicates' },
  { id: 99, name: 'Documentary', desc: 'Real life phenomena, ecological retrospectives, truth' },
  { id: 18, name: 'Drama', desc: 'Deep character studies, emotional human narratives' },
  { id: 14, name: 'Fantasy', desc: 'Mythological realms, magical odysseys, arcane realms' },
  { id: 27, name: 'Horror', desc: 'Psychological terror, creature features, gothic dread' },
  { id: 9648, name: 'Mystery', desc: 'Whodunits, forensic suspense, labyrinthine puzzles' },
  { id: 878, name: 'Sci-Fi', desc: 'Speculative futures, interstellar spaceflight, cybernetics' },
  { id: 53, name: 'Thriller', desc: 'Edge-of-your-seat suspense, tension, psychological twists' },
  { id: 37, name: 'Western', desc: 'Frontier lore, dusty showdowns, outlaw justice' },
];

export const Genres: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const rawGenreParam = searchParams.get('id') || '28';
  const selectedGenreId: number | string = rawGenreParam === '18_mature' ? '18_mature' : (parseInt(rawGenreParam, 10) || 28);

  const [mediaType, setMediaType] = useState<'movie' | 'tv'>('movie');
  const [page, setPage] = useState(1);
  const [sortBy, setSortBy] = useState<'popularity.desc' | 'vote_average.desc' | 'primary_release_date.desc'>('popularity.desc');
  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  const selectedGenre = GENRE_LIST.find((g) => String(g.id) === String(selectedGenreId)) || GENRE_LIST[0];

  useEffect(() => {
    let cancelled = false;
    const load = async () => {
      setLoading(true);
      try {
        const isAdult = selectedGenreId === '18_mature';
        const res = await ApiClient.discover({
          genreId: isAdult ? 10749 : selectedGenreId,
          type: mediaType,
          sortBy,
          page,
          includeAdult: isAdult,
        } as any);
        if (!cancelled) setItems(res);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    load();
    return () => {
      cancelled = true;
    };
  }, [selectedGenreId, mediaType, sortBy, page]);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-[#292D3A] pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs font-bold text-[#A78BFA] uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
            <span>Genre Intelligence Compendium</span>
          </div>
          <h1 className="text-3xl sm:text-5xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Tag className="w-8 h-8 text-[#8B5CF6]" />
            Cinema & Television Genres
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl">
            Curated film movements, 18+ adult & mature romance, and stylistic genres across 100,000+ titles.
          </p>
        </div>

        <div className="flex items-center gap-2 px-4 py-2 rounded-2xl bg-[#11131B] border border-[#292D3A] text-xs font-bold text-slate-300">
          <span className="w-2 h-2 rounded-full bg-[#8B5CF6] animate-pulse" />
          <span>100,000+ Genre Archive</span>
        </div>
      </div>

      {/* Genre selection buttons */}
      <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-none">
        {GENRE_LIST.map((g) => (
          <button
            key={String(g.id)}
            onClick={() => {
              setSearchParams({ id: g.id.toString() });
              setPage(1);
            }}
            className={`px-4 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all border cursor-pointer flex items-center gap-1.5 ${
              String(selectedGenreId) === String(g.id)
                ? g.id === '18_mature'
                  ? 'bg-rose-600 text-white border-rose-500 shadow-lg shadow-rose-600/20'
                  : 'bg-[#8B5CF6] text-white border-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 border-[#292D3A] hover:border-slate-500'
            }`}
          >
            <span>{g.name}</span>
            {g.badge && (
              <span className={`text-[9px] px-1 py-0.2 rounded font-extrabold ${g.id === '18_mature' ? 'bg-black/40 text-rose-300' : 'bg-black/30 text-amber-300'}`}>
                {g.badge}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Selected Genre Banner & Controls */}
      <div className="p-6 rounded-2xl bg-[#11131B] border border-[#292D3A] flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-bold text-[#8B5CF6] uppercase tracking-wider">Active Category</span>
          <h2 className="text-2xl font-bold text-white font-['Manrope'] mt-0.5">{selectedGenre.name}</h2>
          <p className="text-xs text-slate-400 mt-1">{selectedGenre.desc}</p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          {/* Format Toggle (Movies vs TV) */}
          <div className="flex items-center p-1 rounded-xl bg-[#181B27] border border-[#292D3A]">
            <button
              onClick={() => {
                setMediaType('movie');
                setPage(1);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mediaType === 'movie' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Film className="w-3.5 h-3.5" />
              <span>Movies</span>
            </button>
            <button
              onClick={() => {
                setMediaType('tv');
                setPage(1);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                mediaType === 'tv' ? 'bg-[#8B5CF6] text-white shadow-md' : 'text-slate-400 hover:text-white'
              }`}
            >
              <Tv className="w-3.5 h-3.5" />
              <span>TV Series</span>
            </button>
          </div>

          {/* Sort Selector */}
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-3.5 h-3.5 text-slate-400" />
            <select
              value={sortBy}
              onChange={(e) => {
                setSortBy(e.target.value as any);
                setPage(1);
              }}
              className="bg-[#181B27] border border-[#292D3A] text-white text-xs rounded-xl px-3 py-2 focus:outline-none focus:border-[#8B5CF6] cursor-pointer"
            >
              <option value="popularity.desc">Most Popular</option>
              <option value="vote_average.desc">Highest Rated</option>
              <option value="primary_release_date.desc">Latest Release</option>
            </select>
          </div>
        </div>
      </div>

      {/* Titles Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
          <Tag className="w-12 h-12 mx-auto text-slate-600 mb-2" />
          <h3 className="text-lg font-bold text-white">No Titles Found</h3>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((title) => (
            <MovieCard key={title.id} title={title} />
          ))}
        </div>
      )}

      {/* Pagination Controls */}
      <div className="flex flex-wrap items-center justify-center gap-2 pt-6">
        <button
          onClick={() => {
            setPage((p) => Math.max(1, p - 1));
            window.scrollTo({ top: 300, behavior: 'smooth' });
          }}
          disabled={page <= 1 || loading}
          className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-semibold disabled:opacity-30 disabled:cursor-not-allowed transition-colors cursor-pointer"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        {[1, 2, 3, 4, 5].map((pageNum) => (
          <button
            key={pageNum}
            onClick={() => {
              setPage(pageNum);
              window.scrollTo({ top: 300, behavior: 'smooth' });
            }}
            className={`w-9 h-9 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              page === pageNum
                ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            {pageNum}
          </button>
        ))}

        {page > 5 && (
          <span className="w-9 h-9 flex items-center justify-center text-xs font-bold text-white bg-[#8B5CF6] rounded-xl">
            {page}
          </span>
        )}

        <span className="text-slate-500 text-xs px-1">...</span>

        <button
          onClick={() => {
            setPage(500);
            window.scrollTo({ top: 300, behavior: 'smooth' });
          }}
          className="px-3 h-9 rounded-xl bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-bold transition-colors cursor-pointer"
        >
          500+
        </button>

        <button
          onClick={() => {
            setPage((p) => p + 1);
            window.scrollTo({ top: 300, behavior: 'smooth' });
          }}
          disabled={loading}
          className="flex items-center gap-1 px-4 py-2 rounded-xl bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-md shadow-[#8B5CF6]/20 cursor-pointer"
        >
          <span>Next Page</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
