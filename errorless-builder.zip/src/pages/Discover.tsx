import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Filter, SlidersHorizontal, ChevronLeft, ChevronRight, Loader2 } from 'lucide-react';

const GENRES = [
  { id: '', name: 'All Genres' },
  { id: 28, name: 'Action' },
  { id: 12, name: 'Adventure' },
  { id: 16, name: 'Animation' },
  { id: 35, name: 'Comedy' },
  { id: 80, name: 'Crime' },
  { id: 99, name: 'Documentary' },
  { id: 18, name: 'Drama' },
  { id: 14, name: 'Fantasy' },
  { id: 27, name: 'Horror' },
  { id: 9648, name: 'Mystery' },
  { id: 10749, name: 'Romance' },
  { id: 878, name: 'Science Fiction' },
  { id: 53, name: 'Thriller' },
];

const LANGUAGES = [
  { code: '', label: 'All Languages' },
  { code: 'en', label: 'English' },
  { code: 'hi', label: 'Hindi' },
  { code: 'ja', label: 'Japanese' },
  { code: 'ko', label: 'Korean' },
  { code: 'es', label: 'Spanish' },
  { code: 'fr', label: 'French' },
];

export const Discover: React.FC = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  const [type, setType] = useState<'movie' | 'tv'>(
    (searchParams.get('type') as any) || 'movie'
  );
  const [genreId, setGenreId] = useState<string>(searchParams.get('genre') || '');
  const [language, setLanguage] = useState<string>(searchParams.get('lang') || '');
  const [year, setYear] = useState<string>(searchParams.get('year') || '');
  const [sortBy, setSortBy] = useState<string>(searchParams.get('sort') || 'popularity.desc');
  const [page, setPage] = useState<number>(parseInt(searchParams.get('page') || '1', 10));

  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let isCancelled = false;

    const fetchDiscover = async () => {
      setLoading(true);
      try {
        const results = await ApiClient.discover({
          type,
          genreId: genreId ? parseInt(genreId, 10) : undefined,
          language: language || undefined,
          year: year ? parseInt(year, 10) : undefined,
          sortBy,
          page,
        });

        if (!isCancelled) {
          setItems(results);
        }
      } catch {
        if (!isCancelled) setItems([]);
      } finally {
        if (!isCancelled) setLoading(false);
      }
    };

    fetchDiscover();

    return () => {
      isCancelled = true;
    };
  }, [type, genreId, language, year, sortBy, page]);

  // Sync to URL params
  const handleFilterChange = (updates: Record<string, string | number>) => {
    const nextParams = new URLSearchParams(searchParams);
    Object.entries(updates).forEach(([key, val]) => {
      if (val) {
        nextParams.set(key, String(val));
      } else {
        nextParams.delete(key);
      }
    });
    setSearchParams(nextParams);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight">
          Cinema Discovery Engine
        </h1>
        <p className="text-sm text-slate-400 mt-1">
          Explore global cinema catalogs through multi-attribute provider discovery.
        </p>
      </div>

      {/* Filter Control Bar */}
      <div className="p-4 rounded-2xl bg-[#11131B] border border-[#292D3A] mb-8 space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#292D3A]/60">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-300">
            <SlidersHorizontal className="w-4 h-4 text-[#8B5CF6]" />
            <span>Search Parameters</span>
          </div>

          {/* Media Type Toggle */}
          <div className="flex items-center gap-1 p-1 bg-[#181B27] rounded-lg border border-[#292D3A]">
            <button
              onClick={() => {
                setType('movie');
                setPage(1);
                handleFilterChange({ type: 'movie', page: 1 });
              }}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                type === 'movie' ? 'bg-[#8B5CF6] text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              Movies
            </button>
            <button
              onClick={() => {
                setType('tv');
                setPage(1);
                handleFilterChange({ type: 'tv', page: 1 });
              }}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors ${
                type === 'tv' ? 'bg-[#8B5CF6] text-white shadow-sm' : 'text-slate-400 hover:text-white'
              }`}
            >
              TV Series
            </button>
          </div>
        </div>

        {/* Filter Dropdowns */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          {/* Genre */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Genre</label>
            <select
              value={genreId}
              onChange={(e) => {
                setGenreId(e.target.value);
                setPage(1);
                handleFilterChange({ genre: e.target.value, page: 1 });
              }}
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2 focus:outline-none focus:border-[#8B5CF6]"
            >
              {GENRES.map((g) => (
                <option key={g.id} value={g.id}>
                  {g.name}
                </option>
              ))}
            </select>
          </div>

          {/* Language */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Original Language</label>
            <select
              value={language}
              onChange={(e) => {
                setLanguage(e.target.value);
                setPage(1);
                handleFilterChange({ lang: e.target.value, page: 1 });
              }}
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2 focus:outline-none focus:border-[#8B5CF6]"
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.label}
                </option>
              ))}
            </select>
          </div>

          {/* Release Year */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Release Year</label>
            <select
              value={year}
              onChange={(e) => {
                setYear(e.target.value);
                setPage(1);
                handleFilterChange({ year: e.target.value, page: 1 });
              }}
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2 focus:outline-none focus:border-[#8B5CF6]"
            >
              <option value="">Any Year</option>
              {[2026, 2025, 2024, 2023, 2022, 2020, 2015, 2010, 2000, 1990, 1980, 1970].map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          {/* Sort By */}
          <div>
            <label className="block text-slate-400 mb-1 font-medium">Sort Order</label>
            <select
              value={sortBy}
              onChange={(e) => {
                setSortBy(e.target.value);
                setPage(1);
                handleFilterChange({ sort: e.target.value, page: 1 });
              }}
              className="w-full bg-[#181B27] border border-[#292D3A] text-white rounded-lg p-2 focus:outline-none focus:border-[#8B5CF6]"
            >
              <option value="popularity.desc">Most Popular</option>
              <option value="vote_average.desc">Highest Rated</option>
              <option value="primary_release_date.desc">Newest Releases</option>
              <option value="vote_count.desc">Most Reviewed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Grid or Skeletons */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="py-20 text-center rounded-2xl bg-[#11131B] border border-[#292D3A] text-slate-400">
          <Filter className="w-10 h-10 mx-auto text-slate-500 mb-2" />
          <p className="font-semibold text-white text-base">No titles match these parameters</p>
          <p className="text-xs text-slate-400 mt-1">Try resetting the language or year filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      )}

      {/* Pagination Bar */}
      <div className="mt-12 flex items-center justify-center gap-4">
        <button
          disabled={page <= 1 || loading}
          onClick={() => {
            const next = Math.max(1, page - 1);
            setPage(next);
            handleFilterChange({ page: next });
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs font-medium text-slate-300 hover:text-white disabled:opacity-40 disabled:hover:text-slate-300 transition-colors"
        >
          <ChevronLeft className="w-4 h-4" />
          <span>Previous</span>
        </button>

        <span className="text-xs text-slate-400 font-medium">
          Page <strong className="text-white tabular-nums">{page}</strong>
        </span>

        <button
          disabled={loading || items.length < 10}
          onClick={() => {
            const next = page + 1;
            setPage(next);
            handleFilterChange({ page: next });
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs font-medium text-slate-300 hover:text-white disabled:opacity-40 disabled:hover:text-slate-300 transition-colors"
        >
          <span>Next</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
