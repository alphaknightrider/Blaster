import React, { useEffect, useState } from 'react';
import { ApiClient } from '../services/apiClient';
import { NormalizedTitle } from '../types';
import { MovieCard } from '../components/movie/MovieCard';
import { Sparkles, RefreshCw } from 'lucide-react';

export const RecommendationsPage: React.FC = () => {
  const [items, setItems] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(true);

  const loadRecs = async () => {
    setLoading(true);
    try {
      const recs = await ApiClient.getPersonalizedRecommendations(20);
      setItems(recs);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadRecs();
  }, []);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16 min-h-screen">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope'] tracking-tight flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-[#8B5CF6]" />
            Personalized Cinema Recommendations
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Algorithmically generated from your local watchlist and viewed genres without cloud tracking.
          </p>
        </div>

        <button
          onClick={loadRecs}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs font-semibold text-slate-300 hover:text-white hover:border-[#8B5CF6] transition-colors self-start sm:self-auto"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Recommendations</span>
        </button>
      </div>

      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {Array.from({ length: 15 }).map((_, i) => (
            <div key={i} className="aspect-[2/3] rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
          {items.map((item) => (
            <MovieCard key={item.id} title={item} />
          ))}
        </div>
      )}
    </div>
  );
};
