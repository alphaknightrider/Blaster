import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AppProvider } from './context/AppContext';
import { Header } from './components/layout/Header';
import { BottomNav } from './components/layout/BottomNav';
import { AnnouncementBar } from './components/layout/AnnouncementBar';
import { Footer } from './components/layout/Footer';
import { SearchModal } from './components/search/SearchModal';

// Pages
import { Home } from './pages/Home';
import { VegaMoviesPage } from './pages/VegaMoviesPage';
import { Discover } from './pages/Discover';
import { Movies } from './pages/Movies';
import { TvShows } from './pages/TvShows';
import { Anime } from './pages/Anime';
import { CartoonsPage } from './pages/CartoonsPage';
import { Documentaries } from './pages/Documentaries';
import { ShortFilms } from './pages/ShortFilms';
import { ShortDramaPage } from './pages/ShortDramaPage';
import { Trending } from './pages/Trending';
import { Popular } from './pages/Popular';
import { TopRated } from './pages/TopRated';
import { Upcoming } from './pages/Upcoming';
import { Genres } from './pages/Genres';
import { Languages } from './pages/Languages';
import { SearchPage } from './pages/SearchPage';
import { MovieDetails } from './pages/MovieDetails';
import { TvDetails } from './pages/TvDetails';
import { WatchPage } from './pages/WatchPage';
import { WatchlistPage } from './pages/WatchlistPage';
import { HistoryPage } from './pages/HistoryPage';
import { ContinueWatchingPage } from './pages/ContinueWatchingPage';
import { RecommendationsPage } from './pages/RecommendationsPage';
import { SettingsPage } from './pages/SettingsPage';
import { AboutPage } from './pages/AboutPage';
import { PrivacyPage } from './pages/PrivacyPage';
import { TermsPage } from './pages/TermsPage';

// Admin Pages
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { AdminApiSettings } from './pages/admin/AdminApiSettings';
import { AdminProviderStatus } from './pages/admin/AdminProviderStatus';
import { AdminContentPreview } from './pages/admin/AdminContentPreview';

export default function App() {
  return (
    <BrowserRouter>
      <AppProvider>
        <div className="min-h-screen bg-[#090A0F] text-[#F8FAFC] flex flex-col font-['Inter',sans-serif]">
          {/* Top Announcement Bar */}
          <AnnouncementBar />

          {/* Cinematic Floating / Glass Header */}
          <Header />

          {/* Global Interactive Search Modal */}
          <SearchModal />

          {/* Main Routing Views */}
          <main className="flex-1">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/vegamovies" element={<VegaMoviesPage />} />
              <Route path="/discover" element={<Discover />} />
              <Route path="/movies" element={<Movies />} />
              <Route path="/tv" element={<TvShows />} />
              <Route path="/anime" element={<Anime />} />
              <Route path="/cartoons" element={<CartoonsPage />} />
              <Route path="/reels" element={<ShortDramaPage />} />
              <Route path="/shortdrama" element={<ShortDramaPage />} />
              <Route path="/documentaries" element={<Documentaries />} />
              <Route path="/short-films" element={<ShortFilms />} />
              <Route path="/trending" element={<Trending />} />
              <Route path="/popular" element={<Popular />} />
              <Route path="/top-rated" element={<TopRated />} />
              <Route path="/upcoming" element={<Upcoming />} />
              <Route path="/genres" element={<Genres />} />
              <Route path="/languages" element={<Languages />} />
              <Route path="/search" element={<SearchPage />} />

              {/* Title Detail Views */}
              <Route path="/movie/:id" element={<MovieDetails />} />
              <Route path="/tv/:id" element={<TvDetails />} />

              {/* Video Player & Streaming View */}
              <Route path="/watch/:type/:id" element={<WatchPage />} />

              {/* User Local Persistence Views */}
              <Route path="/watchlist" element={<WatchlistPage />} />
              <Route path="/history" element={<HistoryPage />} />
              <Route path="/continue-watching" element={<ContinueWatchingPage />} />
              <Route path="/recommendations" element={<RecommendationsPage />} />
              <Route path="/settings" element={<SettingsPage />} />

              {/* Information & Legal */}
              <Route path="/about" element={<AboutPage />} />
              <Route path="/privacy" element={<PrivacyPage />} />
              <Route path="/terms" element={<TermsPage />} />

              {/* Diagnostic Local Admin Console */}
              <Route path="/admin" element={<AdminDashboard />} />
              <Route path="/admin/api-settings" element={<AdminApiSettings />} />
              <Route path="/admin/provider-status" element={<AdminProviderStatus />} />
              <Route path="/admin/content-preview" element={<AdminContentPreview />} />

              {/* Fallback */}
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </main>

          {/* Mobile Bottom Navigation */}
          <BottomNav />

          {/* Footer */}
          <Footer />
        </div>
      </AppProvider>
    </BrowserRouter>
  );
}
