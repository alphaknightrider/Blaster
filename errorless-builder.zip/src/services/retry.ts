export interface RetryOptions {
  retries?: number;
  backoffMs?: number;
  timeoutMs?: number;
  signal?: AbortSignal;
}

export async function fetchWithRetry<T>(
  fn: (signal: AbortSignal) => Promise<T>,
  options: RetryOptions = {}
): Promise<T> {
  const { retries = 2, backoffMs = 800, timeoutMs = 10000, signal: externalSignal } = options;

  let attempt = 0;
  let lastError: any;

  while (attempt <= retries) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

    // Chain external abort signal if provided
    const onExternalAbort = () => controller.abort();
    if (externalSignal) {
      externalSignal.addEventListener('abort', onExternalAbort);
    }

    try {
      const result = await fn(controller.signal);
      clearTimeout(timeoutId);
      if (externalSignal) {
        externalSignal.removeEventListener('abort', onExternalAbort);
      }
      return result;
    } catch (err: any) {
      clearTimeout(timeoutId);
      if (externalSignal) {
        externalSignal.removeEventListener('abort', onExternalAbort);
      }

      if (err.name === 'AbortError' && externalSignal?.aborted) {
        throw new Error('Request was cancelled');
      }

      lastError = err;
      attempt++;

      if (attempt <= retries) {
        const delay = backoffMs * Math.pow(2, attempt - 1);
        await new Promise((res) => setTimeout(res, delay));
      }
    }
  }

  throw lastError || new Error('Request failed after retries');
}
