import { NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const ANILIST_GRAPHQL_ENDPOINT = 'https://graphql.anilist.co';
const KITSU_BASE_URL = 'https://kitsu.io/api/edge';
const JIKAN_BASE_URL = 'https://api.jikan.moe/v4';

const ANILIST_QUERY = `
query ($page: Int, $perPage: Int, $search: String, $sort: [MediaSort]) {
  Page(page: $page, perPage: $perPage) {
    media(search: $search, sort: $sort, type: ANIME) {
      id
      idMal
      title {
        romaji
        english
        native
      }
      coverImage {
        extraLarge
        large
        medium
      }
      bannerImage
      description
      seasonYear
      startDate {
        year
        month
        day
      }
      episodes
      duration
      status
      genres
      averageScore
      popularity
      trailer {
        id
        site
      }
      studios(isMain: true) {
        nodes {
          name
        }
      }
    }
  }
}
`;

export class AnimeHubProvider {
  // Get trending and popular anime via AniList with Kitsu fallback
  static async getTrendingAnime(page = 1, perPage = 25): Promise<NormalizedTitle[]> {
    const cacheKey = `anime:trending:${page}:${perPage}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const res = await fetch(ANILIST_GRAPHQL_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          query: ANILIST_QUERY,
          variables: {
            page,
            perPage,
            sort: ['POPULARITY_DESC', 'SCORE_DESC'],
          },
        }),
      });

      if (!res.ok) throw new Error(`AniList HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('anilist', latency);

      const mediaList = data?.data?.Page?.media || [];
      const normalized = mediaList.map((m: any) => TitleNormalizer.normalizeAniList(m));

      await cache.set(cacheKey, normalized, 3600 * 1000);
      return normalized;
    } catch (err: any) {
      providerRegistry.recordError('anilist', err.message || 'AniList query error');
      // Fallback to Kitsu API
      return this.getKitsuTrending(page);
    }
  }

  // Get Top Rated Anime
  static async getTopRatedAnime(page = 1, perPage = 25): Promise<NormalizedTitle[]> {
    const cacheKey = `anime:top_rated:${page}:${perPage}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    try {
      const res = await fetch(ANILIST_GRAPHQL_ENDPOINT, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          query: ANILIST_QUERY,
          variables: {
            page,
            perPage,
            sort: ['SCORE_DESC'],
          },
        }),
      });

      if (!res.ok) throw new Error(`AniList HTTP ${res.status}`);
      const data = await res.json();
      const mediaList = data?.data?.Page?.media || [];
      const normalized = mediaList.map((m: any) => TitleNormalizer.normalizeAniList(m));

      await cache.set(cacheKey, normalized, 3600 * 1000);
      return normalized;
    } catch {
      return this.getKitsuTrending(page);
    }
  }

  // Search Anime across AniList & Kitsu
  static async search(query: string, signal?: AbortSignal): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];
    const cacheKey = `anime:search:${query.toLowerCase()}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const res = await fetch(ANILIST_GRAPHQL_ENDPOINT, {
        method: 'POST',
        signal,
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          query: ANILIST_QUERY,
          variables: {
            search: query,
            page: 1,
            perPage: 20,
            sort: ['SEARCH_MATCH'],
          },
        }),
      });

      if (!res.ok) throw new Error(`AniList search HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('anilist', latency);

      const mediaList = data?.data?.Page?.media || [];
      const normalized = mediaList.map((m: any) => TitleNormalizer.normalizeAniList(m));

      await cache.set(cacheKey, normalized, 1800 * 1000);
      return normalized;
    } catch (err: any) {
      providerRegistry.recordError('anilist', err.message || 'Search error');
      return this.searchKitsu(query);
    }
  }

  // Fallback Kitsu Trending
  private static async getKitsuTrending(page = 1): Promise<NormalizedTitle[]> {
    const offset = (page - 1) * 20;
    try {
      const res = await fetch(`${KITSU_BASE_URL}/trending/anime?page[limit]=20&page[offset]=${offset}`);
      if (!res.ok) return [];
      const data = await res.json();
      providerRegistry.recordSuccess('kitsu', 90);
      return (data?.data || []).map((k: any) => TitleNormalizer.normalizeKitsu(k));
    } catch {
      return [];
    }
  }

  // Fallback Kitsu Search
  private static async searchKitsu(query: string): Promise<NormalizedTitle[]> {
    try {
      const res = await fetch(`${KITSU_BASE_URL}/anime?filter[text]=${encodeURIComponent(query)}&page[limit]=20`);
      if (!res.ok) return [];
      const data = await res.json();
      providerRegistry.recordSuccess('kitsu', 110);
      return (data?.data || []).map((k: any) => TitleNormalizer.normalizeKitsu(k));
    } catch {
      return [];
    }
  }

  // Get details for anime by AniList ID
  static async getDetails(anilistId: number | string): Promise<NormalizedTitle | null> {
    const cleanId = parseInt(String(anilistId).replace(/^anilist:/, ''), 10);
    if (!cleanId) return null;

    const cacheKey = `anime:details:${cleanId}`;
    const cached = await cache.get<NormalizedTitle>(cacheKey);
    if (cached) return cached;

    try {
      const res = await fetch(ANILIST_GRAPHQL_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: `
            query ($id: Int) {
              Media(id: $id, type: ANIME) {
                id
                idMal
                title { romaji english native }
                coverImage { extraLarge large }
                bannerImage
                description
                seasonYear
                startDate { year month day }
                episodes
                duration
                status
                genres
                averageScore
                trailer { id site }
                studios(isMain: true) { nodes { name } }
              }
            }
          `,
          variables: { id: cleanId },
        }),
      });

      if (!res.ok) return null;
      const data = await res.json();
      const media = data?.data?.Media;
      if (!media) return null;

      const norm = TitleNormalizer.normalizeAniList(media);
      await cache.set(cacheKey, norm, 3600 * 1000);
      return norm;
    } catch {
      return null;
    }
  }
}
