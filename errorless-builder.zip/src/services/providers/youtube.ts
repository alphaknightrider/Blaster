import { VideoItem } from '../../types';
import { StorageManager } from '../../storage';
import { providerRegistry } from '../providerRegistry';

const YOUTUBE_API_BASE = 'https://www.googleapis.com/youtube/v3';

export class YoutubeProvider {
  private static getKey(): string {
    const settings = StorageManager.getSettings();
    if (settings.youtubeApiKey && settings.youtubeApiKey.trim()) {
      return settings.youtubeApiKey.trim();
    }
    const envKey = (import.meta as any).env?.VITE_YOUTUBE_API_KEY;
    return envKey ? envKey.trim() : '';
  }

  // Search official trailer if not already provided by TMDB
  static async searchTrailer(title: string, year?: number): Promise<VideoItem | null> {
    const key = this.getKey();
    if (!key) return null;

    try {
      const q = `${title} ${year || ''} official trailer`;
      const url = `${YOUTUBE_API_BASE}/search?part=snippet&maxResults=1&q=${encodeURIComponent(q)}&type=video&videoEmbeddable=true&key=${key}`;
      const res = await fetch(url);
      if (!res.ok) return null;
      const data = await res.json();
      const item = data.items?.[0];
      if (!item) return null;

      providerRegistry.recordSuccess('youtube', 75);
      return {
        id: item.id.videoId,
        key: item.id.videoId,
        name: item.snippet.title,
        site: 'YouTube',
        type: 'Trailer',
        official: true,
      };
    } catch {
      return null;
    }
  }

  static getEmbedUrl(key: string, autoplay = true): string {
    return `https://www.youtube-nocookie.com/embed/${key}?autoplay=${autoplay ? 1 : 0}&modestbranding=1&rel=0&iv_load_policy=3`;
  }

  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const key = this.getKey();
    if (!key) {
      return { ok: true, latencyMs: 30, message: 'Official Iframe Embed Player is active (Direct API key optional)' };
    }
    const start = performance.now();
    try {
      const res = await fetch(`${YOUTUBE_API_BASE}/videos?part=snippet&id=dQw4w9WgXcQ&key=${key}`);
      const latency = Math.round(performance.now() - start);
      if (res.ok) {
        providerRegistry.recordSuccess('youtube', latency);
        return { ok: true, latencyMs: latency, message: 'YouTube Data API v3 connected' };
      }
      return { ok: false, latencyMs: latency, message: `Status code ${res.status}` };
    } catch (err: any) {
      return { ok: false, latencyMs: 0, message: err.message };
    }
  }
}
