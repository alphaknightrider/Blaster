import { cache } from '../cache';

const MYMEMORY_API = 'https://api.mymemory.translated.net/get';

export class TranslationProvider {
  // Translate synopsis text to requested language
  static async translateText(text: string, targetLang: string): Promise<string> {
    if (!text || !text.trim() || targetLang === 'en') return text;

    // Limit text length to 400 characters to stay within quick response limits
    const truncated = text.slice(0, 400);
    const cacheKey = `trans:${targetLang}:${truncated}`;
    const cached = await cache.get<string>(cacheKey);
    if (cached) return cached;

    try {
      const url = `${MYMEMORY_API}?q=${encodeURIComponent(truncated)}&langpair=en|${targetLang}`;
      const res = await fetch(url);
      if (!res.ok) return text;
      const data = await res.json();
      const translation = data?.responseData?.translatedText;
      if (translation && typeof translation === 'string') {
        await cache.set(cacheKey, translation, 86400 * 1000);
        return translation;
      }
      return text;
    } catch {
      return text;
    }
  }
}
