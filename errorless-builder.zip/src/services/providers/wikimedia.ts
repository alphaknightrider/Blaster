import { NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const WIKIPEDIA_API = 'https://en.wikipedia.org/w/api.php';
const WIKIMEDIA_COMMONS_API = 'https://commons.wikimedia.org/w/api.php';

export class WikimediaProvider {
  // Get Wikipedia encyclopedia summary and trivia for any movie
  static async getMovieSummary(title: string, year?: number): Promise<{
    extract?: string;
    pageUrl?: string;
    thumbnail?: string;
  } | null> {
    const query = year ? `${title} (${year} film)` : `${title} film`;
    const cacheKey = `wiki:summary:${query.toLowerCase()}`;
    const cached = await cache.get<any>(cacheKey);
    if (cached) return cached;

    try {
      const url = `${WIKIPEDIA_API}?action=query&prop=extracts|pageimages|info&inprop=url&exintro=1&explaintext=1&piprop=thumbnail&pithumbsize=600&titles=${encodeURIComponent(query)}&format=json&origin=*`;
      const res = await fetch(url);
      if (!res.ok) return null;
      const data = await res.json();
      const pages = data?.query?.pages || {};
      const pageId = Object.keys(pages)[0];
      if (!pageId || pageId === '-1') return null;

      const page = pages[pageId];
      const result = {
        extract: page.extract,
        pageUrl: page.fullurl,
        thumbnail: page.thumbnail?.source,
      };

      await cache.set(cacheKey, result, 86400 * 1000);
      return result;
    } catch {
      return null;
    }
  }

  // Search historical public domain video reels on Wikimedia Commons
  static async searchCommonsVideos(query = 'silent film'): Promise<NormalizedTitle[]> {
    const cacheKey = `commons:videos:${query.toLowerCase()}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const url = `${WIKIMEDIA_COMMONS_API}?action=query&list=search&srsearch=${encodeURIComponent(query + ' filetype:video')}&srnamespace=6&format=json&origin=*`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`Wikimedia HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('wikimedia', latency);

      const items: NormalizedTitle[] = (data?.query?.search || []).slice(0, 15).map((item: any) => {
        const rawTitle = item.title.replace(/^File:/, '').replace(/\.[^/.]+$/, '').replace(/_/g, ' ');
        return {
          id: `commons:${item.pageid}`,
          rawId: String(item.pageid),
          provider: 'wikimedia',
          mediaType: 'short',
          title: rawTitle,
          overview: item.snippet ? item.snippet.replace(/<[^>]*>/g, '').trim() : 'Preserved open educational motion picture from Wikimedia Commons.',
          poster: '/assets/images/cyrus_brand_logo_1790781674754.jpg',
          backdrop: '/assets/images/cyrus_hero_backdrop_1790781652435.jpg',
          releaseDate: '1920',
          year: 1920,
          genres: [{ id: 'historical', name: 'Historical Archive' }, { id: 'public-domain', name: 'Public Domain' }],
          rating: 7.9,
          language: 'Silent / English',
          availability: {
            free: true,
            publicDomain: true,
            streamUrl: `https://commons.wikimedia.org/wiki/${encodeURIComponent(item.title)}`,
            officialPage: `https://commons.wikimedia.org/wiki/${encodeURIComponent(item.title)}`,
            downloadOptions: [
              {
                format: 'Wikimedia Commons Master File',
                quality: 'Original Open Source',
                size: 'Variable',
                url: `https://commons.wikimedia.org/wiki/${encodeURIComponent(item.title)}`,
                source: 'Wikimedia Commons',
                license: 'Creative Commons / Public Domain',
              },
            ],
          },
        };
      });

      await cache.set(cacheKey, items, 3600 * 1000);
      return items;
    } catch (err: any) {
      providerRegistry.recordError('wikimedia', err.message || 'Wikimedia error');
      return [];
    }
  }
}
