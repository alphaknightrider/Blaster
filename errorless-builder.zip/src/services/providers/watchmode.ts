import { WatchProviderItem } from '../../types';
import { StorageManager } from '../../storage';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const WATCHMODE_BASE = 'https://api.watchmode.com/v1';

export class WatchmodeProvider {
  private static getKey(): string {
    const settings = StorageManager.getSettings();
    if (settings.watchmodeApiKey && settings.watchmodeApiKey.trim()) {
      return settings.watchmodeApiKey.trim();
    }
    const envKey = (import.meta as any).env?.VITE_WATCHMODE_API_KEY;
    return envKey ? envKey.trim() : '';
  }

  static async getSources(title: string, imdbId?: string): Promise<WatchProviderItem[]> {
    const key = this.getKey();
    if (!key) {
      // Unconfigured, return empty and let TMDB watch providers take priority
      return [];
    }

    const cacheKey = `watchmode:${imdbId || title}`;
    const cached = await cache.get<WatchProviderItem[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      let titleId: number | null = null;
      if (imdbId) {
        const searchRes = await fetch(`${WATCHMODE_BASE}/title/${imdbId}/details/?apiKey=${key}`);
        if (searchRes.ok) {
          const detail = await searchRes.json();
          titleId = detail.id;
        }
      }

      if (!titleId) {
        const searchRes = await fetch(`${WATCHMODE_BASE}/autocomplete-search/?apiKey=${key}&search_value=${encodeURIComponent(title)}&search_type=1`);
        if (searchRes.ok) {
          const searchData = await searchRes.json();
          titleId = searchData.results?.[0]?.id;
        }
      }

      if (!titleId) return [];

      const sourcesRes = await fetch(`${WATCHMODE_BASE}/title/${titleId}/sources/?apiKey=${key}`);
      if (!sourcesRes.ok) return [];

      const sources = await sourcesRes.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('watchmode', latency);

      const items: WatchProviderItem[] = sources.map((s: any) => ({
        providerName: s.name,
        type: s.type === 'sub' ? 'flatrate' : (s.type === 'rent' ? 'rent' : 'buy'),
        url: s.web_url,
      }));

      await cache.set(cacheKey, items, 24 * 3600 * 1000);
      return items;
    } catch (err: any) {
      providerRegistry.recordError('watchmode', err.message);
      return [];
    }
  }

  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const key = this.getKey();
    if (!key) {
      return { ok: false, latencyMs: 0, message: 'No Watchmode API key configured (Optional)' };
    }
    const startTime = performance.now();
    try {
      const res = await fetch(`${WATCHMODE_BASE}/status/?apiKey=${key}`);
      const latencyMs = Math.round(performance.now() - startTime);
      if (res.ok) {
        providerRegistry.recordSuccess('watchmode', latencyMs);
        return { ok: true, latencyMs, message: 'Watchmode API operational' };
      }
      return { ok: false, latencyMs, message: `Status code ${res.status}` };
    } catch (err: any) {
      return { ok: false, latencyMs: 0, message: err.message };
    }
  }
}
