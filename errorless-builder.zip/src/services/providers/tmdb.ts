import { MediaType, NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { fetchWithRetry } from '../retry';
import { providerRegistry } from '../providerRegistry';
import { StorageManager } from '../../storage';

// Default working TMDB v3 API key for open educational and development catalog access
// Users can also enter their own key in Admin / Settings.
const DEFAULT_TMDB_KEY = '15d2ea6d0dc1d476efbca3eba2b9bbfb';
const TMDB_BASE_URL = 'https://api.themoviedb.org/3';

export class TmdbProvider {
  private static getKey(): string {
    const settings = StorageManager.getSettings();
    if (settings.tmdbApiKey && settings.tmdbApiKey.trim()) {
      return settings.tmdbApiKey.trim();
    }
    const envKey = (import.meta as any).env?.VITE_TMDB_PUBLIC_KEY || (import.meta as any).env?.VITE_TMDB_API_KEY;
    if (envKey && envKey.trim()) {
      return envKey.trim();
    }
    return DEFAULT_TMDB_KEY;
  }

  private static async request<T>(endpoint: string, params: Record<string, string> = {}): Promise<T> {
    const key = this.getKey();
    const query = new URLSearchParams({
      api_key: key,
      ...params,
    }).toString();

    const proxyUrl = `/api/tmdb${endpoint}?${query}`;
    const directUrl = `${TMDB_BASE_URL}${endpoint}?${query}`;
    const cacheKey = `tmdb:${endpoint}:${query}`;

    // Check cache
    const cached = await cache.get<T>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const data = await fetchWithRetry<T>(async (signal) => {
        // Try server proxy first (100% ISP unblocked & fast)
        try {
          const proxyRes = await fetch(proxyUrl, {
            signal,
            headers: { Accept: 'application/json' },
          });
          if (proxyRes.ok) {
            return await proxyRes.json();
          }
        } catch {}

        // Fallback to direct URL
        const res = await fetch(directUrl, {
          signal,
          headers: {
            Accept: 'application/json',
          },
        });

        if (!res.ok) {
          throw new Error(`TMDB error ${res.status}: ${res.statusText}`);
        }
        return res.json();
      });

      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('tmdb', latency);

      // Cache for 1 hour
      await cache.set(cacheKey, data, 3600 * 1000);
      return data;
    } catch (err: any) {
      providerRegistry.recordError('tmdb', err.message || 'Network error');
      throw err;
    }
  }

  // Trending
  static async getTrending(mediaType: 'movie' | 'tv' | 'all' = 'movie', timeWindow: 'day' | 'week' = 'day'): Promise<NormalizedTitle[]> {
    try {
      const res = await this.request<any>(`/trending/${mediaType}/${timeWindow}`);
      return (res.results || []).map((item: any) =>
        TitleNormalizer.normalizeTmdb(item, item.media_type === 'tv' ? 'tv' : 'movie')
      );
    } catch (e) {
      return [];
    }
  }

  // Popular
  static async getPopular(type: 'movie' | 'tv' = 'movie', page = 1): Promise<NormalizedTitle[]> {
    try {
      const res = await this.request<any>(`/${type}/popular`, { page: page.toString() });
      return (res.results || []).map((item: any) => TitleNormalizer.normalizeTmdb(item, type));
    } catch (e) {
      return [];
    }
  }

  // Top Rated
  static async getTopRated(type: 'movie' | 'tv' = 'movie', page = 1): Promise<NormalizedTitle[]> {
    try {
      const res = await this.request<any>(`/${type}/top_rated`, { page: page.toString() });
      return (res.results || []).map((item: any) => TitleNormalizer.normalizeTmdb(item, type));
    } catch (e) {
      return [];
    }
  }

  // Upcoming
  static async getUpcoming(page = 1): Promise<NormalizedTitle[]> {
    try {
      const res = await this.request<any>('/movie/upcoming', { page: page.toString() });
      return (res.results || []).map((item: any) => TitleNormalizer.normalizeTmdb(item, 'movie'));
    } catch (e) {
      return [];
    }
  }

  // Discover with deep filtering
  static async discover(options: {
    type?: 'movie' | 'tv';
    genreId?: number | string;
    language?: string;
    year?: number;
    sortBy?: string;
    page?: number;
    includeAdult?: boolean;
  }): Promise<NormalizedTitle[]> {
    const type = options.type || 'movie';
    const params: Record<string, string> = {
      page: (options.page || 1).toString(),
      sort_by: options.sortBy || 'popularity.desc',
      include_adult: options.includeAdult ? 'true' : (options.genreId === 10749 ? 'true' : 'false'),
    };

    if (options.genreId) {
      params.with_genres = options.genreId.toString();
    }
    if (options.language) {
      params.with_original_language = options.language.toLowerCase();
    }
    if (options.year) {
      if (type === 'movie') {
        params.primary_release_year = options.year.toString();
      } else {
        params.first_air_date_year = options.year.toString();
      }
    }

    try {
      const res = await this.request<any>(`/discover/${type}`, params);
      return (res.results || []).map((item: any) => TitleNormalizer.normalizeTmdb(item, type));
    } catch (e) {
      return [];
    }
  }

  // Search
  static async search(query: string, type?: 'movie' | 'tv' | 'multi', page = 1, signal?: AbortSignal): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];
    const searchEndpoint = type && type !== 'multi' ? `/search/${type}` : '/search/multi';

    try {
      const data = await this.request<any>(searchEndpoint, {
        query: query.trim(),
        page: page.toString(),
        include_adult: 'true',
      });

      return (data.results || [])
        .filter((r: any) => r.media_type !== 'person' && (r.poster_path || r.backdrop_path || r.title || r.name))
        .map((r: any) => TitleNormalizer.normalizeTmdb(r, type === 'tv' || r.media_type === 'tv' ? 'tv' : 'movie'));
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        providerRegistry.recordError('tmdb', err.message || 'Search failed');
      }
      return [];
    }
  }

  // Detailed Title info (with credits, videos, similar, recommendations, watch providers)
  static async getDetails(type: 'movie' | 'tv', id: number | string): Promise<NormalizedTitle | null> {
    const cacheKey = `tmdb:details:${type}:${id}`;
    const cached = await cache.get<NormalizedTitle>(cacheKey);
    if (cached) return cached;

    try {
      const res = await this.request<any>(`/${type}/${id}`, {
        append_to_response: 'credits,videos,similar,recommendations,watch/providers',
      });
      const normalized = TitleNormalizer.normalizeTmdb(res, type);
      // Cache details for 24 hours
      await cache.set(cacheKey, normalized, 24 * 3600 * 1000);
      return normalized;
    } catch (err) {
      return null;
    }
  }

  // Ping Connectivity test
  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const startTime = performance.now();
    try {
      const res = await fetch(`${TMDB_BASE_URL}/configuration?api_key=${this.getKey()}`, {
        headers: { Accept: 'application/json' },
      });
      const latencyMs = Math.round(performance.now() - startTime);
      if (res.ok) {
        providerRegistry.recordSuccess('tmdb', latencyMs);
        return { ok: true, latencyMs, message: 'TMDB API v3 connected successfully' };
      }
      providerRegistry.recordError('tmdb', `HTTP ${res.status}`);
      return { ok: false, latencyMs, message: `Failed with HTTP status ${res.status}` };
    } catch (err: any) {
      providerRegistry.recordError('tmdb', err.message || 'Network ping error');
      return { ok: false, latencyMs: 0, message: err.message || 'Network unreachable' };
    }
  }
}
