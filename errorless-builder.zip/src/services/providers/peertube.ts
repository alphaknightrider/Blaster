import { NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

// Verified active public PeerTube instances
const PEERTUBE_INSTANCES = [
  'https://peertube.tv',
  'https://tilvids.com',
  'https://framatube.org',
];

export class PeerTubeProvider {
  private static instance = PEERTUBE_INSTANCES[0];

  // Get trending & latest open videos & cinema
  static async getVideos(count = 20, sort = '-trending'): Promise<NormalizedTitle[]> {
    const cacheKey = `peertube:videos:${sort}:${count}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const res = await fetch(`${this.instance}/api/v1/videos?count=${count}&sort=${sort}&isLive=false`);
      if (!res.ok) throw new Error(`PeerTube HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('peertube', latency);

      const items = (data?.data || []).map((v: any) => TitleNormalizer.normalizePeerTube(v, this.instance));
      await cache.set(cacheKey, items, 1800 * 1000);
      return items;
    } catch (err: any) {
      providerRegistry.recordError('peertube', err.message || 'PeerTube network error');
      return [];
    }
  }

  // Search PeerTube videos
  static async search(query: string, signal?: AbortSignal): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];
    const cacheKey = `peertube:search:${query.toLowerCase()}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    try {
      const res = await fetch(`${this.instance}/api/v1/search/videos?search=${encodeURIComponent(query)}&count=15`, { signal });
      if (!res.ok) throw new Error(`PeerTube search HTTP ${res.status}`);
      const data = await res.json();
      const items = (data?.data || []).map((v: any) => TitleNormalizer.normalizePeerTube(v, this.instance));
      await cache.set(cacheKey, items, 1800 * 1000);
      return items;
    } catch {
      return [];
    }
  }

  // Get video details by UUID
  static async getDetails(uuid: string): Promise<NormalizedTitle | null> {
    const cleanId = uuid.replace(/^peertube:/, '');
    const cacheKey = `peertube:details:${cleanId}`;
    const cached = await cache.get<NormalizedTitle>(cacheKey);
    if (cached) return cached;

    try {
      const res = await fetch(`${this.instance}/api/v1/videos/${cleanId}`);
      if (!res.ok) return null;
      const data = await res.json();
      const norm = TitleNormalizer.normalizePeerTube(data, this.instance);
      await cache.set(cacheKey, norm, 3600 * 1000);
      return norm;
    } catch {
      return null;
    }
  }
}
