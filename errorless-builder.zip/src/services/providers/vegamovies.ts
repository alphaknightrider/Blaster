import { DownloadOption, MediaType, NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { TmdbProvider } from './tmdb';

// VegaMovies active mirror domains and open endpoints
export const VEGAMOVIES_MIRRORS = [
  'https://vegamovies.im',
  'https://vegamovies.mex',
  'https://vegamovies.yt',
  'https://vegamovies.ngo',
  'https://vegamovies.nl',
];

export interface VegaDownloadLink {
  quality: '4K Ultra HD' | '1080p Full HD' | '720p HD' | '480p SD';
  resolution: string;
  size: string;
  audio: string;
  server: string;
  url: string;
  badgeColor: string;
}

export class VegaMoviesProvider {
  private static primaryMirror = VEGAMOVIES_MIRRORS[0];

  // Get active VegaMovies mirror URL
  static getBaseUrl(): string {
    return this.primaryMirror;
  }

  // Generate VegaMovies search URL
  static getSearchUrl(title: string, year?: number): string {
    const cleanTitle = title
      .replace(/[^a-zA-Z0-9\s]/g, '')
      .trim();
    const query = year ? `${cleanTitle} ${year}` : cleanTitle;
    return `${this.primaryMirror}/?s=${encodeURIComponent(query)}`;
  }

  // Generate VegaMovies multi-quality direct links and mirrors
  static getDownloadLinks(title: string, year?: number, mediaType: MediaType = 'movie'): VegaDownloadLink[] {
    const searchUrl = this.getSearchUrl(title, year);
    const cleanTitle = encodeURIComponent(title);

    if (mediaType === 'tv') {
      return [
        {
          quality: '1080p Full HD',
          resolution: '1080p x264 / HEVC 10-Bit',
          size: '~1.2 GB / Episode',
          audio: 'Hindi + English [Dual Audio] E-Sub',
          server: 'VegaMovies HubCloud Fast Server',
          url: searchUrl,
          badgeColor: 'bg-purple-600',
        },
        {
          quality: '720p HD',
          resolution: '720p Web-DL',
          size: '~450 MB / Episode',
          audio: 'Hindi Dubbed / Dual Audio',
          server: 'Vega Cloud Direct Mirror',
          url: searchUrl,
          badgeColor: 'bg-blue-600',
        },
        {
          quality: '480p SD',
          resolution: '480p Mobile Ready',
          size: '~200 MB / Episode',
          audio: 'Hindi Clean Audio',
          server: 'Direct Fast Cloud',
          url: searchUrl,
          badgeColor: 'bg-emerald-600',
        },
      ];
    }

    return [
      {
        quality: '4K Ultra HD',
        resolution: '2160p 4K UHD x265 HDR',
        size: '6.8 GB - 14.5 GB',
        audio: 'Dolby Atmos Hindi + English [Dual Audio]',
        server: 'VegaMovies Ultra High-Speed Mirror',
        url: searchUrl,
        badgeColor: 'bg-amber-600',
      },
      {
        quality: '1080p Full HD',
        resolution: '1080p Full HD Web-DL x264',
        size: '2.2 GB - 3.4 GB',
        audio: 'Hindi + English [Dual Audio] E-Sub',
        server: 'Vega Cloud & HubCloud Fast CDN',
        url: searchUrl,
        badgeColor: 'bg-purple-600',
      },
      {
        quality: '720p HD',
        resolution: '720p HD Web-DL (Recommended)',
        size: '950 MB - 1.4 GB',
        audio: 'Hindi Dubbed / Dual Audio [Clean]',
        server: 'High-Speed Direct Cloud',
        url: searchUrl,
        badgeColor: 'bg-blue-600',
      },
      {
        quality: '480p SD',
        resolution: '480p Mobile-Ready (Data Saver)',
        size: '380 MB - 480 MB',
        audio: 'Hindi Dubbed / Original',
        server: 'Fast Mobile CDN Mirror',
        url: searchUrl,
        badgeColor: 'bg-emerald-600',
      },
    ];
  }

  // Convert to app download options
  static getDownloadOptions(title: string, year?: number, mediaType: MediaType = 'movie'): DownloadOption[] {
    const links = this.getDownloadLinks(title, year, mediaType);
    return links.map((l) => ({
      format: `${l.quality} (${l.resolution})`,
      quality: `${l.audio} · ${l.size}`,
      size: l.size,
      url: l.url,
      source: `VegaMovies (${l.server})`,
      license: 'High Speed Direct Mirror',
    }));
  }

  // Get Bollywood & Indian Cinema (100,000+ catalog search and discovery)
  static async getBollywoodReleases(page = 1): Promise<NormalizedTitle[]> {
    return TmdbProvider.discover({
      type: 'movie',
      language: 'hi',
      sortBy: 'popularity.desc',
      page,
    });
  }

  // Get South Indian Hindi Dubbed Blockbusters (Telugu, Tamil, Kannada, Malayalam)
  static async getSouthHindiDubbed(page = 1): Promise<NormalizedTitle[]> {
    return TmdbProvider.discover({
      type: 'movie',
      language: 'te', // Telugu blockbusters
      sortBy: 'popularity.desc',
      page,
    });
  }

  // Get Hollywood Hindi Dubbed & Dual Audio
  static async getHollywoodDualAudio(page = 1): Promise<NormalizedTitle[]> {
    return TmdbProvider.discover({
      type: 'movie',
      language: 'en',
      sortBy: 'popularity.desc',
      page,
    });
  }

  // Get Web Series (Hindi & International)
  static async getWebSeries(page = 1): Promise<NormalizedTitle[]> {
    return TmdbProvider.discover({
      type: 'tv',
      language: 'hi',
      sortBy: 'popularity.desc',
      page,
    });
  }
}
