import { NormalizedTitle, TVSeason, TVEpisode } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const TVMAZE_BASE = 'https://api.tvmaze.com';

export class TvmazeProvider {
  // Get popular shows paginated
  static async getPopularShows(page = 0): Promise<NormalizedTitle[]> {
    const cacheKey = `tvmaze:shows:page:${page}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const res = await fetch(`${TVMAZE_BASE}/shows?page=${page}`, {
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) throw new Error(`TVmaze HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('tvmaze', latency);

      const normalized = (data || []).slice(0, 30).map((show: any) => TitleNormalizer.normalizeTvmaze(show));
      await cache.set(cacheKey, normalized, 3600 * 1000);
      return normalized;
    } catch (err: any) {
      providerRegistry.recordError('tvmaze', err.message || 'Network error');
      return [];
    }
  }

  // Search TV shows
  static async search(query: string, signal?: AbortSignal): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];
    const cacheKey = `tvmaze:search:${query.toLowerCase()}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const res = await fetch(`${TVMAZE_BASE}/search/shows?q=${encodeURIComponent(query)}`, {
        signal,
        headers: { Accept: 'application/json' },
      });
      if (!res.ok) throw new Error(`TVmaze search HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('tvmaze', latency);

      const items = (data || []).map((entry: any) => TitleNormalizer.normalizeTvmaze(entry.show));
      await cache.set(cacheKey, items, 1800 * 1000);
      return items;
    } catch (err: any) {
      providerRegistry.recordError('tvmaze', err.message || 'Search error');
      return [];
    }
  }

  // Get show details with seasons and episodes
  static async getDetails(showId: number | string): Promise<NormalizedTitle | null> {
    const cleanId = String(showId).replace(/^tvmaze:/, '');
    const cacheKey = `tvmaze:details:${cleanId}`;
    const cached = await cache.get<NormalizedTitle>(cacheKey);
    if (cached) return cached;

    try {
      const [showRes, seasonsRes] = await Promise.all([
        fetch(`${TVMAZE_BASE}/shows/${cleanId}`),
        fetch(`${TVMAZE_BASE}/shows/${cleanId}/seasons`),
      ]);

      if (!showRes.ok) return null;
      const showData = await showRes.json();
      const seasonsData = seasonsRes.ok ? await seasonsRes.json() : [];

      const norm = TitleNormalizer.normalizeTvmaze(showData);

      // Attach seasons
      if (Array.isArray(seasonsData) && seasonsData.length > 0) {
        norm.seasons = seasonsData.map((s: any) => ({
          id: s.id,
          seasonNumber: s.number,
          name: s.name || `Season ${s.number}`,
          episodeCount: s.episodeOrder || 10,
          posterPath: s.image?.medium || s.image?.original,
          overview: s.summary?.replace(/<[^>]*>/g, '').trim(),
        }));
        norm.seasonsCount = norm.seasons.length;
      }

      await cache.set(cacheKey, norm, 3600 * 1000);
      return norm;
    } catch {
      return null;
    }
  }

  // Connectivity ping
  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const startTime = performance.now();
    try {
      const res = await fetch(`${TVMAZE_BASE}/shows/1`, { method: 'HEAD' });
      const latencyMs = Math.round(performance.now() - startTime);
      return { ok: res.ok, latencyMs, message: res.ok ? 'Connected' : `HTTP ${res.status}` };
    } catch (err: any) {
      return { ok: false, latencyMs: 0, message: err.message || 'Offline' };
    }
  }
}
