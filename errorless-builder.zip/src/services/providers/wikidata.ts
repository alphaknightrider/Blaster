import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const WIKIDATA_API = 'https://www.wikidata.org/w/api.php';

export class WikidataProvider {
  static async searchEntity(title: string, year?: number): Promise<any | null> {
    const cacheKey = `wikidata:${title}:${year || ''}`;
    const cached = await cache.get<any>(cacheKey);
    if (cached) return cached;

    const start = performance.now();
    try {
      const url = `${WIKIDATA_API}?action=wbsearchentities&search=${encodeURIComponent(title)}&language=en&type=item&format=json&origin=*`;
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();
      const match = data.search?.[0];
      const latency = Math.round(performance.now() - start);
      providerRegistry.recordSuccess('wikidata', latency);

      if (match) {
        await cache.set(cacheKey, match, 24 * 3600 * 1000);
      }
      return match || null;
    } catch (err: any) {
      providerRegistry.recordError('wikidata', err.message);
      return null;
    }
  }

  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const start = performance.now();
    try {
      const url = `${WIKIDATA_API}?action=wbsearchentities&search=Inception&language=en&type=item&format=json&origin=*`;
      const res = await fetch(url);
      const latency = Math.round(performance.now() - start);
      if (res.ok) {
        providerRegistry.recordSuccess('wikidata', latency);
        return { ok: true, latencyMs: latency, message: 'Wikidata Semantic API operational' };
      }
      return { ok: false, latencyMs: latency, message: `Status code ${res.status}` };
    } catch (err: any) {
      return { ok: false, latencyMs: 0, message: err.message };
    }
  }
}
