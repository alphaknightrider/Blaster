export interface ShortDramaEpisode {
  episodeNumber: number;
  title: string;
  duration: string;
  videoUrl: string;
  thumbnail: string;
  isFree?: boolean;
}

export interface ShortDrama {
  id: string;
  title: string;
  hindiTitle?: string;
  category: 'indian_desi' | '18_mature' | 'billionaire' | 'werewolf' | 'revenge' | 'palace';
  categoryLabel: string;
  language: 'Hindi' | 'English' | 'Hinglish' | 'Bhojpuri';
  synopsis: string;
  cover: string;
  banner?: string;
  totalEpisodes: number;
  views: string;
  rating: number;
  badge?: string;
  isIndian?: boolean;
  episodes: ShortDramaEpisode[];
}

const BANNER_POOL = [
  'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=1600&q=80', // Penthouse Tycoon
  'https://images.unsplash.com/photo-1578328819058-b69f3a3b0f6b?auto=format&fit=crop&w=1600&q=80', // Royal Haveli Palace
  'https://images.unsplash.com/photo-1514565131-fce0801e5785?auto=format&fit=crop&w=1600&q=80', // Mumbai Midnight Don
  'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?auto=format&fit=crop&w=1600&q=80', // Dark Revenge
  'https://images.unsplash.com/photo-1519671482749-fd09be7ccebf?auto=format&fit=crop&w=1600&q=80', // Velvet Romance
  'https://images.unsplash.com/photo-1492691527719-9d1e07e534b4?auto=format&fit=crop&w=1600&q=80', // Rural Sunset Sagas
  'https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?auto=format&fit=crop&w=1600&q=80', // Werewolf Moonlit Forest
  'https://images.unsplash.com/photo-1511765224389-37f0e77cf0eb?auto=format&fit=crop&w=1600&q=80', // Royal Dynasty Ballroom
];

const POSTER_POOL = [
  'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80', // Billionaire Jamai
  'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80', // Thakur's Bride
  'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80', // Divorced Bahu
  'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80', // Delhi Tycoon
  'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=600&q=80', // Gaon Ki Chhori
  'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80', // Super Cop
  'https://images.unsplash.com/photo-1501196354995-cbb51c65aaea?auto=format&fit=crop&w=600&q=80', // Mumbai Don
  'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80', // Steamy Romance
  'https://images.unsplash.com/photo-1539571696357-5a69c17a67c6?auto=format&fit=crop&w=600&q=80', // Contract Love
  'https://images.unsplash.com/photo-1531746020798-e6953c6e8e04?auto=format&fit=crop&w=600&q=80', // Drama Queen
  'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=600&q=80', // Rural Heart
  'https://images.unsplash.com/photo-1519764622345-23439dd774f7?auto=format&fit=crop&w=600&q=80', // Werewolf Bloodline
  'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=600&q=80', // Royal Palace
  'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=600&q=80', // Desi Jalwa
  'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=600&q=80', // Quadruplets CEO
];

const VIDEO_STREAM_POOL = [
  'https://archive.org/download/superman_1941/superman_1941_512kb.mp4',
  'https://archive.org/download/Popeye_forPresident/Popeye_forPresident_512kb.mp4',
  'https://archive.org/download/Betty_Boop_Poor_Cinderella_1934/Betty_Boop_Poor_Cinderella_1934_512kb.mp4',
  'https://archive.org/download/Betty_Boop_More_Pep_1936/Betty_Boop_More_Pep_1936_512kb.mp4',
];

export const SHORT_DRAMA_FLAGSHIPS: ShortDrama[] = [
  {
    id: 'drama-in-crorepati-damad',
    title: 'The Secret Crorepati Jamai',
    hindiTitle: 'छुपा हुआ करोड़पति दामाद (The Hidden Billionaire Son-In-Law)',
    category: 'indian_desi',
    categoryLabel: '🇮🇳 Indian Desi & Billionaire',
    language: 'Hindi',
    synopsis: 'Mocked and insulted daily as a penniless house-husband (घर जमाई) by his greedy in-laws, Kabir stayed silent for his wife Meera’s sake. On his mother-in-law\'s 50th birthday, the city police commissioner and 50 bulletproof Rolls-Royces arrive to salute the real Chairman of Singhania Conglomerate.',
    cover: POSTER_POOL[0],
    banner: BANNER_POOL[0],
    totalEpisodes: 80,
    views: '8.9M',
    rating: 9.8,
    badge: '🔥 MicroTV #1 Trending',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'दामाद की बेइज्जती (The Humiliation)'
          : i === 1
          ? '50 गाड़ियों का काफिला (The 50 Car Convoy)'
          : i === 2
          ? 'चेयरमैन का खुलासा (Chairman Revealed)'
          : 'साम्राज्य की वापसी'
      }`,
      duration: '1:45',
      videoUrl: VIDEO_STREAM_POOL[0],
      thumbnail: POSTER_POOL[0],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-thakur-bride',
    title: 'Thakur’s Forced Passion: Zabardasti Ka Rishta',
    hindiTitle: 'ठाकुर साहिब का जुनून (18+ देसी डार्क रोमांस)',
    category: '18_mature',
    categoryLabel: '🔞 18+ Desi Romance',
    language: 'Hindi',
    synopsis: 'Fierce and ruthless, Ranveer Singh Thakur ruled the entire northern province with an iron fist. To clear her family\'s debt, simple village teacher Ananya was dragged into his ancestral palace. Behind velvet bedroom doors, the ruthless Thakur demanded absolute surrender before offering her the royal mangalsutra.',
    cover: POSTER_POOL[1],
    banner: BANNER_POOL[1],
    totalEpisodes: 72,
    views: '9.4M',
    rating: 9.7,
    badge: '🔞 18+ Desi Steamy',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'हवेली में पहली रात (First Night in Haveli)'
          : i === 1
          ? 'ठाकुर की शर्त (Thakur\'s Demand)'
          : 'इश्क का फितूर'
      }`,
      duration: '2:15',
      videoUrl: VIDEO_STREAM_POOL[1],
      thumbnail: POSTER_POOL[1],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-bahu-badla',
    title: 'Revenge of the Divorced Bahu',
    hindiTitle: 'बहू का खौफनाक बदला (The Divorced Daughter-in-Law)',
    category: 'revenge',
    categoryLabel: '🔥 Revenge & Comeback',
    language: 'Hindi',
    synopsis: 'Thrown out of the house in the freezing rain for giving birth to a daughter, Pooja was left to starve by her cruel mother-in-law. Five years later, she returns as Pooja Oberoi, the richest venture capitalist in Asia, buying her ex-husband’s bankrupt firm and making her in-laws beg on their knees.',
    cover: POSTER_POOL[2],
    banner: BANNER_POOL[3],
    totalEpisodes: 85,
    views: '7.8M',
    rating: 9.6,
    badge: '💥 High Voltage Drama',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'बारिश में निकाला (Thrown in Rain)'
          : i === 1
          ? '5 साल बाद वापसी (Return After 5 Years)'
          : 'नीलामी का खेल'
      }`,
      duration: '1:50',
      videoUrl: VIDEO_STREAM_POOL[2],
      thumbnail: POSTER_POOL[2],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-delhi-tycoon',
    title: 'Contract Marriage with Delhi Tycoon',
    hindiTitle: 'दिल्ली के अरबपति से गुप्त निकाह (18+ रोमांस)',
    category: 'billionaire',
    categoryLabel: '💋 Billionaire & Contract Love',
    language: 'Hinglish',
    synopsis: 'To pay for her brother’s heart transplant, college student Maya signs a 1-year secret marriage agreement with Reyansh Singhania, Delhi\'s most feared billionaire. The penthouse contract said "No intimacy, strictly professional" — until a thunderstorm night melted every boundary.',
    cover: POSTER_POOL[3],
    banner: BANNER_POOL[0],
    totalEpisodes: 65,
    views: '8.1M',
    rating: 9.5,
    badge: '💋 Binge Favorite',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'समझौते के फेरे (The Contract Wedding)'
          : i === 1
          ? 'पेंटहाउस का राज (Penthouse Secret)'
          : 'बेकाबू मोहब्बत'
      }`,
      duration: '1:55',
      videoUrl: VIDEO_STREAM_POOL[3],
      thumbnail: POSTER_POOL[3],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-gaon-babu',
    title: 'Gaon Ki Chhori Aur Shehari Babu',
    hindiTitle: 'गांव की छोरी और शहर का बाबू (देसी लव स्टोरी)',
    category: 'indian_desi',
    categoryLabel: '🇮🇳 Indian Desi & Village Love',
    language: 'Hindi',
    synopsis: 'Arrogant US-returned billionaire Armaan crashes his luxury Mercedes in a dusty UP village during a monsoon storm. Rescued by Gauri, the fiercest village girl who doesn’t care about his billions, what begins as constant bickering turns into an uncontrollable, desi rural romance.',
    cover: POSTER_POOL[4],
    banner: BANNER_POOL[5],
    totalEpisodes: 55,
    views: '6.4M',
    rating: 9.4,
    badge: 'Desi Romance',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'तूफान में मुलाकात (Storm Encounter)'
          : i === 1
          ? 'खेतों में तकरार (Farm Dispute)'
          : 'दिल की बात'
      }`,
      duration: '1:40',
      videoUrl: VIDEO_STREAM_POOL[4],
      thumbnail: POSTER_POOL[4],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-undercover-cop',
    title: 'Ghar Jamai Nikla Super Cop',
    hindiTitle: 'घर जमाई निकला सुपर कॉप (Secret IPS Officer)',
    category: 'revenge',
    categoryLabel: '🔥 Desi Action & Revenge',
    language: 'Hindi',
    synopsis: 'Treated like a servant and forced to cook for his arrogant corporate in-laws, Arjun never answers back. When the city’s most dangerous gangster kidnaps his wife, Arjun puts on his Khaki uniform with 3 IPS stars, shocking the entire police department and his trembling family.',
    cover: POSTER_POOL[5],
    banner: BANNER_POOL[2],
    totalEpisodes: 60,
    views: '7.1M',
    rating: 9.7,
    badge: '💥 Super Hit IPS',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'रसोई का नौकर (Kitchen Servant)'
          : i === 1
          ? 'वर्दी का रौब (Uniform Power)'
          : 'सैल्यूट कमिश्नर का'
      }`,
      duration: '1:50',
      videoUrl: VIDEO_STREAM_POOL[0],
      thumbnail: POSTER_POOL[5],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-in-mafia-obsession',
    title: 'Mumbai Don’s Obsession: Meri Jaan (18+)',
    hindiTitle: 'डॉन का खतरनाक इश्क (18+ मुंबई माफिया)',
    category: '18_mature',
    categoryLabel: '🔞 18+ Desi Romance',
    language: 'Hindi',
    synopsis: 'Underworld kingpin Vikram accidentally locks eyes with classical dancer Riya during a gang shootout. Captivated by her innocence, the dangerous don brings her to his fortress-like seaside bungalow in Bandra, declaring that no man in Mumbai can touch what belongs to Vikram.',
    cover: POSTER_POOL[6],
    banner: BANNER_POOL[2],
    totalEpisodes: 70,
    views: '8.6M',
    rating: 9.8,
    badge: '🔞 Dark Mafia 18+',
    isIndian: true,
    episodes: Array.from({ length: 25 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `भाग ${i + 1}: ${
        i === 0
          ? 'डॉन की नजर (The Don\'s Gaze)'
          : i === 1
          ? 'पिंजरे में कैद (Trapped in Gold Cage)'
          : 'जुनूनी इश्क'
      }`,
      duration: '2:05',
      videoUrl: VIDEO_STREAM_POOL[1],
      thumbnail: POSTER_POOL[6],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-18-ceo',
    title: 'The Billionaire\'s Secret Bedmate (18+)',
    hindiTitle: 'अरबपति का गुप्त बिस्तर साथी (18+)',
    category: '18_mature',
    categoryLabel: '🔞 18+ Mature Romance',
    language: 'English',
    synopsis: 'Forced into an underground marriage with the ruthless billionaire Alexander Vance, Evelyn thought it was purely transactional. Until his burning gaze and midnight demands broke every rule she ever set.',
    cover: POSTER_POOL[1],
    banner: BANNER_POOL[4],
    totalEpisodes: 65,
    views: '4.8M',
    rating: 9.6,
    badge: 'Trending #1',
    episodes: Array.from({ length: 20 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `Episode ${i + 1}: ${i === 0 ? 'The Midnight Encounter' : i === 1 ? 'Unmasked In Darkness' : i === 2 ? 'Whispered Confession' : 'Tangled Hearts'}`,
      duration: '1:45',
      videoUrl: VIDEO_STREAM_POOL[0],
      thumbnail: POSTER_POOL[1],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-luna-alpha',
    title: 'The Rejected Luna\'s Second Chance',
    hindiTitle: 'ठुकराई हुई लूना का बदला',
    category: 'werewolf',
    categoryLabel: '🐺 Werewolf & Vampire Romance',
    language: 'English',
    synopsis: 'Cast out by her fated mate for being "weak," Maya vanishes into the forbidden dark woods. Three years later, she returns as the supreme Lycan Queen of the Silverfang Empire.',
    cover: POSTER_POOL[5],
    banner: BANNER_POOL[6],
    totalEpisodes: 72,
    views: '3.9M',
    rating: 9.4,
    badge: 'Popular',
    episodes: Array.from({ length: 20 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `Episode ${i + 1}: ${i === 0 ? 'The Broken Bond' : i === 1 ? 'Bloodmoon Awakening' : 'Rise of the Lycan Queen'}`,
      duration: '2:10',
      videoUrl: VIDEO_STREAM_POOL[1],
      thumbnail: POSTER_POOL[5],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-billionaire-baby',
    title: 'Flash Marriage to the Secret Tycoon',
    hindiTitle: 'ड्राइवर निकला 800 करोड़ का मालिक',
    category: 'billionaire',
    categoryLabel: '💋 Billionaire & Contract Love',
    language: 'English',
    synopsis: 'To save her grandmother’s hospital fees, Mia hastily signed a marriage certificate with an ordinary driver at the civil affairs bureau. Little did she know, his "cheap" car was actually part of an 800-billion-dollar dynasty.',
    cover: POSTER_POOL[4],
    banner: BANNER_POOL[0],
    totalEpisodes: 55,
    views: '2.7M',
    rating: 9.1,
    badge: 'Viral Reel',
    episodes: Array.from({ length: 20 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `Episode ${i + 1}: ${i === 0 ? 'Nine Dollar Wedding' : i === 1 ? 'The Fake Driver' : 'Black Card Revealed'}`,
      duration: '1:35',
      videoUrl: VIDEO_STREAM_POOL[3],
      thumbnail: POSTER_POOL[4],
      isFree: i < 10,
    })),
  },
  {
    id: 'drama-palace-rebirth',
    title: 'Rebirth of the Vengeful Empress',
    hindiTitle: 'महारानी का पुनर्जन्म',
    category: 'palace',
    categoryLabel: '👑 Royal Palace Intrigue',
    language: 'English',
    synopsis: 'Poisoned in the cold palace after helping her husband claim the throne, Lady Shen wakes up ten years earlier on the eve of her imperial selection. This time, she will play the emperors like chess pieces.',
    cover: POSTER_POOL[6],
    banner: BANNER_POOL[7],
    totalEpisodes: 90,
    views: '5.1M',
    rating: 9.7,
    badge: 'Top Drama',
    episodes: Array.from({ length: 20 }, (_, i) => ({
      episodeNumber: i + 1,
      title: `Episode ${i + 1}: ${i === 0 ? 'Wine of Poison' : i === 1 ? 'Back to Sixteen' : 'The Lotus Trap'}`,
      duration: '2:05',
      videoUrl: VIDEO_STREAM_POOL[4],
      thumbnail: POSTER_POOL[6],
      isFree: i < 10,
    })),
  },
];

// --- GENERATOR OF 1,000+ SHORT DRAMAS ---
const DESI_NAMES = [
  'Kabir', 'Ranveer', 'Arjun', 'Reyansh', 'Armaan', 'Vikram', 'Pooja', 'Ananya', 'Maya', 'Gauri',
  'Riya', 'Rathore', 'Singhania', 'Oberoi', 'Mittal', 'Thakur', 'Chauhan', 'Kashyap', 'Malhotra', 'Vance',
  'Aditya', 'Samrat', 'Devraj', 'Siddharth', 'Yuvraj', 'Rudra', 'Veer', 'Shivaay', 'Zoya', 'Nandini'
];

const DESI_PREFIXES = [
  'The Secret Crorepati', 'Ghar Jamai\'s Hidden', 'Dehati Babu\'s', 'The Disowned Scion of',
  'Singhania Family\'s Secret', 'The Rickshaw Driver Who Bought', 'Oberoi Empire\'s', 'The Undercover IPS',
  'Village Belle &', 'Chhupa Hua', 'Gaon Ki Ladki Aur', 'Arjun\'s Revenge On', 'The Silent Billionaire',
  'The Chaiwala Scion of', 'Desi Jamai Slaps', 'Royal Rathore\'s', 'The Slumdog Tycoon of', 'Billionaire Peon of',
  'The Stolen Will of', 'The True Heir of'
];

const DESI_SUFFIXES = [
  'Jamai Returns', 'Revenge on In-Laws', '100 Rolls-Royces', 'Billionaire Bride', 'True Identity Revealed',
  'Bahu Ka Samrajya', '5000 Crore Empire', 'Wedding Day Secret', 'Penthouse Contract', 'Golden Sindoor',
  'Hidden Warlord', 'Supreme Don', 'Slapping The Relatives', 'Silent Protector', 'Village Belle\'s Love',
  'Secret IPS Strike'
];

const DESI_HINDI_TITLES = [
  'छुपा हुआ करोड़पति दामाद', 'ससुराल वालों का घमंड तोड़ा', '5000 करोड़ का घर जमाई', 'ठाकुर साहब की दुल्हनिया',
  'बहू का खौफनाक इंतकाम', 'तलाक के बाद बनी कंपनी की मालकिन', 'गांव की छोरी ने बदला शहर का बाबू', 'असली चेयरमैन का खुलासा',
  'अंडरकवर डीसीपी का रौब', 'दिल्ली के अरबपति का कॉन्ट्रैक्ट ब्याह', '18+ हवेली की दास्तान', 'राजपूतों का असली वारिस',
  'चायवाले की बेटी बनी प्रेसिडेंट', 'माफिया डॉन की दीवानगी', 'महारानी का शाही बदला', 'नीलामी में खरीदा पति का दफ्तर'
];

const CATEGORIES_DATA: Array<{
  category: ShortDrama['category'];
  categoryLabel: string;
  isIndian: boolean;
  defaultLang: ShortDrama['language'];
}> = [
  { category: 'indian_desi', categoryLabel: '🇮🇳 Indian Desi & Billionaire', isIndian: true, defaultLang: 'Hindi' },
  { category: '18_mature', categoryLabel: '🔞 18+ Desi Romance', isIndian: true, defaultLang: 'Hindi' },
  { category: 'revenge', categoryLabel: '🔥 Revenge & Comeback', isIndian: true, defaultLang: 'Hindi' },
  { category: 'billionaire', categoryLabel: '💋 Billionaire & Contract Love', isIndian: true, defaultLang: 'Hinglish' },
  { category: 'palace', categoryLabel: '👑 Royal Palace & Haveli', isIndian: true, defaultLang: 'Hindi' },
  { category: 'werewolf', categoryLabel: '🐺 Werewolf & Alpha Luna', isIndian: false, defaultLang: 'English' },
];

function generateExpandedDramas(count = 1100): ShortDrama[] {
  const result: ShortDrama[] = [];

  for (let i = 1; i <= count; i++) {
    const catConfig = CATEGORIES_DATA[i % CATEGORIES_DATA.length];
    const nameA = DESI_NAMES[(i * 3) % DESI_NAMES.length];
    const nameB = DESI_NAMES[(i * 7 + 1) % DESI_NAMES.length];
    const prefix = DESI_PREFIXES[i % DESI_PREFIXES.length];
    const suffix = DESI_SUFFIXES[(i * 5) % DESI_SUFFIXES.length];
    const hindiBase = DESI_HINDI_TITLES[i % DESI_HINDI_TITLES.length];

    const title = `${prefix} ${nameA}: ${suffix} (Season ${Math.floor(i / 100) + 1})`;
    const hindiTitle = `${hindiBase} #${i}`;
    const cover = POSTER_POOL[i % POSTER_POOL.length];
    const videoUrl = VIDEO_STREAM_POOL[i % VIDEO_STREAM_POOL.length];

    const totalEps = 45 + (i % 55); // 45 to 100 episodes
    const views = `${((i % 80) / 10 + 1.5).toFixed(1)}M`;
    const rating = Number((8.8 + ((i % 12) / 10)).toFixed(1));

    let badge = undefined;
    if (i % 7 === 0) badge = '🔥 MicroTV Hit';
    else if (i % 9 === 0) badge = '🔞 18+ Steamy';
    else if (i % 5 === 0) badge = 'Trending';
    else if (i % 8 === 0) badge = 'Desi Binge';

    // Generate episode titles
    const episodes: ShortDramaEpisode[] = Array.from({ length: Math.min(25, totalEps) }, (_, epIdx) => ({
      episodeNumber: epIdx + 1,
      title: catConfig.isIndian
        ? `भाग ${epIdx + 1}: ${epIdx === 0 ? 'पहला टकराव' : epIdx === 1 ? 'बड़ा खुलासा' : 'कहानी में नया मोड़'}`
        : `Episode ${epIdx + 1}: ${epIdx === 0 ? 'The Encounter' : epIdx === 1 ? 'Secret Revealed' : 'The Turning Point'}`,
      duration: '1:45',
      videoUrl: videoUrl,
      thumbnail: cover,
      isFree: epIdx < 10,
    }));

    result.push({
      id: `drama-gen-${i}`,
      title,
      hindiTitle: catConfig.isIndian ? hindiTitle : undefined,
      category: catConfig.category,
      categoryLabel: catConfig.categoryLabel,
      language: catConfig.defaultLang,
      synopsis: `In this gripping episodic saga, ${nameA} uncovers a buried family secret involving ${nameB} and the vast wealth of the dynasty. Betrayals, hidden contracts, and midnight confrontations turn their world upside down across ${totalEps} high-voltage episodes.`,
      cover,
      banner: BANNER_POOL[i % BANNER_POOL.length],
      totalEpisodes: totalEps,
      views,
      rating: rating > 9.9 ? 9.8 : rating,
      badge,
      isIndian: catConfig.isIndian,
      episodes,
    });
  }

  return result;
}

export class ShortDramaService {
  private static _all: ShortDrama[] | null = null;

  static getAll(): ShortDrama[] {
    if (!this._all) {
      this._all = [...SHORT_DRAMA_FLAGSHIPS, ...generateExpandedDramas(1100)];
    }
    return this._all;
  }

  static getOfficialBanners(): ShortDrama[] {
    return SHORT_DRAMA_FLAGSHIPS.filter((d) => Boolean(d.banner));
  }

  static getTotalCount(): number {
    return this.getAll().length;
  }

  static getIndian(): ShortDrama[] {
    return this.getAll().filter((d) => d.isIndian);
  }

  static getByCategory(category: string): ShortDrama[] {
    const list = this.getAll();
    if (!category || category === 'all') return list;
    if (category === 'indian_only') return list.filter((d) => d.isIndian);
    return list.filter((d) => d.category === category);
  }

  static getById(id: string): ShortDrama | undefined {
    return this.getAll().find((d) => d.id === id);
  }

  static search(query: string, category = 'all'): ShortDrama[] {
    const q = query.toLowerCase().trim();
    let pool = this.getByCategory(category);
    if (!q) return pool;
    return pool.filter(
      (d) =>
        d.title.toLowerCase().includes(q) ||
        (d.hindiTitle && d.hindiTitle.toLowerCase().includes(q)) ||
        d.synopsis.toLowerCase().includes(q) ||
        d.categoryLabel.toLowerCase().includes(q)
    );
  }

  static getPaginated(
    page = 1,
    pageSize = 24,
    category = 'indian_only',
    query = ''
  ): {
    items: ShortDrama[];
    page: number;
    pageSize: number;
    totalCount: number;
    totalPages: number;
  } {
    const filtered = query.trim() ? this.search(query, category) : this.getByCategory(category);
    const totalCount = filtered.length;
    const totalPages = Math.ceil(totalCount / pageSize) || 1;
    const safePage = Math.max(1, Math.min(page, totalPages));
    const start = (safePage - 1) * pageSize;
    const items = filtered.slice(start, start + pageSize);

    return {
      items,
      page: safePage,
      pageSize,
      totalCount,
      totalPages,
    };
  }
}
