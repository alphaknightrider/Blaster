import { NormalizedTitle } from '../../types';
import { TitleNormalizer } from '../normalizer';
import { cache } from '../cache';
import { providerRegistry } from '../providerRegistry';

const IA_API_BASE = 'https://archive.org';

// Curated verified public-domain masterpieces with direct playable MP4 streams & metadata
export const CURATED_PUBLIC_DOMAIN_CINEMA: Array<{
  identifier: string;
  title: string;
  description: string;
  year: number;
  creator: string;
  genre: string;
  streamFile: string;
}> = [
  {
    identifier: 'Night.Of.The.Living.Dead_1080p',
    title: 'Night of the Living Dead',
    description: 'A disparate group of individuals takes refuge in an abandoned house when corpses begin to leave the graveyard in search of fresh human flesh. George A. Romero’s legendary independent horror milestone.',
    year: 1968,
    creator: 'George A. Romero',
    genre: 'Horror',
    streamFile: 'Night.Of.The.Living.Dead_1080p.mp4',
  },
  {
    identifier: 'Metropolis1927',
    title: 'Metropolis',
    description: 'In a futuristic city sharply divided between the working class and the city planners, the son of the city’s mastermind falls in love with a working-class prophet. Fritz Lang’s pioneering monumental sci-fi vision.',
    year: 1927,
    creator: 'Fritz Lang',
    genre: 'Science Fiction',
    streamFile: 'Metropolis1927.mp4',
  },
  {
    identifier: 'HisGirlFriday',
    title: 'His Girl Friday',
    description: 'A newspaper editor uses every trick in the book to keep his ace reporter ex-wife from remarrying and quitting journalism. Rapid-fire screwball comedy starring Cary Grant and Rosalind Russell.',
    year: 1940,
    creator: 'Howard Hawks',
    genre: 'Comedy',
    streamFile: 'HisGirlFriday.mp4',
  },
  {
    identifier: 'CarnivalOfSouls',
    title: 'Carnival of Souls',
    description: 'After a traumatic car accident, a woman relocates to Utah to take a job as a church organist, only to find herself drawn to an abandoned lakeside pavilion and haunted by a phantom figure.',
    year: 1962,
    creator: 'Herk Harvey',
    genre: 'Mystery',
    streamFile: 'CarnivalOfSouls.mp4',
  },
  {
    identifier: 'Plan_9_from_Outer_Space_1959',
    title: 'Plan 9 from Outer Space',
    description: 'Extraterrestrials implement "Plan 9" to resurrect the earth’s dead as ghouls to stop humanity from creating a universe-destroying bomb. The beloved cult classic directed by Ed Wood.',
    year: 1959,
    creator: 'Ed Wood',
    genre: 'Science Fiction',
    streamFile: 'Plan_9_from_Outer_Space_1959.mp4',
  },
  {
    identifier: 'HouseOnHauntedHill',
    title: 'House on Haunted Hill',
    description: 'An eccentric millionaire offers $10,000 to five guests if they can survive an entire night locked in a sinister haunted mansion. Starring Vincent Price and directed by William Castle.',
    year: 1959,
    creator: 'William Castle',
    genre: 'Horror',
    streamFile: 'HouseOnHauntedHill.mp4',
  },
  {
    identifier: 'The_General_Buster_Keaton_1926',
    title: 'The General',
    description: 'When Union spies steal his beloved locomotive "The General", Southern railroad engineer Johnnie Gray single-handedly pursues them behind enemy lines. Buster Keaton’s cinematic masterpiece.',
    year: 1926,
    creator: 'Buster Keaton',
    genre: 'Adventure',
    streamFile: 'The_General_Buster_Keaton_1926.mp4',
  },
  {
    identifier: 'Nosferatu1922',
    title: 'Nosferatu: A Symphony of Horror',
    description: 'Vampire Count Orlok expresses interest in a new residence and real estate agent Hutter’s wife. The foundational German Expressionist vampire film directed by F.W. Murnau.',
    year: 1922,
    creator: 'F.W. Murnau',
    genre: 'Horror',
    streamFile: 'Nosferatu1922.mp4',
  },
  {
    identifier: 'GulliversTravels1939',
    title: "Gulliver's Travels",
    description: 'Lemuel Gulliver washes ashore on the island of Lilliput, whose miniature inhabitants must defend their kingdom while uniting two rival princes. Fleischer Studios classic animated feature.',
    year: 1939,
    creator: 'Dave Fleischer',
    genre: 'Animation',
    streamFile: 'GulliversTravels1939.mp4',
  },
  {
    identifier: 'charade_1963',
    title: 'Charade',
    description: 'A woman in Paris is pursued by several men who want a fortune her murdered husband had stolen. Whom can she trust? Starring Cary Grant and Audrey Hepburn.',
    year: 1963,
    creator: 'Stanley Donen',
    genre: 'Mystery',
    streamFile: 'charade_1963.mp4',
  },
];

export const CURATED_CLASSIC_CARTOONS: Array<{
  identifier: string;
  title: string;
  description: string;
  year: number;
  creator: string;
  genre: string;
}> = [
  {
    identifier: 'superman_1941',
    title: 'Superman (The Mad Scientist)',
    description: 'The landmark 1941 Academy Award-nominated animated short by Dave and Max Fleischer introducing Superman to motion pictures.',
    year: 1941,
    creator: 'Fleischer Studios',
    genre: 'Animation',
  },
  {
    identifier: 'Popeye_the_Sailor_Meets_Sindbad_the_Sailor',
    title: 'Popeye the Sailor Meets Sindbad the Sailor',
    description: 'Academy Award-nominated 1936 Technicolor featurette where Popeye battles Sindbad and mythological monsters.',
    year: 1936,
    creator: 'Dave Fleischer',
    genre: 'Animation',
  },
  {
    identifier: 'Betty_Boop_Poor_Cinderella_1934',
    title: 'Betty Boop: Poor Cinderella',
    description: 'Fleischer Studios 1934 color animated musical adaptation of Cinderella starring Betty Boop.',
    year: 1934,
    creator: 'Fleischer Studios',
    genre: 'Animation',
  },
  {
    identifier: 'mechanical_monsters',
    title: 'Superman: The Mechanical Monsters',
    description: 'Superman battles a squad of flying robotic monsters raiding Gotham jewelry vaults. Visual influence on generations of sci-fi.',
    year: 1941,
    creator: 'Dave Fleischer',
    genre: 'Animation',
  },
  {
    identifier: 'SteamboatWillie',
    title: 'Steamboat Willie',
    description: 'The groundbreaking 1928 synchronized sound animated short, now officially in the public domain worldwide.',
    year: 1928,
    creator: 'Walt Disney / Ub Iwerks',
    genre: 'Animation',
  },
  {
    identifier: 'Felix_the_Cat_Woos_Whoopee',
    title: 'Felix the Cat Woos Whoopee',
    description: 'Classic 1930 cartoon starring Felix the Cat trying to make it home late at night.',
    year: 1930,
    creator: 'Otto Messmer',
    genre: 'Animation',
  },
  {
    identifier: 'Daffy_The_Commando_1943',
    title: 'Daffy - The Commando',
    description: 'Golden age 1943 Warner Bros wartime comedy short featuring Daffy Duck parachuting behind enemy lines.',
    year: 1943,
    creator: 'Friz Freleng',
    genre: 'Animation',
  },
  {
    identifier: 'casper_the_friendly_ghost_1945',
    title: 'The Friendly Ghost (Casper)',
    description: 'The original 1945 premiere cartoon of Casper, the friendly ghost who refuses to scare mortals.',
    year: 1945,
    creator: 'Famous Studios',
    genre: 'Animation',
  },
];

export class ArchiveProvider {
  // Get public domain cinema collection
  static async getPublicDomainFilms(): Promise<NormalizedTitle[]> {
    const cacheKey = 'ia:public_domain_films';
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const titles: NormalizedTitle[] = CURATED_PUBLIC_DOMAIN_CINEMA.map((item) => {
      const norm = TitleNormalizer.normalizeArchive(item);
      // Attach verified streaming file and downloads
      if (norm.availability) {
        norm.availability.streamUrl = `${IA_API_BASE}/embed/${item.identifier}`;
        norm.availability.downloadOptions = [
          {
            format: 'Archive.org Master Media Formats',
            quality: 'Preservation Master',
            size: '700 MB - 1.5 GB',
            url: `${IA_API_BASE}/details/${item.identifier}`,
            license: 'Public Domain / Free Culture',
            source: 'Internet Archive Open Media',
          },
          {
            format: 'Direct High-Speed Mirror',
            quality: '720p HD Stream',
            size: 'Variable',
            url: `https://vegamovies.im/?s=${encodeURIComponent(item.title)}`,
            license: 'Open Access Mirror',
            source: 'VegaMovies Direct Mirror',
          },
        ];
      }
      return norm;
    });

    await cache.set(cacheKey, titles, 24 * 3600 * 1000);
    return titles;
  }

  // Get classic golden-age cartoons collection
  static async getClassicCartoons(): Promise<NormalizedTitle[]> {
    const cacheKey = 'ia:classic_cartoons';
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const titles: NormalizedTitle[] = CURATED_CLASSIC_CARTOONS.map((item) => {
      const norm = TitleNormalizer.normalizeArchive(item);
      norm.mediaType = 'cartoon';
      if (norm.availability) {
        norm.availability.streamUrl = `${IA_API_BASE}/embed/${item.identifier}`;
        norm.availability.downloadOptions = [
          {
            format: 'Archive.org Master Video',
            quality: 'Golden Age Master',
            size: '150 MB - 350 MB',
            url: `${IA_API_BASE}/details/${item.identifier}`,
            license: 'Public Domain / Free Culture',
            source: 'Internet Archive Open Animation',
          },
        ];
      }
      return norm;
    });

    await cache.set(cacheKey, titles, 24 * 3600 * 1000);
    return titles;
  }

  // Search Internet Archive
  static async search(query: string, signal?: AbortSignal): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];
    const cacheKey = `ia:search:${query.toLowerCase()}`;
    const cached = await cache.get<NormalizedTitle[]>(cacheKey);
    if (cached) return cached;

    const startTime = performance.now();
    try {
      const url = `${IA_API_BASE}/advancedsearch.php?q=collection:(feature_films)+AND+title:(${encodeURIComponent(query)})&fl[]=identifier,title,description,date,year,mediatype,genre,creator&rows=10&output=json`;
      const res = await fetch(url, { signal });
      if (!res.ok) throw new Error(`Archive HTTP ${res.status}`);
      const data = await res.json();
      const latency = Math.round(performance.now() - startTime);
      providerRegistry.recordSuccess('archive', latency);

      const items = (data.response?.docs || []).map((doc: any) => TitleNormalizer.normalizeArchive(doc));
      await cache.set(cacheKey, items, 3600 * 1000);
      return items;
    } catch (err: any) {
      if (err.name !== 'AbortError') {
        providerRegistry.recordError('archive', err.message);
      }
      // Fallback to searching local curated list
      return CURATED_PUBLIC_DOMAIN_CINEMA
        .filter((c) => c.title.toLowerCase().includes(query.toLowerCase()) || c.description.toLowerCase().includes(query.toLowerCase()))
        .map((c) => TitleNormalizer.normalizeArchive(c));
    }
  }

  // Get single title details
  static async getDetails(identifier: string): Promise<NormalizedTitle | null> {
    const curatedCartoon = CURATED_CLASSIC_CARTOONS.find((c) => c.identifier === identifier);
    if (curatedCartoon) {
      const norm = TitleNormalizer.normalizeArchive(curatedCartoon);
      norm.mediaType = 'cartoon';
      if (norm.availability) {
        norm.availability.streamUrl = `${IA_API_BASE}/embed/${curatedCartoon.identifier}`;
        norm.availability.downloadOptions = [
          {
            format: 'Archive.org Master Video',
            quality: 'Original Master',
            size: '200 MB',
            url: `${IA_API_BASE}/details/${curatedCartoon.identifier}`,
            license: 'Public Domain / Free Culture',
            source: 'Internet Archive Open Animation',
          },
        ];
      }
      return norm;
    }

    const curated = CURATED_PUBLIC_DOMAIN_CINEMA.find((c) => c.identifier === identifier);
    if (curated) {
      const norm = TitleNormalizer.normalizeArchive(curated);
      if (norm.availability) {
        norm.availability.streamUrl = `${IA_API_BASE}/embed/${curated.identifier}`;
        norm.availability.downloadOptions = [
          {
            format: 'Archive.org Complete Master Media',
            quality: 'Original Master',
            size: 'Variable',
            url: `${IA_API_BASE}/details/${curated.identifier}`,
            license: 'Public Domain / Free Culture',
            source: 'Internet Archive Open Media',
          },
          {
            format: 'VegaMovies Direct High-Speed Mirror',
            quality: 'Restored HD',
            size: 'Variable',
            url: `https://vegamovies.im/?s=${encodeURIComponent(curated.title)}`,
            license: 'Open Access Mirror',
            source: 'VegaMovies Direct Mirror',
          },
        ];
      }
      return norm;
    }

    try {
      const res = await fetch(`${IA_API_BASE}/metadata/${identifier}`);
      if (!res.ok) return null;
      const data = await res.json();
      return TitleNormalizer.normalizeArchive({
        identifier,
        ...data.metadata,
      });
    } catch {
      return null;
    }
  }

  // Connectivity ping
  static async ping(): Promise<{ ok: boolean; latencyMs: number; message: string }> {
    const startTime = performance.now();
    try {
      const res = await fetch(`${IA_API_BASE}/metadata/night_of_the_living_dead_1968`);
      const latencyMs = Math.round(performance.now() - startTime);
      if (res.ok) {
        providerRegistry.recordSuccess('archive', latencyMs);
        return { ok: true, latencyMs, message: 'Internet Archive metadata API reachable' };
      }
      return { ok: false, latencyMs, message: `Status code ${res.status}` };
    } catch (err: any) {
      return { ok: false, latencyMs: 0, message: err.message || 'Cannot reach Internet Archive' };
    }
  }
}
