import { ProviderHealth, ProviderId } from '../types';
import { StorageManager } from '../storage';

class ProviderRegistry {
  private healthMap = new Map<ProviderId, ProviderHealth>([
    [
      'tmdb',
      {
        provider: 'tmdb',
        name: 'The Movie Database (TMDB)',
        status: 'online',
        latencyMs: 120,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'High-coverage metadata, trending, credits, trailers, and providers',
      },
    ],
    [
      'archive',
      {
        provider: 'archive',
        name: 'Internet Archive Public Domain Cinema',
        status: 'online',
        latencyMs: 95,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Authorized open public domain feature films, streams, and downloads',
      },
    ],
    [
      'wikidata',
      {
        provider: 'wikidata',
        name: 'Wikidata Semantic API',
        status: 'online',
        latencyMs: 140,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Structured entity facts, release dates, and director credentials',
      },
    ],
    [
      'watchmode',
      {
        provider: 'watchmode',
        name: 'Watchmode Availability Engine',
        status: 'online',
        latencyMs: 110,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Multi-platform streaming provider links and regional availability',
      },
    ],
    [
      'youtube',
      {
        provider: 'youtube',
        name: 'YouTube Official Trailers & Video API',
        status: 'online',
        latencyMs: 80,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'High-definition 1080p official theatrical trailers and teasers',
      },
    ],
    [
      'tvmaze',
      {
        provider: 'tvmaze',
        name: 'TVmaze Open Television API',
        status: 'online',
        latencyMs: 110,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: '100% free keyless broadcast television, show schedules, episodes, and cast',
      },
    ],
    [
      'anilist',
      {
        provider: 'anilist',
        name: 'AniList GraphQL Anime API',
        status: 'online',
        latencyMs: 90,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Decentralized open anime catalog, trending seasons, scores, and studios',
      },
    ],
    [
      'kitsu',
      {
        provider: 'kitsu',
        name: 'Kitsu Open Anime JSON:API',
        status: 'online',
        latencyMs: 120,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Free anime indexing and trending anime rankings',
      },
    ],
    [
      'vegamovies',
      {
        provider: 'vegamovies',
        name: 'VegaMovies Multi-Cloud Mirror Network',
        status: 'online',
        latencyMs: 75,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: '100,000+ Bollywood, South Hindi Dubbed, Dual Audio, and 4K mirrors',
      },
    ],
    [
      'peertube',
      {
        provider: 'peertube',
        name: 'PeerTube Federated Video Network',
        status: 'online',
        latencyMs: 140,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Decentralized open cinema, documentaries, and creative commons video',
      },
    ],
    [
      'wikimedia',
      {
        provider: 'wikimedia',
        name: 'Wikimedia Commons & Wikipedia API',
        status: 'online',
        latencyMs: 130,
        lastChecked: Date.now(),
        requestsCount: 0,
        errorCount: 0,
        details: 'Free encyclopedic film history, trivia, and public domain motion reels',
      },
    ],
  ]);

  getAll(): ProviderHealth[] {
    return Array.from(this.healthMap.values());
  }

  get(provider: ProviderId): ProviderHealth | undefined {
    return this.healthMap.get(provider);
  }

  recordSuccess(provider: ProviderId, latencyMs: number): void {
    const item = this.healthMap.get(provider);
    if (!item) return;
    item.requestsCount++;
    item.latencyMs = Math.round((item.latencyMs * 0.7) + (latencyMs * 0.3));
    item.status = 'online';
    item.lastChecked = Date.now();
  }

  recordError(provider: ProviderId, errorMsg: string): void {
    const item = this.healthMap.get(provider);
    if (!item) return;
    item.requestsCount++;
    item.errorCount++;
    item.lastChecked = Date.now();
    if (item.errorCount > 3) {
      item.status = 'degraded';
    }
    StorageManager.addLog('error', `Provider [${provider}] failure: ${errorMsg}`, provider);
  }

  updateStatus(provider: ProviderId, status: 'online' | 'degraded' | 'offline' | 'unconfigured', details?: string): void {
    const item = this.healthMap.get(provider);
    if (!item) return;
    item.status = status;
    item.lastChecked = Date.now();
    if (details) item.details = details;
  }
}

export const providerRegistry = new ProviderRegistry();
