interface CacheItem<T> {
  data: T;
  timestamp: number;
  ttl: number; // in milliseconds
}

class CacheService {
  private memoryCache = new Map<string, CacheItem<any>>();
  private maxMemoryEntries = 250;
  private dbPromise: Promise<IDBDatabase | null> | null = null;

  constructor() {
    this.initIndexedDB();
  }

  private initIndexedDB(): Promise<IDBDatabase | null> {
    if (this.dbPromise) return this.dbPromise;

    if (typeof window === 'undefined' || !window.indexedDB) {
      this.dbPromise = Promise.resolve(null);
      return this.dbPromise;
    }

    this.dbPromise = new Promise((resolve) => {
      try {
        const request = window.indexedDB.open('CyrusMoviesCache', 1);
        request.onupgradeneeded = (e: any) => {
          const db = e.target.result as IDBDatabase;
          if (!db.objectStoreNames.contains('api_cache')) {
            db.createObjectStore('api_cache', { keyPath: 'key' });
          }
        };
        request.onsuccess = (e: any) => {
          resolve(e.target.result as IDBDatabase);
        };
        request.onerror = () => {
          resolve(null);
        };
      } catch {
        resolve(null);
      }
    });

    return this.dbPromise;
  }

  async get<T>(key: string): Promise<T | null> {
    const now = Date.now();

    // Check memory first
    if (this.memoryCache.has(key)) {
      const entry = this.memoryCache.get(key)!;
      if (now - entry.timestamp < entry.ttl) {
        return entry.data as T;
      }
      this.memoryCache.delete(key);
    }

    // Check IndexedDB
    try {
      const db = await this.initIndexedDB();
      if (!db) return null;

      return new Promise<T | null>((resolve) => {
        try {
          const tx = db.transaction('api_cache', 'readonly');
          const store = tx.objectStore('api_cache');
          const req = store.get(key);
          req.onsuccess = () => {
            const result = req.result;
            if (result && now - result.timestamp < result.ttl) {
              // Populate memory cache
              this.setMemory(key, result.data, result.ttl);
              resolve(result.data as T);
            } else {
              resolve(null);
            }
          };
          req.onerror = () => resolve(null);
        } catch {
          resolve(null);
        }
      });
    } catch {
      return null;
    }
  }

  async set<T>(key: string, data: T, ttlMs: number = 3600 * 1000): Promise<void> {
    const timestamp = Date.now();
    this.setMemory(key, data, ttlMs);

    try {
      const db = await this.initIndexedDB();
      if (!db) return;

      const tx = db.transaction('api_cache', 'readwrite');
      const store = tx.objectStore('api_cache');
      store.put({ key, data, timestamp, ttl: ttlMs });
    } catch {
      // Ignore storage errors gracefully
    }
  }

  private setMemory<T>(key: string, data: T, ttl: number): void {
    if (this.memoryCache.size >= this.maxMemoryEntries) {
      // LRU eviction: remove first inserted
      const firstKey = this.memoryCache.keys().next().value;
      if (firstKey) this.memoryCache.delete(firstKey);
    }
    this.memoryCache.set(key, { data, timestamp: Date.now(), ttl });
  }

  async clear(): Promise<void> {
    this.memoryCache.clear();
    try {
      const db = await this.initIndexedDB();
      if (db) {
        const tx = db.transaction('api_cache', 'readwrite');
        tx.objectStore('api_cache').clear();
      }
    } catch {}
  }
}

export const cache = new CacheService();
