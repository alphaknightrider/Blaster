import { MediaType, NormalizedTitle, ProviderHealth } from '../types';
import { TmdbProvider } from './providers/tmdb';
import { ArchiveProvider } from './providers/archive';
import { TvmazeProvider } from './providers/tvmaze';
import { AnimeHubProvider } from './providers/animeHub';
import { PeerTubeProvider } from './providers/peertube';
import { WikimediaProvider } from './providers/wikimedia';
import { VegaMoviesProvider } from './providers/vegamovies';
import { TranslationProvider } from './providers/translator';
import { WatchmodeProvider } from './providers/watchmode';
import { YoutubeProvider } from './providers/youtube';
import { WikidataProvider } from './providers/wikidata';
import { ShortDramaService } from './providers/shortDrama';
import { providerRegistry } from './providerRegistry';
import { StorageManager } from '../storage';

export class ApiClient {
  // Unified Trending
  static async getTrending(type: 'movie' | 'tv' | 'all' = 'movie'): Promise<NormalizedTitle[]> {
    try {
      const tmdbTrending = await TmdbProvider.getTrending(type);
      if (tmdbTrending.length > 0) return tmdbTrending;
    } catch {}

    if (type === 'tv') {
      try {
        const tvmaze = await TvmazeProvider.getPopularShows(0);
        if (tvmaze.length > 0) return tvmaze;
      } catch {}
    }

    try {
      const vega = await VegaMoviesProvider.getHollywoodDualAudio(1);
      if (vega.length > 0) return vega;
    } catch {}

    // Fallback to Public Domain Cinema
    return ArchiveProvider.getPublicDomainFilms();
  }

  // Unified Popular
  static async getPopular(type: 'movie' | 'tv' = 'movie', page = 1): Promise<NormalizedTitle[]> {
    try {
      const res = await TmdbProvider.getPopular(type, page);
      if (res.length > 0) return res;
    } catch {}

    if (type === 'tv') {
      try {
        const tvmaze = await TvmazeProvider.getPopularShows(page - 1);
        if (tvmaze.length > 0) return tvmaze;
      } catch {}
    }

    try {
      const vega = await VegaMoviesProvider.getHollywoodDualAudio(page);
      if (vega.length > 0) return vega;
    } catch {}

    return ArchiveProvider.getPublicDomainFilms();
  }

  // Unified Top Rated
  static async getTopRated(type: 'movie' | 'tv' = 'movie', page = 1): Promise<NormalizedTitle[]> {
    try {
      const res = await TmdbProvider.getTopRated(type, page);
      if (res.length > 0) return res;
    } catch {}

    if (type === 'tv') {
      try {
        const tvmaze = await TvmazeProvider.getPopularShows(page);
        if (tvmaze.length > 0) return tvmaze;
      } catch {}
    }

    try {
      const vega = await VegaMoviesProvider.getBollywoodReleases(page);
      if (vega.length > 0) return vega;
    } catch {}

    return ArchiveProvider.getPublicDomainFilms();
  }

  // Upcoming
  static async getUpcoming(page = 1): Promise<NormalizedTitle[]> {
    try {
      return await TmdbProvider.getUpcoming(page);
    } catch {
      return [];
    }
  }

  // Public domain cinema
  static async getPublicDomainCinema(): Promise<NormalizedTitle[]> {
    return ArchiveProvider.getPublicDomainFilms();
  }

  // Discover with filters
  static async discover(options: {
    type?: 'movie' | 'tv';
    genreId?: number | string;
    language?: string;
    year?: number;
    sortBy?: string;
    page?: number;
  }): Promise<NormalizedTitle[]> {
    try {
      return await TmdbProvider.discover(options);
    } catch {
      return ArchiveProvider.getPublicDomainFilms();
    }
  }

  // Language specific (e.g. Hindi 'hi', Tamil 'ta', Telugu 'te', etc.)
  static async getByLanguage(languageCode: string, type: 'movie' | 'tv' = 'movie', page = 1): Promise<NormalizedTitle[]> {
    try {
      return await TmdbProvider.discover({
        type,
        language: languageCode,
        sortBy: 'popularity.desc',
        page,
      });
    } catch {
      return [];
    }
  }

  // Anime Hub (AniList & Kitsu)
  static async getAnimeCatalog(page = 1): Promise<NormalizedTitle[]> {
    return AnimeHubProvider.getTrendingAnime(page);
  }

  static async getTopRatedAnime(page = 1): Promise<NormalizedTitle[]> {
    return AnimeHubProvider.getTopRatedAnime(page);
  }

  // Classic Golden-Age Cartoons (Superman, Popeye, Betty Boop, Steamboat Willie)
  static async getClassicCartoons(): Promise<NormalizedTitle[]> {
    return ArchiveProvider.getClassicCartoons();
  }

  // TVmaze Shows Catalog
  static async getTvmazeShows(page = 0): Promise<NormalizedTitle[]> {
    return TvmazeProvider.getPopularShows(page);
  }

  // PeerTube Open Media Catalog
  static async getPeerTubeVideos(count = 20): Promise<NormalizedTitle[]> {
    return PeerTubeProvider.getVideos(count);
  }

  // Wikimedia Commons Historical Reels
  static async getWikimediaReels(query = 'silent film'): Promise<NormalizedTitle[]> {
    return WikimediaProvider.searchCommonsVideos(query);
  }

  // Universal Search across TMDB, TVmaze, AniList, Internet Archive, and PeerTube
  static async search(
    query: string,
    filters?: {
      type?: 'all' | 'movie' | 'tv' | 'anime' | 'cartoon' | 'archive' | 'peertube' | 'short';
      year?: number;
      genreId?: number | string;
    },
    signal?: AbortSignal
  ): Promise<NormalizedTitle[]> {
    if (!query.trim()) return [];

    const promises: Promise<NormalizedTitle[]>[] = [];

    // Search TMDB (Movies & TV)
    if (!filters?.type || filters.type === 'all' || filters.type === 'movie' || filters.type === 'tv') {
      const tmdbType = filters?.type === 'tv' ? 'tv' : (filters?.type === 'movie' ? 'movie' : 'multi');
      promises.push(TmdbProvider.search(query, tmdbType, 1, signal));
    }

    // Search TVmaze (Television broadcast shows)
    if (!filters?.type || filters.type === 'all' || filters.type === 'tv') {
      promises.push(TvmazeProvider.search(query, signal));
    }

    // Search Anime (AniList / Kitsu)
    if (!filters?.type || filters.type === 'all' || filters.type === 'anime') {
      promises.push(AnimeHubProvider.search(query, signal));
    }

    // Search Internet Archive (Public domain films & classic cartoons)
    if (!filters?.type || filters.type === 'all' || filters.type === 'archive' || filters.type === 'cartoon') {
      promises.push(ArchiveProvider.search(query, signal));
    }

    // Search PeerTube (Open federated media)
    if (!filters?.type || filters.type === 'all' || filters.type === 'peertube') {
      promises.push(PeerTubeProvider.search(query, signal));
    }

    try {
      const resultsArray = await Promise.allSettled(promises);
      const combined: NormalizedTitle[] = [];

      for (const res of resultsArray) {
        if (res.status === 'fulfilled') {
          combined.push(...res.value);
        }
      }

      // Include matching Short Dramas only if explicitly searching reels/short or browsing all with empty query
      if (filters?.type === 'short') {
        try {
          const dramaMatches = ShortDramaService.search(query).slice(0, 12);
          for (const d of dramaMatches) {
            combined.push({
              id: `shortdrama:${d.id}`,
              rawId: d.id,
              provider: 'archive',
              mediaType: 'short',
              title: d.hindiTitle || d.title,
              overview: d.synopsis,
              poster: d.cover,
              backdrop: d.cover,
              releaseDate: '2025',
              year: 2025,
              rating: d.rating,
              language: d.language,
              genres: [{ id: d.category, name: d.categoryLabel }],
              availability: {
                free: true,
                publicDomain: false,
                streamUrl: d.episodes[0]?.videoUrl,
              },
            });
          }
        } catch {}
      }

      // Filter by year if requested
      let filtered = combined;
      if (filters?.year) {
        filtered = filtered.filter((item) => item.year === filters.year);
      }

      // Remove duplicates based on ID or normalized title
      const seen = new Set<string>();
      return filtered.filter((item) => {
        if (seen.has(item.id)) return false;
        seen.add(item.id);
        return true;
      });
    } catch {
      return [];
    }
  }

  // Parse ID and get details across all federated providers
  static async getTitleDetails(qualifiedId: string): Promise<NormalizedTitle | null> {
    if (!qualifiedId) return null;

    // 1. TVmaze
    if (qualifiedId.startsWith('tvmaze:')) {
      const rawId = qualifiedId.replace(/^tvmaze:/, '');
      return await TvmazeProvider.getDetails(rawId);
    }

    // 2. AniList Anime
    if (qualifiedId.startsWith('anilist:')) {
      const rawId = qualifiedId.replace(/^anilist:/, '');
      return await AnimeHubProvider.getDetails(rawId);
    }

    // 3. PeerTube
    if (qualifiedId.startsWith('peertube:')) {
      const rawId = qualifiedId.replace(/^peertube:/, '');
      return await PeerTubeProvider.getDetails(rawId);
    }

    // 4. Internet Archive
    if (qualifiedId.startsWith('ia:')) {
      const rawId = qualifiedId.replace(/^ia:/, '');
      return await ArchiveProvider.getDetails(rawId);
    }

    // 5. TMDB
    if (qualifiedId.startsWith('tmdb:')) {
      const parts = qualifiedId.split(':');
      const type = (parts[1] as 'movie' | 'tv') || 'movie';
      const rawId = parts[2];
      const title = await TmdbProvider.getDetails(type, rawId);

      // Enhance with watchmode and Wikipedia trivia
      if (title) {
        try {
          const [wmSources, wikiInfo] = await Promise.allSettled([
            WatchmodeProvider.getSources(title.title, title.externalIds?.imdbId),
            WikimediaProvider.getMovieSummary(title.title, title.year),
          ]);

          if (wmSources.status === 'fulfilled' && wmSources.value.length > 0 && title.availability) {
            title.availability.watchProviders = [...(title.availability.watchProviders || []), ...wmSources.value];
          }

          if (wikiInfo.status === 'fulfilled' && wikiInfo.value?.pageUrl && title.externalIds) {
            title.externalIds.wikipediaUrl = wikiInfo.value.pageUrl;
          }
        } catch {}
      }
      return title;
    }

    // Direct numeric TMDB ID or raw ID fallback
    try {
      const movieRes = await TmdbProvider.getDetails('movie', qualifiedId);
      if (movieRes) return movieRes;
    } catch {}

    try {
      const tvRes = await TmdbProvider.getDetails('tv', qualifiedId);
      if (tvRes) return tvRes;
    } catch {}

    // Fallback to archive
    return await ArchiveProvider.getDetails(qualifiedId);
  }

  // Database-free recommendation engine:
  // Combines user watchlist genres, viewing history, and provider similar titles
  static async getPersonalizedRecommendations(limit = 12): Promise<NormalizedTitle[]> {
    const watchlist = StorageManager.getWatchlist();
    const history = StorageManager.getHistory();

    // Collect preferred genre IDs
    const genreCountMap = new Map<number | string, number>();
    for (const item of watchlist) {
      for (const g of item.genres || []) {
        genreCountMap.set(g.id, (genreCountMap.get(g.id) || 0) + 1);
      }
    }

    // Top preferred genre
    let topGenreId: number | string | undefined;
    let maxCount = 0;
    for (const [gid, count] of genreCountMap.entries()) {
      if (count > maxCount) {
        maxCount = count;
        topGenreId = gid;
      }
    }

    if (topGenreId) {
      try {
        const results = await TmdbProvider.discover({
          genreId: topGenreId,
          sortBy: 'vote_average.desc',
        });
        // Filter out items already in watchlist or history
        const watchedIds = new Set([...watchlist.map((w) => w.id), ...history.map((h) => h.id)]);
        return results.filter((r) => !watchedIds.has(r.id)).slice(0, limit);
      } catch {}
    }

    // Fallback: Return top rated
    return await this.getTopRated('movie', 1);
  }

  // Ping all providers for Admin diagnostics
  static async pingAll(): Promise<ProviderHealth[]> {
    await Promise.allSettled([
      TmdbProvider.ping(),
      ArchiveProvider.ping(),
      TvmazeProvider.ping(),
      WatchmodeProvider.ping(),
      YoutubeProvider.ping(),
      WikidataProvider.ping(),
    ]);
    return providerRegistry.getAll();
  }
}
