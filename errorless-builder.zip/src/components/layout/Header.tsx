import React, { useEffect, useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Search, Bookmark, Settings, Globe, Film } from 'lucide-react';

export const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const location = useLocation();
  const { t, language, setLanguage, watchlist, setSearchOpen } = useApp();

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 30);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { label: t.nav.home, path: '/' },
    { label: '⚡ VegaMovies', path: '/vegamovies' },
    { label: '🔥 Reels & ShortDrama', path: '/reels' },
    { label: t.nav.movies, path: '/movies' },
    { label: t.nav.tvShows, path: '/tv' },
    { label: t.nav.anime, path: '/anime' },
    { label: 'Cartoons', path: '/cartoons' },
    { label: t.nav.discover, path: '/discover' },
    { label: t.nav.genres, path: '/genres' },
  ];

  const isCurrent = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 transition-colors duration-300 ${
        scrolled ? 'glass-header py-3' : 'bg-gradient-to-b from-[#090A0F]/90 via-[#090A0F]/40 to-transparent py-4'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between gap-4">
        {/* Zone 1: Brand & Logo */}
        <Link to="/" className="flex items-center gap-2.5 group shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-[#8B5CF6] to-[#38BDF8] p-[1.5px] flex items-center justify-center shadow-lg shadow-[#8B5CF6]/20">
            <div className="w-full h-full bg-[#090A0F] rounded-[7px] flex items-center justify-center">
              <svg className="w-4 h-4 text-white group-hover:scale-110 transition-transform" viewBox="0 0 24 24" fill="none">
                <path
                  d="M19 12C19 15.866 15.866 19 12 19C8.13401 19 5 15.866 5 12C5 8.13401 8.13401 5 12 5"
                  stroke="url(#cyrus-gradient)"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
                <polygon points="10 8 16 12 10 16 10 8" fill="#38BDF8" />
                <defs>
                  <linearGradient id="cyrus-gradient" x1="5" y1="5" x2="19" y2="19">
                    <stop stopColor="#8B5CF6" />
                    <stop offset="1" stopColor="#38BDF8" />
                  </linearGradient>
                </defs>
              </svg>
            </div>
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-white group-hover:text-slate-200 transition-colors font-['Manrope'] leading-none">
              CYRUS <span className="text-[#8B5CF6]">MOVIES</span>
            </span>
            <span className="text-[10px] text-slate-400 font-medium tracking-wider uppercase leading-tight hidden sm:block">
              {t.common.tagline}
            </span>
          </div>
        </Link>

        {/* Zone 2: Navigation Links (Desktop) */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-300">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`transition-colors py-1 ${
                isCurrent(link.path)
                  ? 'text-white border-b-2 border-[#8B5CF6] font-semibold'
                  : 'hover:text-white'
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Zone 3: Actions */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Quick Search trigger */}
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#181B27]/80 hover:bg-[#181B27] border border-[#292D3A] text-xs text-slate-300 hover:text-white transition-all shadow-sm"
            title="Search cinema (Ctrl+K)"
          >
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span className="hidden sm:inline text-slate-400">{t.nav.search}</span>
            <kbd className="hidden lg:inline-block px-1.5 py-0.5 text-[10px] bg-[#090A0F] border border-[#292D3A] rounded text-slate-400">
              ⌘K
            </kbd>
          </button>

          {/* Language Switcher */}
          <button
            onClick={() => setLanguage(language === 'en' ? 'hi' : 'en')}
            className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#181B27]/80 hover:bg-[#181B27] border border-[#292D3A] text-xs font-medium text-slate-300 hover:text-white transition-colors"
            title="Change language"
          >
            <Globe className="w-3.5 h-3.5 text-[#38BDF8]" />
            <span>{language === 'en' ? 'HI' : 'EN'}</span>
          </button>

          {/* Watchlist */}
          <Link
            to="/watchlist"
            className="relative p-2 rounded-lg bg-[#181B27]/80 hover:bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white transition-colors"
            title={t.nav.watchlist}
          >
            <Bookmark className="w-4 h-4" />
            {watchlist.length > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#8B5CF6] text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-[#090A0F]">
                {watchlist.length > 99 ? '99+' : watchlist.length}
              </span>
            )}
          </Link>

          {/* Settings */}
          <Link
            to="/settings"
            className="p-2 rounded-lg bg-[#181B27]/80 hover:bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white transition-colors"
            title={t.nav.settings}
          >
            <Settings className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </header>
  );
};
