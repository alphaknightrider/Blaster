import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Home, Film, Tv, Compass, Bookmark, Search, Zap, Flame } from 'lucide-react';

export const BottomNav: React.FC = () => {
  const location = useLocation();
  const { t, watchlist, setSearchOpen } = useApp();

  const isCurrent = (path: string) => {
    if (path === '/' && location.pathname === '/') return true;
    if (path !== '/' && location.pathname.startsWith(path)) return true;
    return false;
  };

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#090A0F]/95 backdrop-blur-lg border-t border-[#292D3A] px-2 py-1 safe-area-bottom">
      <div className="flex items-center justify-around h-14">
        <Link
          to="/"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium leading-none">{t.nav.home}</span>
        </Link>

        <Link
          to="/vegamovies"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/vegamovies') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Zap className="w-5 h-5 mb-0.5 text-amber-400" />
          <span className="text-[10px] font-bold leading-none">Vega</span>
        </Link>

        <Link
          to="/reels"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/reels') ? 'text-rose-500 font-bold' : 'text-slate-400 hover:text-rose-400'
          }`}
        >
          <Flame className="w-5 h-5 mb-0.5 text-rose-500 animate-pulse" />
          <span className="text-[10px] font-bold leading-none text-rose-400">Reels</span>
        </Link>

        <Link
          to="/movies"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/movies') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Film className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium leading-none">{t.nav.movies}</span>
        </Link>

        <Link
          to="/tv"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/tv') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Tv className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium leading-none">{t.nav.tvShows}</span>
        </Link>

        <Link
          to="/discover"
          className={`flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/discover') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Compass className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium leading-none">{t.nav.discover}</span>
        </Link>

        <Link
          to="/watchlist"
          className={`relative flex flex-col items-center justify-center flex-1 py-1 transition-colors ${
            isCurrent('/watchlist') ? 'text-[#8B5CF6]' : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          <Bookmark className="w-5 h-5 mb-0.5" />
          {watchlist.length > 0 && (
            <span className="absolute top-1 right-3 w-3.5 h-3.5 bg-[#8B5CF6] text-white text-[9px] font-bold rounded-full flex items-center justify-center">
              {watchlist.length}
            </span>
          )}
          <span className="text-[10px] font-medium leading-none">{t.nav.watchlist}</span>
        </Link>

        <button
          onClick={() => setSearchOpen(true)}
          className="flex flex-col items-center justify-center flex-1 py-1 text-slate-400 hover:text-slate-200 transition-colors"
        >
          <Search className="w-5 h-5 mb-0.5" />
          <span className="text-[10px] font-medium leading-none">{t.nav.search}</span>
        </button>
      </div>
    </nav>
  );
};
