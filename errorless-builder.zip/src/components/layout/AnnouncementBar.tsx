import React from 'react';
import { useApp } from '../../context/AppContext';
import { X, Sparkles } from 'lucide-react';

export const AnnouncementBar: React.FC = () => {
  const { announcementVisible, dismissAnnouncement, t } = useApp();

  if (!announcementVisible) return null;

  return (
    <div className="bg-gradient-to-r from-[#181B27] via-[#201c38] to-[#181B27] border-b border-[#292D3A] text-xs text-[#F8FAFC] py-2 px-4 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 overflow-hidden">
          <Sparkles className="w-3.5 h-3.5 text-[#8B5CF6] shrink-0" />
          <p className="truncate text-slate-300 font-medium">
            {t.home.announcement}
          </p>
        </div>
        <button
          onClick={dismissAnnouncement}
          aria-label={t.home.dismiss}
          className="shrink-0 text-slate-400 hover:text-white p-1 rounded transition-colors"
        >
          <X className="w-3.5 h-3.5" />
        </button>
      </div>
    </div>
  );
};
