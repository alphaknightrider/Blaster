import React from 'react';
import { Link } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { ShieldCheck, HardDrive, DatabaseZap, Cpu } from 'lucide-react';

export const Footer: React.FC = () => {
  const { t } = useApp();

  return (
    <footer className="bg-[#090A0F] border-t border-[#292D3A] text-slate-400 text-xs py-12 px-4 sm:px-6 lg:px-8 pb-24 md:pb-12 mt-16">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Core architectural trust badges */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 p-4 rounded-xl bg-[#11131B] border border-[#292D3A]/60 text-slate-300">
          <div className="flex items-center gap-3">
            <DatabaseZap className="w-5 h-5 text-[#8B5CF6] shrink-0" />
            <div>
              <p className="font-semibold text-white text-xs">Zero Database Storage</p>
              <p className="text-[11px] text-slate-400">100% Client-Side Local Storage & IndexedDB</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Cpu className="w-5 h-5 text-[#38BDF8] shrink-0" />
            <div>
              <p className="font-semibold text-white text-xs">Multi-API Federation</p>
              <p className="text-[11px] text-slate-400">Real-time failover across TMDB, Archive & Wikidata</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
            <div>
              <p className="font-semibold text-white text-xs">Authorized Media Sources</p>
              <p className="text-[11px] text-slate-400">Public domain cinema & verified official embeds</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <HardDrive className="w-5 h-5 text-amber-400 shrink-0" />
            <div>
              <p className="font-semibold text-white text-xs">Private By Design</p>
              <p className="text-[11px] text-slate-400">No trackers, cookies or remote accounts</p>
            </div>
          </div>
        </div>

        {/* Links & Brand */}
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6 border-t border-[#292D3A]/40 pt-8">
          <div>
            <span className="text-base font-bold text-white tracking-wider font-['Manrope']">
              CYRUS <span className="text-[#8B5CF6]">MOVIES</span>
            </span>
            <p className="text-slate-400 text-xs mt-1">
              Your World of Cinema — High-Fidelity Discovery & Streaming Federation.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-xs">
            <Link to="/about" className="hover:text-white transition-colors">
              {t.nav.about}
            </Link>
            <Link to="/privacy" className="hover:text-white transition-colors">
              Privacy Policy
            </Link>
            <Link to="/terms" className="hover:text-white transition-colors">
              Terms of Service
            </Link>
            <Link to="/admin" className="hover:text-white transition-colors flex items-center gap-1 text-[#8B5CF6]">
              <span>{t.nav.admin}</span>
            </Link>
          </div>
        </div>

        {/* Attributions */}
        <div className="text-[11px] text-slate-500 space-y-1">
          <p>
            This product uses the TMDB API but is not endorsed or certified by TMDB. Public-domain media files and stream assets are retrieved from the Internet Archive open culture repository.
          </p>
          <p>
            © {new Date().getFullYear()} Cyrus Movies. Designed for fluid cinematic discovery without cloud databases.
          </p>
        </div>
      </div>
    </footer>
  );
};
