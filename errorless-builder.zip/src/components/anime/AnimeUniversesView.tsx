import React, { useEffect, useState } from 'react';
import {
  AnimeUniverseService,
  DragonBallCharacter,
  DattebayoCharacter,
} from '../../services/providers/animeUniverse';
import { Zap, Shield, Sparkles, Flame, User, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

export const AnimeUniversesView: React.FC = () => {
  const [universe, setUniverse] = useState<'dragonball' | 'dattebayo'>('dragonball');
  const [dbCharacters, setDbCharacters] = useState<DragonBallCharacter[]>([]);
  const [dbLoading, setDbLoading] = useState(true);

  const [narutoCharacters, setNarutoCharacters] = useState<DattebayoCharacter[]>([]);
  const [narutoLoading, setNarutoLoading] = useState(true);

  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    let cancelled = false;
    AnimeUniverseService.getDragonBallCharacters(16)
      .then((data) => {
        if (!cancelled) setDbCharacters(data);
      })
      .finally(() => {
        if (!cancelled) setDbLoading(false);
      });

    AnimeUniverseService.getDattebayoCharacters(1)
      .then((data) => {
        if (!cancelled) setNarutoCharacters(data);
      })
      .finally(() => {
        if (!cancelled) setNarutoLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  const filteredDb = dbCharacters.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.race.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredNaruto = narutoCharacters.filter(
    (c) =>
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.personal?.clan?.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      {/* Subheader & Universe Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#11131B] border border-[#292D3A]">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setUniverse('dragonball')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              universe === 'dragonball'
                ? 'bg-amber-500 text-slate-950 shadow-lg shadow-amber-500/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            <Zap className="w-3.5 h-3.5 fill-current" />
            <span>Dragon Ball Universe (Official API)</span>
          </button>

          <button
            onClick={() => setUniverse('dattebayo')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              universe === 'dattebayo'
                ? 'bg-orange-500 text-white shadow-lg shadow-orange-500/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            <Flame className="w-3.5 h-3.5 fill-current" />
            <span>Dattebayo (Naruto & Boruto API)</span>
          </button>
        </div>

        {/* Quick Filter */}
        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder={universe === 'dragonball' ? 'Filter Saiyans, Goku, Vegeta...' : 'Filter Ninja, Clan, Hokage...'}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#181B27] border border-[#292D3A] rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#8B5CF6]"
          />
        </div>
      </div>

      {/* Dragon Ball Universe View */}
      {universe === 'dragonball' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Powered by official Dragon Ball API · Live power level & Ki telemetry</span>
            <span>{filteredDb.length} Fighters listed</span>
          </div>

          {dbLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-64 bg-[#181B27] rounded-2xl border border-[#292D3A]" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredDb.map((fighter) => (
                <div
                  key={fighter.id}
                  className="rounded-2xl bg-[#181B27] border border-[#292D3A] p-4 flex flex-col justify-between hover:border-amber-400/50 transition-all group"
                >
                  <div>
                    <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-[#11131B] flex items-center justify-center mb-3">
                      <img
                        src={fighter.image}
                        alt={fighter.name}
                        className="h-full object-contain group-hover:scale-105 transition-transform duration-300"
                      />
                      <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-amber-300 text-[10px] font-bold border border-amber-500/30">
                        {fighter.race}
                      </span>
                    </div>

                    <h4 className="font-extrabold text-white text-base group-hover:text-amber-400 transition-colors">
                      {fighter.name}
                    </h4>
                    <p className="text-[11px] text-slate-400 font-medium mb-3">{fighter.affiliation}</p>

                    <div className="space-y-1.5 p-2.5 rounded-xl bg-[#11131B] border border-[#292D3A] text-[11px]">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Base Ki:</span>
                        <span className="text-amber-400 font-bold tabular-nums">{fighter.ki}</span>
                      </div>
                      <div className="flex items-center justify-between border-t border-[#292D3A] pt-1">
                        <span className="text-slate-400">Max Ki:</span>
                        <span className="text-orange-400 font-bold tabular-nums text-[10px]">{fighter.maxKi}</span>
                      </div>
                    </div>

                    {fighter.description && (
                      <p className="text-[11px] text-slate-300 line-clamp-2 mt-2 leading-relaxed">
                        {fighter.description}
                      </p>
                    )}
                  </div>

                  <div className="pt-3 mt-3 border-t border-[#292D3A]/60 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 font-medium">Z Fighters Database</span>
                    <Link
                      to={`/search?q=${encodeURIComponent('Dragon Ball ' + fighter.name)}`}
                      className="text-[11px] font-bold text-amber-400 hover:text-amber-300 flex items-center gap-1"
                    >
                      Watch Series
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Dattebayo Naruto Universe View */}
      {universe === 'dattebayo' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Powered by official Dattebayo Naruto & Boruto API · Ninja Clans & Jutsu Compendium</span>
            <span>{filteredNaruto.length} Shinobi listed</span>
          </div>

          {narutoLoading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 animate-pulse">
              {Array.from({ length: 8 }).map((_, i) => (
                <div key={i} className="h-64 bg-[#181B27] rounded-2xl border border-[#292D3A]" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {filteredNaruto.map((ninja) => (
                <div
                  key={ninja.id}
                  className="rounded-2xl bg-[#181B27] border border-[#292D3A] p-4 flex flex-col justify-between hover:border-orange-500/50 transition-all group"
                >
                  <div>
                    <div className="relative aspect-square w-full rounded-xl overflow-hidden bg-[#11131B] flex items-center justify-center mb-3">
                      {ninja.images && ninja.images[0] ? (
                        <img
                          src={ninja.images[0]}
                          alt={ninja.name}
                          className="h-full object-contain group-hover:scale-105 transition-transform duration-300"
                        />
                      ) : (
                        <User className="w-12 h-12 text-slate-600" />
                      )}
                      {ninja.personal?.clan && (
                        <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-orange-400 text-[10px] font-bold border border-orange-500/30">
                          {ninja.personal.clan} Clan
                        </span>
                      )}
                    </div>

                    <h4 className="font-extrabold text-white text-base group-hover:text-orange-400 transition-colors">
                      {ninja.name}
                    </h4>

                    {ninja.personal?.classification && (
                      <p className="text-[11px] text-slate-400 font-medium mb-2">
                        {Array.isArray(ninja.personal.classification)
                          ? ninja.personal.classification.join(' / ')
                          : ninja.personal.classification}
                      </p>
                    )}

                    {ninja.jutsu && ninja.jutsu.length > 0 && (
                      <div className="space-y-1 mt-2">
                        <span className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                          Signature Jutsu:
                        </span>
                        <div className="flex flex-wrap gap-1">
                          {ninja.jutsu.slice(0, 3).map((j) => (
                            <span
                              key={j}
                              className="px-2 py-0.5 rounded-md bg-[#11131B] text-[10px] text-slate-300 border border-[#292D3A] font-medium"
                            >
                              {j}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="pt-3 mt-3 border-t border-[#292D3A]/60 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500 font-medium">Dattebayo DB</span>
                    <Link
                      to={`/search?q=${encodeURIComponent('Naruto ' + ninja.name)}`}
                      className="text-[11px] font-bold text-orange-400 hover:text-orange-300 flex items-center gap-1"
                    >
                      Watch Episodes
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
