import React, { useState } from 'react';
import { AnimeUniverseService, TraceMoeResult } from '../../services/providers/animeUniverse';
import { Search, Image, Sparkles, CheckCircle2, Play, ExternalLink, RefreshCw } from 'lucide-react';
import { Link } from 'react-router-dom';

const SAMPLE_SCREENS = [
  {
    title: 'Attack on Titan (Eren Scout Regiment)',
    url: 'https://wsrv.nl/?url=https://image.tmdb.org/t/p/w780/h8AMk2kHqJ1aT2v4b6YyV2t7Z9c.jpg',
  },
  {
    title: 'Demon Slayer (Tanjiro Water Breathing)',
    url: 'https://wsrv.nl/?url=https://image.tmdb.org/t/p/w780/xUfRZu2mi8jH69hm0DxEFUmBTm5.jpg',
  },
  {
    title: 'Jujutsu Kaisen (Gojo Hollow Purple)',
    url: 'https://wsrv.nl/?url=https://image.tmdb.org/t/p/w780/hD04x51F2Gf5j0Wb09YjM3yK6qL.jpg',
  },
  {
    title: 'Spirited Away (Chihiro & Haku)',
    url: 'https://wsrv.nl/?url=https://image.tmdb.org/t/p/w780/Ab8mkHmkYADjU7wQiOkia9BzGvS.jpg',
  },
];

export const WhatAnimeSearch: React.FC = () => {
  const [imageUrl, setImageUrl] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState<TraceMoeResult[] | null>(null);
  const [searchedUrl, setSearchedUrl] = useState('');

  const handleSearch = async (urlToSearch: string) => {
    if (!urlToSearch.trim()) return;
    setSearching(true);
    setSearchedUrl(urlToSearch);
    try {
      const res = await AnimeUniverseService.searchTraceMoeByUrl(urlToSearch.trim());
      setResults(res);
    } catch {
      setResults([]);
    } finally {
      setSearching(false);
    }
  };

  const formatSeconds = (sec: number) => {
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60);
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#11131B] border border-[#292D3A] space-y-4 shadow-xl">
        <div className="max-w-2xl">
          <div className="flex items-center gap-2 text-xs font-bold text-[#A78BFA] uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Trace.moe Reverse Anime Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-['Manrope']">
            Identify Any Anime Scene from a Screenshot
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 leading-relaxed">
            Paste an image link or select a sample frame below. What Anime analyzes pixel frames against millions of anime episodes to identify the exact series, episode, and timestamp.
          </p>
        </div>

        {/* Input bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSearch(imageUrl);
          }}
          className="flex flex-col sm:flex-row gap-3 pt-2"
        >
          <div className="relative flex-1">
            <Image className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="url"
              placeholder="Paste anime screenshot image URL (JPEG/PNG/WebP)..."
              value={imageUrl}
              onChange={(e) => setImageUrl(e.target.value)}
              className="w-full bg-[#181B27] border border-[#292D3A] rounded-2xl pl-10 pr-4 py-3 text-xs sm:text-sm text-white placeholder-slate-500 focus:outline-none focus:border-[#8B5CF6]"
            />
          </div>

          <button
            type="submit"
            disabled={searching || !imageUrl.trim()}
            className="flex items-center justify-center gap-2 px-6 py-3 rounded-2xl bg-[#8B5CF6] text-white text-xs sm:text-sm font-bold hover:bg-[#7c4def] disabled:opacity-50 transition-colors shadow-lg shadow-[#8B5CF6]/20 cursor-pointer"
          >
            {searching ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Scanning Frame...</span>
              </>
            ) : (
              <>
                <Search className="w-4 h-4" />
                <span>Analyze Frame</span>
              </>
            )}
          </button>
        </form>

        {/* Quick Sample Screenshots */}
        <div className="pt-2">
          <span className="text-[11px] font-semibold text-slate-400 block mb-2">Or test with verified sample screenshots:</span>
          <div className="flex flex-wrap gap-2">
            {SAMPLE_SCREENS.map((s) => (
              <button
                key={s.title}
                type="button"
                onClick={() => {
                  setImageUrl(s.url);
                  handleSearch(s.url);
                }}
                className="px-3 py-1.5 rounded-xl bg-[#181B27] hover:bg-[#222736] border border-[#292D3A] text-[11px] font-semibold text-slate-300 hover:text-white transition-colors cursor-pointer"
              >
                {s.title}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Results View */}
      {results && (
        <div className="space-y-4">
          <h3 className="text-lg font-bold text-white font-['Manrope'] flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            Detected Anime Matches ({results.length})
          </h3>

          {results.length === 0 ? (
            <div className="p-8 text-center text-slate-400 bg-[#11131B] rounded-2xl border border-[#292D3A]">
              No exact frame match found. Try another screenshot with higher contrast.
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {results.map((res, i) => (
                <div
                  key={i}
                  className="p-5 rounded-2xl bg-[#181B27] border border-[#292D3A] flex flex-col sm:flex-row gap-4 items-start"
                >
                  <div className="relative aspect-video w-full sm:w-48 rounded-xl overflow-hidden bg-black shrink-0 border border-[#292D3A]">
                    <img
                      src={res.image || searchedUrl}
                      alt={res.filename}
                      className="w-full h-full object-cover"
                    />
                    <span className="absolute bottom-1 right-1 px-1.5 py-0.5 rounded bg-black/80 backdrop-blur-md text-[10px] font-bold text-emerald-400 border border-emerald-500/30">
                      {res.similarity}% Match
                    </span>
                  </div>

                  <div className="flex-1 space-y-2 overflow-hidden">
                    <div>
                      <span className="px-2 py-0.5 rounded bg-[#8B5CF6]/20 text-[#A78BFA] text-[10px] font-bold uppercase tracking-wider">
                        AniList ID #{res.anilist}
                      </span>
                      <h4 className="font-bold text-white text-sm line-clamp-2 mt-1">
                        {res.filename || `Anime Title (AniList #${res.anilist})`}
                      </h4>
                    </div>

                    <div className="space-y-1 text-xs text-slate-400">
                      <div className="flex items-center justify-between">
                        <span>Episode:</span>
                        <span className="text-white font-semibold">{res.episode}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Timestamp:</span>
                        <span className="text-white font-semibold font-mono">
                          {formatSeconds(res.from)} - {formatSeconds(res.to)}
                        </span>
                      </div>
                    </div>

                    <div className="pt-2 flex items-center gap-2">
                      <Link
                        to={`/search?q=${encodeURIComponent(res.filename.replace(/\.mkv|\.mp4|\[.*?\]/g, '').trim())}`}
                        className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#8B5CF6] text-white text-xs font-bold hover:bg-[#7c4def] transition-colors"
                      >
                        <Play className="w-3.5 h-3.5 fill-current" />
                        <span>Stream Anime</span>
                      </Link>

                      <a
                        href={`https://anilist.co/anime/${res.anilist}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#11131B] text-slate-300 hover:text-white border border-[#292D3A] text-xs font-semibold"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>AniList Page</span>
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
