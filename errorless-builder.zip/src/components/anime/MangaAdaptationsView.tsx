import React, { useEffect, useState } from 'react';
import { AnimeUniverseService } from '../../services/providers/animeUniverse';
import { BookOpen, Sparkles, ExternalLink, Search, Image as ImageIcon } from 'lucide-react';

export const MangaAdaptationsView: React.FC = () => {
  const [subTab, setSubTab] = useState<'mangadex' | 'openlibrary' | 'art'>('mangadex');
  const [query, setQuery] = useState('Attack on Titan');
  const [mangaList, setMangaList] = useState<any[]>([]);
  const [bookList, setBookList] = useState<any[]>([]);
  const [artList] = useState<any[]>(() => AnimeUniverseService.getAnimeArtGallery());
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (subTab === 'mangadex') {
      setLoading(true);
      AnimeUniverseService.searchMangaDex(query)
        .then((data) => setMangaList(data))
        .finally(() => setLoading(false));
    } else if (subTab === 'openlibrary') {
      setLoading(true);
      AnimeUniverseService.searchOpenLibrary(query)
        .then((data) => setBookList(data))
        .finally(() => setLoading(false));
    }
  }, [subTab, query]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (subTab === 'mangadex') {
      setLoading(true);
      AnimeUniverseService.searchMangaDex(query)
        .then((data) => setMangaList(data))
        .finally(() => setLoading(false));
    } else if (subTab === 'openlibrary') {
      setLoading(true);
      AnimeUniverseService.searchOpenLibrary(query)
        .then((data) => setBookList(data))
        .finally(() => setLoading(false));
    }
  };

  return (
    <div className="space-y-6">
      {/* Subtab Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl bg-[#11131B] border border-[#292D3A]">
        <div className="flex items-center gap-2 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
          <button
            onClick={() => setSubTab('mangadex')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              subTab === 'mangadex'
                ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            📖 MangaDex (Manga API)
          </button>

          <button
            onClick={() => setSubTab('openlibrary')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              subTab === 'openlibrary'
                ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            📚 Open Library (Adaptations & Novels)
          </button>

          <button
            onClick={() => setSubTab('art')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
              subTab === 'art'
                ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/20'
                : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
            }`}
          >
            🎨 Nekos, Waifus & Art (NekosBest / Waifu.im)
          </button>
        </div>

        {subTab !== 'art' && (
          <form onSubmit={handleSearch} className="relative w-full sm:w-64">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search title..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="w-full bg-[#181B27] border border-[#292D3A] rounded-xl pl-9 pr-3 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-[#8B5CF6]"
            />
          </form>
        )}
      </div>

      {/* MangaDex View */}
      {subTab === 'mangadex' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Official MangaDex API · Full manga chapters and publication status</span>
            <span>{mangaList.length} Manga results</span>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-pulse">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-44 bg-[#181B27] rounded-2xl border border-[#292D3A]" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {mangaList.map((m) => (
                <div
                  key={m.id}
                  className="p-4 rounded-2xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all flex gap-4 group"
                >
                  {m.coverUrl && (
                    <div className="w-20 h-28 rounded-xl overflow-hidden shrink-0 bg-[#11131B] border border-[#292D3A]">
                      <img src={m.coverUrl} alt={m.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform" />
                    </div>
                  )}

                  <div className="flex-1 flex flex-col justify-between overflow-hidden">
                    <div>
                      <div className="flex items-center gap-1.5 text-[10px] text-slate-400 mb-1">
                        <span className="uppercase font-bold text-[#A78BFA] px-1.5 py-0.5 rounded bg-[#11131B] border border-[#292D3A]">
                          {m.status || 'Manga'}
                        </span>
                        {m.year && <span>{m.year}</span>}
                      </div>

                      <h4 className="font-bold text-white text-sm line-clamp-1 group-hover:text-[#A78BFA] transition-colors">
                        {m.title}
                      </h4>

                      <p className="text-xs text-slate-300 line-clamp-2 mt-1 leading-relaxed">
                        {m.description}
                      </p>
                    </div>

                    <div className="pt-2 border-t border-[#292D3A]/60 flex items-center justify-between">
                      <span className="text-[10px] text-slate-500">MangaDex v5</span>
                      <a
                        href={m.readUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="flex items-center gap-1 text-[11px] font-bold text-[#8B5CF6] hover:text-[#A78BFA]"
                      >
                        <span>Read Manga</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Open Library View */}
      {subTab === 'openlibrary' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Open Library REST API · Light Novels, Author Records & First Editions</span>
            <span>{bookList.length} Adaptations</span>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-pulse">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="h-32 bg-[#181B27] rounded-2xl border border-[#292D3A]" />
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {bookList.map((b, i) => (
                <div
                  key={i}
                  className="p-5 rounded-2xl bg-[#181B27] border border-[#292D3A] flex flex-col justify-between"
                >
                  <div className="space-y-1">
                    <span className="text-[10px] text-slate-500 font-bold uppercase tracking-wider">
                      Published {b.first_publish_year}
                    </span>
                    <h4 className="font-bold text-white text-sm line-clamp-1">{b.title}</h4>
                    <p className="text-xs text-slate-400 font-medium">By {b.author_name}</p>
                  </div>

                  <div className="pt-3 mt-3 border-t border-[#292D3A]/60 flex items-center justify-between">
                    <span className="text-[10px] text-slate-500">OpenLibrary.org</span>
                    <a
                      href={`https://openlibrary.org${b.key}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-[11px] font-bold text-[#8B5CF6] hover:text-[#A78BFA]"
                    >
                      <span>Book Record</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Nekos, Waifus & Art Gallery */}
      {subTab === 'art' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between text-xs text-slate-400">
            <span>Powered by NekosBest, Waifu.im, Waifu.pics & Catboys APIs · High-Resolution Artworks</span>
            <span>{artList.length} Curated Masterworks</span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {artList.map((art) => (
              <div
                key={art.id}
                className="rounded-2xl overflow-hidden bg-[#181B27] border border-[#292D3A] flex flex-col group hover:border-[#8B5CF6]/50 transition-all"
              >
                <div className="relative aspect-video w-full overflow-hidden bg-black">
                  <img src={art.url} alt={art.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                  <span className="absolute top-2 left-2 px-2 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-[#A78BFA] text-[10px] font-bold border border-[#8B5CF6]/30">
                    {art.category}
                  </span>
                </div>

                <div className="p-3.5 flex items-center justify-between">
                  <div>
                    <h4 className="font-bold text-white text-xs">{art.title}</h4>
                    <p className="text-[10px] text-slate-400">{art.source}</p>
                  </div>
                  <a
                    href={art.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1.5 rounded-lg bg-[#11131B] text-slate-400 hover:text-white border border-[#292D3A]"
                    title="View Original Image"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
