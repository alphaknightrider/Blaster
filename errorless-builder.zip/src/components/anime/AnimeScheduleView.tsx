import React, { useEffect, useState } from 'react';
import { AnimeUniverseService, ScheduleItem } from '../../services/providers/animeUniverse';
import { Calendar, Clock, Star, Play, Sparkles } from 'lucide-react';
import { Link } from 'react-router-dom';

const DAYS = [
  { id: 'monday', label: 'Monday' },
  { id: 'tuesday', label: 'Tuesday' },
  { id: 'wednesday', label: 'Wednesday' },
  { id: 'thursday', label: 'Thursday' },
  { id: 'friday', label: 'Friday' },
  { id: 'saturday', label: 'Saturday' },
  { id: 'sunday', label: 'Sunday' },
];

export const AnimeScheduleView: React.FC = () => {
  const [selectedDay, setSelectedDay] = useState<string>(() => {
    const days = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    return days[new Date().getDay()];
  });
  const [schedule, setSchedule] = useState<ScheduleItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    AnimeUniverseService.getSchedule(selectedDay)
      .then((data) => {
        if (!cancelled) setSchedule(data);
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, [selectedDay]);

  return (
    <div className="space-y-6">
      {/* Day Selector Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {DAYS.map((d) => {
          const isToday = DAYS[new Date().getDay() === 0 ? 6 : new Date().getDay() - 1]?.id === d.id;
          const isSelected = selectedDay === d.id;
          return (
            <button
              key={d.id}
              onClick={() => setSelectedDay(d.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap cursor-pointer ${
                isSelected
                  ? 'bg-[#8B5CF6] text-white shadow-lg shadow-[#8B5CF6]/20'
                  : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
              }`}
            >
              <span>{d.label}</span>
              {isToday && (
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse ml-1" title="Today" />
              )}
            </button>
          );
        })}
      </div>

      {/* Airing Shows List */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 animate-pulse">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="h-28 bg-[#181B27] rounded-2xl border border-[#292D3A]" />
          ))}
        </div>
      ) : schedule.length === 0 ? (
        <div className="p-8 text-center text-slate-400 bg-[#11131B] rounded-2xl border border-[#292D3A]">
          No broadcast episodes listed for this day.
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {schedule.map((item) => (
            <div
              key={item.mal_id}
              className="p-4 rounded-2xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all flex gap-4 group"
            >
              <div className="relative w-20 h-28 rounded-xl overflow-hidden shrink-0 bg-[#11131B]">
                <img
                  src={item.image_url}
                  alt={item.title}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
              </div>

              <div className="flex-1 flex flex-col justify-between overflow-hidden">
                <div>
                  <div className="flex items-center gap-1.5 text-[11px] text-slate-400 font-semibold mb-1">
                    <Clock className="w-3.5 h-3.5 text-[#8B5CF6]" />
                    <span>{item.broadcast_time}</span>
                  </div>

                  <h4 className="font-bold text-white text-sm line-clamp-1 group-hover:text-[#A78BFA] transition-colors">
                    {item.title}
                  </h4>

                  {item.title_japanese && (
                    <p className="text-[11px] text-slate-500 line-clamp-1">{item.title_japanese}</p>
                  )}

                  <div className="flex flex-wrap gap-1 mt-1.5">
                    {item.genres.slice(0, 2).map((g) => (
                      <span key={g} className="px-1.5 py-0.5 rounded bg-[#11131B] text-[10px] text-slate-400 font-medium border border-[#292D3A]">
                        {g}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#292D3A]/60 mt-2">
                  {item.score && (
                    <span className="flex items-center gap-1 text-xs text-amber-300 font-bold">
                      <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
                      <span>{item.score.toFixed(1)}</span>
                    </span>
                  )}

                  <Link
                    to={`/search?q=${encodeURIComponent(item.title)}`}
                    className="flex items-center gap-1 text-[11px] font-bold text-[#8B5CF6] hover:text-[#A78BFA] group/btn"
                  >
                    <span>Watch Episodes</span>
                    <Play className="w-3 h-3 fill-current group-hover/btn:translate-x-0.5 transition-transform" />
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
