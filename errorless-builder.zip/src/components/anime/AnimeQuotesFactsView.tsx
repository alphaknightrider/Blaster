import React, { useState } from 'react';
import { AnimeUniverseService, AnimeQuote, AnimeFact } from '../../services/providers/animeUniverse';
import { Quote, Sparkles, Copy, Check, RefreshCw, Flame, BookOpen } from 'lucide-react';

export const AnimeQuotesFactsView: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [currentQuote, setCurrentQuote] = useState<AnimeQuote>(() => AnimeUniverseService.getRandomQuote());
  const [copied, setCopied] = useState(false);
  const [facts] = useState<AnimeFact[]>(() => AnimeUniverseService.getFacts());
  const allQuotes = AnimeUniverseService.getAllQuotes();

  const handleNextQuote = () => {
    setCopied(false);
    setCurrentQuote(AnimeUniverseService.getRandomQuote(selectedCategory));
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(`"${currentQuote.quote}" — ${currentQuote.character} (${currentQuote.anime})`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredQuotes =
    selectedCategory === 'all'
      ? allQuotes
      : allQuotes.filter(
          (q) => q.category === selectedCategory || q.anime.toLowerCase().includes(selectedCategory.toLowerCase())
        );

  return (
    <div className="space-y-8">
      {/* Featured Quote of the Moment */}
      <div className="relative p-6 sm:p-10 rounded-3xl bg-gradient-to-br from-[#181B27] via-[#11131B] to-[#0D0F18] border border-[#292D3A] shadow-2xl overflow-hidden">
        <Quote className="w-24 h-24 absolute -top-4 -right-4 text-[#8B5CF6]/10 pointer-events-none" />

        <div className="max-w-3xl space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-full bg-[#8B5CF6]/20 text-[#A78BFA] border border-[#8B5CF6]/30 text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              <span>Anime Quote Engine · {currentQuote.anime}</span>
            </span>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopy}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#11131B] border border-[#292D3A] text-slate-300 hover:text-white text-xs font-semibold transition-colors cursor-pointer"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>

              <button
                onClick={handleNextQuote}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-bold hover:bg-[#7c4def] transition-colors shadow-md shadow-[#8B5CF6]/20 cursor-pointer"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Next Quote</span>
              </button>
            </div>
          </div>

          <blockquote className="text-xl sm:text-2xl font-extrabold text-white leading-relaxed font-['Manrope']">
            "{currentQuote.quote}"
          </blockquote>

          <div className="flex items-center gap-3 pt-2">
            <div className="w-10 h-10 rounded-full bg-[#8B5CF6]/30 border border-[#8B5CF6]/50 flex items-center justify-center font-bold text-white text-sm">
              {currentQuote.character.charAt(0)}
            </div>
            <div>
              <p className="font-bold text-white text-sm">{currentQuote.character}</p>
              <p className="text-xs text-slate-400 font-medium">{currentQuote.anime}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Category Filter Pills */}
      <div className="space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'all', label: 'All Quotes' },
              { id: 'aot', label: 'Attack on Titan (AOT Quotes)' },
              { id: 'shonen', label: 'Shonen Heroes' },
              { id: 'philosophical', label: 'Philosophical & Deep' },
              { id: 'inspirational', label: 'Inspirational' },
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                  selectedCategory === cat.id
                    ? 'bg-[#8B5CF6] text-white shadow-md shadow-[#8B5CF6]/20'
                    : 'bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A]'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>

          <span className="text-xs text-slate-400">{filteredQuotes.length} Quotes in category</span>
        </div>

        {/* Quotes Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredQuotes.map((q) => (
            <div
              key={q.id}
              className="p-5 rounded-2xl bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all flex flex-col justify-between group"
            >
              <p className="text-sm font-semibold text-slate-200 leading-relaxed mb-4">
                "{q.quote}"
              </p>

              <div className="flex items-center justify-between pt-3 border-t border-[#292D3A]/60">
                <div>
                  <h4 className="font-bold text-white text-xs group-hover:text-[#A78BFA] transition-colors">
                    {q.character}
                  </h4>
                  <p className="text-[11px] text-slate-400">{q.anime}</p>
                </div>

                <button
                  onClick={() => {
                    navigator.clipboard.writeText(`"${q.quote}" — ${q.character} (${q.anime})`);
                  }}
                  className="p-2 rounded-lg bg-[#11131B] text-slate-400 hover:text-white border border-[#292D3A] transition-colors cursor-pointer"
                  title="Copy quote"
                >
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Anime Facts & Trivia Database */}
      <div className="space-y-4 pt-4 border-t border-[#292D3A]">
        <h3 className="text-lg font-bold text-white font-['Manrope'] flex items-center gap-2">
          <BookOpen className="w-4 h-4 text-amber-400" />
          Anime Facts & Production Lore (Anime Facts API)
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {facts.map((f) => (
            <div key={f.id} className="p-4 rounded-2xl bg-[#11131B] border border-[#292D3A] space-y-2">
              <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 text-[10px] font-bold uppercase tracking-wider">
                {f.anime} Fact
              </span>
              <p className="text-xs text-slate-300 leading-relaxed">{f.fact}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
