import React, { useEffect, useState } from 'react';
import { AnimeUniverseService, GhibliFilm } from '../../services/providers/animeUniverse';
import { Sparkles, Star, Clock, Calendar, Play, ExternalLink } from 'lucide-react';
import { Link } from 'react-router-dom';

export const StudioGhibliVault: React.FC = () => {
  const [films, setFilms] = useState<GhibliFilm[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedFilm, setSelectedFilm] = useState<GhibliFilm | null>(null);

  useEffect(() => {
    let cancelled = false;
    AnimeUniverseService.getGhibliFilms()
      .then((data) => {
        if (!cancelled) {
          setFilms(data);
          if (data.length > 0) setSelectedFilm(data[0]);
        }
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });

    return () => {
      cancelled = true;
    };
  }, []);

  if (loading) {
    return (
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 animate-pulse">
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className="aspect-[2/3] bg-[#181B27] rounded-2xl border border-[#292D3A]" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Featured Ghibli Banner */}
      {selectedFilm && (
        <div className="relative rounded-3xl overflow-hidden border border-[#292D3A] bg-[#11131B] min-h-[360px] flex items-end p-6 sm:p-10 shadow-2xl">
          <div className="absolute inset-0 z-0">
            <img
              src={selectedFilm.movie_banner || selectedFilm.image}
              alt={selectedFilm.title}
              className="w-full h-full object-cover object-center filter brightness-[0.65]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-[#090A0F]/70 to-transparent pointer-events-none" />
            <div className="absolute inset-0 bg-gradient-to-r from-[#090A0F]/90 via-[#090A0F]/40 to-transparent pointer-events-none" />
          </div>

          <div className="relative z-10 max-w-2xl space-y-3">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold text-slate-300">
              <span className="px-2.5 py-1 rounded-md bg-[#8B5CF6]/30 text-[#A78BFA] border border-[#8B5CF6]/40 uppercase tracking-wider text-[11px]">
                Studio Ghibli Masterpiece
              </span>
              <span>·</span>
              <span className="text-amber-300 flex items-center gap-1">
                <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                {selectedFilm.rt_score}% RT Score
              </span>
              <span>·</span>
              <span className="flex items-center gap-1 text-slate-400">
                <Clock className="w-3.5 h-3.5" />
                {selectedFilm.running_time} min
              </span>
              <span>·</span>
              <span>{selectedFilm.release_date}</span>
            </div>

            <div className="space-y-1">
              <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-['Manrope']">
                {selectedFilm.title}
              </h2>
              <p className="text-sm font-medium text-slate-400">
                {selectedFilm.original_title} ({selectedFilm.original_title_romanised}) · Dir. {selectedFilm.director}
              </p>
            </div>

            <p className="text-xs sm:text-sm text-slate-300 line-clamp-3 leading-relaxed">
              {selectedFilm.description}
            </p>

            <div className="pt-2 flex flex-wrap items-center gap-3">
              <Link
                to={`/search?q=${encodeURIComponent(selectedFilm.title)}`}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-[#8B5CF6] text-white text-xs font-bold hover:bg-[#7c4def] transition-colors shadow-lg shadow-[#8B5CF6]/20"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Search & Stream</span>
              </Link>

              <a
                href={`https://www.youtube.com/results?search_query=${encodeURIComponent(selectedFilm.title + ' studio ghibli official trailer')}`}
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-[#181B27] text-slate-300 hover:text-white border border-[#292D3A] text-xs font-semibold"
              >
                <ExternalLink className="w-3.5 h-3.5 text-slate-400" />
                <span>Trailer & Clips</span>
              </a>
            </div>
          </div>
        </div>
      )}

      {/* Grid of all Ghibli Works */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-bold text-white font-['Manrope'] flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#8B5CF6]" />
            Complete Hayao Miyazaki & Studio Ghibli Filmography
          </h3>
          <span className="text-xs text-slate-400">{films.length} Official Films</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {films.map((film) => (
            <div
              key={film.id}
              onClick={() => setSelectedFilm(film)}
              className={`group cursor-pointer rounded-2xl overflow-hidden bg-[#181B27] border transition-all duration-300 flex flex-col ${
                selectedFilm?.id === film.id
                  ? 'border-[#8B5CF6] shadow-lg shadow-[#8B5CF6]/20 scale-[1.02]'
                  : 'border-[#292D3A] hover:border-slate-500'
              }`}
            >
              <div className="relative aspect-[2/3] w-full overflow-hidden bg-[#11131B]">
                <img
                  src={film.image}
                  alt={film.title}
                  loading="lazy"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-2 right-2 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-md text-amber-300 text-[10px] font-bold flex items-center gap-1">
                  <Star className="w-3 h-3 fill-amber-300 text-amber-300" />
                  <span>{film.rt_score}%</span>
                </div>
              </div>

              <div className="p-3 flex-1 flex flex-col justify-between">
                <div>
                  <h4 className="font-bold text-white text-xs line-clamp-1 group-hover:text-[#A78BFA] transition-colors">
                    {film.title}
                  </h4>
                  <p className="text-[10px] text-slate-400 line-clamp-1">{film.original_title}</p>
                </div>
                <div className="flex items-center justify-between text-[10px] text-slate-500 pt-2 border-t border-[#292D3A]/60 mt-2">
                  <span>{film.release_date}</span>
                  <span>{film.running_time}m</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
