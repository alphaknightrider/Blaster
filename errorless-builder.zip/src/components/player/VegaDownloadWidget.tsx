import React, { useState } from 'react';
import { NormalizedTitle } from '../../types';
import { VegaMoviesProvider, VegaDownloadLink } from '../../services/providers/vegamovies';
import { Download, Zap, ExternalLink, Copy, Check, Sparkles, HardDrive } from 'lucide-react';

interface VegaDownloadWidgetProps {
  title: NormalizedTitle;
}

export const VegaDownloadWidget: React.FC<VegaDownloadWidgetProps> = ({ title }) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [activeMirrorIdx, setActiveMirrorIdx] = useState<number | null>(null);

  const links: VegaDownloadLink[] = VegaMoviesProvider.getDownloadLinks(
    title.title,
    title.year,
    title.mediaType
  );

  const handleLaunchDownload = (link: VegaDownloadLink, idx: number) => {
    setActiveMirrorIdx(idx);
    window.open(link.url, '_blank', 'noopener,noreferrer');
    setTimeout(() => setActiveMirrorIdx(null), 2500);
  };

  const handleCopyLink = (link: VegaDownloadLink, idx: number) => {
    navigator.clipboard.writeText(link.url);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  return (
    <div className="rounded-2xl bg-gradient-to-b from-[#141824] to-[#10131E] border border-[#292D3A] p-6 space-y-5 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-[#292D3A]/80 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#8B5CF6] to-[#EC4899] p-0.5 shadow-lg shadow-[#8B5CF6]/30">
            <div className="w-full h-full bg-[#090A0F] rounded-[10px] flex items-center justify-center">
              <Zap className="w-5 h-5 text-[#8B5CF6]" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-lg font-bold text-white font-['Manrope'] tracking-tight">
                VegaMovies Instant Download & Cloud Mirrors
              </h3>
              <span className="hidden sm:inline-block px-2 py-0.5 rounded text-[10px] font-bold bg-[#8B5CF6]/20 text-[#8B5CF6] border border-[#8B5CF6]/30 uppercase">
                100,000+ Movies
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Multi-quality fast cloud mirrors (4K, 1080p, 720p, 480p) · Hindi & Dual Audio.
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-[#181B27] border border-[#292D3A] text-xs text-emerald-400 font-semibold self-start sm:self-auto">
          <Sparkles className="w-3.5 h-3.5" />
          <span>100% Free & Working</span>
        </div>
      </div>

      {/* Quality Links Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {links.map((link, idx) => (
          <div
            key={idx}
            className="flex flex-col justify-between p-4 rounded-xl bg-[#181B27]/90 border border-[#292D3A] hover:border-[#8B5CF6]/60 transition-all space-y-3 group"
          >
            <div>
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-bold text-white group-hover:text-[#38BDF8] transition-colors">
                  {link.quality}
                </span>
                <span className="text-[11px] font-bold text-amber-300 tabular-nums bg-amber-950/40 border border-amber-800/40 px-2 py-0.5 rounded">
                  {link.size}
                </span>
              </div>
              <p className="text-xs text-slate-300 font-mono mt-1">{link.resolution}</p>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-1.5">
                <span className="px-1.5 py-0.5 rounded bg-[#090A0F] border border-[#292D3A] text-[#8B5CF6] font-medium">
                  {link.audio}
                </span>
              </div>
            </div>

            <div className="flex items-center gap-2 pt-2 border-t border-[#292D3A]/60">
              <button
                onClick={() => handleLaunchDownload(link, idx)}
                className="flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-[#8B5CF6] hover:bg-[#7c4def] text-white text-xs font-bold transition-all shadow-md active:scale-95 cursor-pointer"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{activeMirrorIdx === idx ? 'Connecting Mirror...' : 'Download Mirror'}</span>
              </button>

              <button
                onClick={() => handleCopyLink(link, idx)}
                className="p-2 rounded-lg bg-[#090A0F] border border-[#292D3A] hover:border-slate-500 text-slate-300 hover:text-white transition-colors"
                title="Copy Direct Link"
              >
                {copiedIdx === idx ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* VegaMovies Portal Footer Notice */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 text-xs text-slate-400">
        <span className="flex items-center gap-1.5">
          <HardDrive className="w-3.5 h-3.5 text-slate-500" />
          <span>High-speed cloud mirrors: HubCloud, G-Direct, Mega, Fast-DL</span>
        </span>

        <a
          href={VegaMoviesProvider.getSearchUrl(title.title, title.year)}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-1 text-[#38BDF8] hover:underline font-semibold"
        >
          <span>Open on VegaMovies Portal</span>
          <ExternalLink className="w-3 h-3" />
        </a>
      </div>
    </div>
  );
};
