import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { NormalizedTitle } from '../../types';
import { useApp } from '../../context/AppContext';
import { Star, Bookmark, Play, Film } from 'lucide-react';
import { DEFAULT_POSTER } from '../../services/normalizer';

interface MovieCardProps {
  title: NormalizedTitle;
  priority?: boolean;
}

export const MovieCard: React.FC<MovieCardProps> = ({ title }) => {
  const navigate = useNavigate();
  const { isInWatchlist, toggleWatchlist } = useApp();
  const [attempt, setAttempt] = useState(0);
  const inWatchlist = isInWatchlist(title.id);

  const detailPath = title.mediaType === 'tv' ? `/tv/${encodeURIComponent(title.id)}` : `/movie/${encodeURIComponent(title.id)}`;
  const watchPath = `/watch/${title.mediaType}/${encodeURIComponent(title.id)}`;

  const handleWatchlistClick = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWatchlist({
      id: title.id,
      title: title.title,
      poster: title.poster,
      backdrop: title.backdrop,
      mediaType: title.mediaType,
      releaseDate: title.releaseDate,
      rating: title.rating,
      genres: title.genres,
    });
  };

  const getPosterSrc = (): string | null => {
    const rawPoster = title.poster || '';
    const rawBackdrop = title.backdrop || '';

    if (attempt === 0 && rawPoster) return rawPoster;

    // Attempt 1: if wsrv.nl failed, try direct TMDB URL
    if (attempt === 1 && rawPoster.includes('wsrv.nl/?url=')) {
      const match = rawPoster.split('wsrv.nl/?url=')[1];
      if (match) return decodeURIComponent(match);
    }
    // Attempt 1 alternate: if direct failed, try wsrv.nl
    if (attempt === 1 && !rawPoster.includes('wsrv.nl') && rawPoster.startsWith('http')) {
      return `https://wsrv.nl/?url=${encodeURIComponent(rawPoster)}&w=500&q=80`;
    }

    // Attempt 2: try backdrop
    if (attempt === 2 && rawBackdrop) {
      if (rawBackdrop.includes('wsrv.nl/?url=')) {
        const match = rawBackdrop.split('wsrv.nl/?url=')[1];
        if (match) return decodeURIComponent(match);
      }
      return rawBackdrop;
    }

    // Attempt 3: default branding poster
    if (attempt === 3) {
      return DEFAULT_POSTER;
    }

    return null;
  };

  const posterSrc = getPosterSrc();

  return (
    <div className="group relative flex flex-col rounded-xl overflow-hidden bg-[#181B27] border border-[#292D3A]/70 hover:border-[#8B5CF6]/50 transition-all duration-300 hover:shadow-xl hover:shadow-[#8B5CF6]/10 shrink-0 select-none">
      {/* Poster Media Box */}
      <Link to={detailPath} className="relative aspect-[2/3] w-full overflow-hidden bg-[#11131B]">
        {posterSrc ? (
          <img
            src={posterSrc}
            alt={title.title}
            loading="lazy"
            referrerPolicy="no-referrer"
            onError={() => setAttempt((prev) => prev + 1)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          />
        ) : (
          <div className="w-full h-full flex flex-col items-center justify-center p-4 text-center bg-gradient-to-br from-[#181B27] to-[#090A0F] border border-[#292D3A]">
            <Film className="w-8 h-8 text-[#8B5CF6] mb-2 opacity-60" />
            <h4 className="text-xs font-bold text-white line-clamp-2">{title.title}</h4>
            {title.year && <span className="text-[10px] text-slate-400 mt-1">{title.year}</span>}
          </div>
        )}

        {/* Hover / Active Gradient Scrim */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-transparent to-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-between p-3">
          {/* Top Quick Actions */}
          <div className="flex justify-end">
            <button
              onClick={handleWatchlistClick}
              aria-label={inWatchlist ? 'Remove from Watchlist' : 'Add to Watchlist'}
              className={`p-2 rounded-full backdrop-blur-md transition-colors cursor-pointer ${
                inWatchlist
                  ? 'bg-[#8B5CF6] text-white shadow-md'
                  : 'bg-black/60 text-white hover:bg-[#8B5CF6]'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 fill-current" />
            </button>
          </div>

          {/* Center Play Button Overlay */}
          <div className="flex justify-center items-center">
            <button
              onClick={(e) => {
                e.preventDefault();
                navigate(watchPath);
              }}
              aria-label={`Play ${title.title}`}
              className="w-12 h-12 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center shadow-lg shadow-[#8B5CF6]/50 transform scale-75 group-hover:scale-100 transition-transform duration-300 hover:bg-[#7c4def] cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current ml-0.5" />
            </button>
          </div>

          {/* Bottom Card Meta on Hover */}
          <div className="flex items-center justify-between text-[11px] text-slate-300 font-medium">
            <span className="capitalize">{title.mediaType === 'short' ? 'Reel' : title.mediaType}</span>
            {title.genres && title.genres.length > 0 && (
              <span className="truncate max-w-[100px] text-slate-400">
                {title.genres[0].name}
              </span>
            )}
          </div>
        </div>

        {/* Public Domain / Free Badge */}
        {title.availability?.publicDomain && (
          <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-400/90 text-slate-950 shadow-sm backdrop-blur-md">
            ARCHIVE
          </span>
        )}

        {/* Adult / 18+ Badge if applicable */}
        {((title.genres && title.genres.some((g) => g.id === 10749 || g.name.toLowerCase().includes('adult') || g.name.toLowerCase().includes('18+'))) ||
          (title.title && (title.title.includes('18+') || title.title.toLowerCase().includes('erotic')))) && (
          <span className="absolute top-2 left-2 px-1.5 py-0.5 rounded text-[10px] font-bold bg-rose-600 text-white shadow-sm backdrop-blur-md">
            18+
          </span>
        )}
      </Link>

      {/* Info Container */}
      <div className="p-3 flex flex-col flex-1 justify-between gap-1">
        <Link to={detailPath} className="focus:outline-none">
          <h3 className="font-semibold text-xs sm:text-sm text-white line-clamp-1 group-hover:text-[#A78BFA] transition-colors">
            {title.title}
          </h3>
        </Link>

        {/* VegaMovies Dual Audio & Quality Badges */}
        <div className="flex flex-wrap items-center gap-1 mt-0.5">
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-emerald-950/90 text-emerald-300 font-bold border border-emerald-800/70">
            Dual Audio (Hindi 5.1)
          </span>
          <span className="text-[9px] px-1.5 py-0.2 rounded bg-[#11131B] text-slate-400 font-medium border border-[#292D3A]">
            1080p · 720p
          </span>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-400 mt-1">
          <span className="tabular-nums">{title.year || '2025'}</span>

          {typeof title.rating === 'number' && title.rating > 0 && (
            <div className="flex items-center gap-1 font-medium text-amber-300">
              <Star className="w-3 h-3 fill-amber-300" />
              <span className="tabular-nums">{title.rating.toFixed(1)}</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
