import React, { useRef } from 'react';
import { Link } from 'react-router-dom';
import { NormalizedTitle } from '../../types';
import { MovieCard } from './MovieCard';
import { ChevronLeft, ChevronRight, RefreshCw, Film } from 'lucide-react';

interface MovieRowProps {
  title: string;
  subtitle?: string;
  items: NormalizedTitle[];
  loading?: boolean;
  error?: string | null;
  onRetry?: () => void;
  viewAllLink?: string;
}

export const MovieRow: React.FC<MovieRowProps> = ({
  title,
  subtitle,
  items,
  loading = false,
  error = null,
  onRetry,
  viewAllLink,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (direction: 'left' | 'right') => {
    if (scrollRef.current) {
      const { scrollLeft, clientWidth } = scrollRef.current;
      const scrollAmount = clientWidth * 0.75;
      scrollRef.current.scrollTo({
        left: direction === 'left' ? scrollLeft - scrollAmount : scrollLeft + scrollAmount,
        behavior: 'smooth',
      });
    }
  };

  return (
    <section className="relative my-8 px-4 sm:px-6 lg:px-8">
      {/* Row Header */}
      <div className="flex items-end justify-between mb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Manrope']">
            {title}
          </h2>
          {subtitle && <p className="text-xs sm:text-sm text-slate-400 mt-0.5">{subtitle}</p>}
        </div>

        <div className="flex items-center gap-2">
          {viewAllLink && (
            <Link
              to={viewAllLink}
              className="text-xs font-semibold text-[#8B5CF6] hover:text-[#38BDF8] transition-colors mr-2"
            >
              View All
            </Link>
          )}

          {/* Desktop Left/Right Navigation */}
          <div className="hidden sm:flex items-center gap-1">
            <button
              onClick={() => scroll('left')}
              aria-label="Scroll left"
              className="p-1.5 rounded-lg bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white hover:border-[#8B5CF6] transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={() => scroll('right')}
              aria-label="Scroll right"
              className="p-1.5 rounded-lg bg-[#181B27] border border-[#292D3A] text-slate-300 hover:text-white hover:border-[#8B5CF6] transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      {/* Content Area */}
      {loading ? (
        <div className="flex gap-4 overflow-hidden py-1">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="w-[140px] sm:w-[170px] md:w-[200px] shrink-0 rounded-xl bg-[#181B27] animate-pulse border border-[#292D3A]"
            >
              <div className="aspect-[2/3] w-full bg-[#11131B] rounded-t-xl" />
              <div className="p-3 space-y-2">
                <div className="h-4 bg-[#292D3A] rounded w-3/4" />
                <div className="h-3 bg-[#292D3A]/60 rounded w-1/2" />
              </div>
            </div>
          ))}
        </div>
      ) : error ? (
        <div className="p-6 rounded-xl bg-[#181B27] border border-[#292D3A] flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div>
            <p className="text-sm font-medium text-red-400">Failed to load content for {title}</p>
            <p className="text-xs text-slate-400 mt-1">{error}</p>
          </div>
          {onRetry && (
            <button
              onClick={onRetry}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-[#8B5CF6] text-white text-xs font-semibold hover:bg-[#7c4def] transition-colors"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Retry</span>
            </button>
          )}
        </div>
      ) : items.length === 0 ? (
        <div className="p-8 rounded-xl bg-[#181B27] border border-[#292D3A] text-center text-slate-400">
          <Film className="w-8 h-8 mx-auto text-slate-500 mb-2" />
          <p className="text-sm">No titles currently available in this category.</p>
        </div>
      ) : (
        <div
          ref={scrollRef}
          className="flex gap-4 overflow-x-auto no-scrollbar scroll-smooth py-1"
        >
          {items.map((item) => (
            <div key={item.id} className="w-[140px] sm:w-[170px] md:w-[200px] shrink-0">
              <MovieCard title={item} />
            </div>
          ))}
        </div>
      )}
    </section>
  );
};
