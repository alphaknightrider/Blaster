import React, { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { NormalizedTitle } from '../../types';
import { useApp } from '../../context/AppContext';
import { Play, Info, Bookmark, Star, Clock } from 'lucide-react';
import { DEFAULT_BACKDROP } from '../../services/normalizer';

interface HeroBannerProps {
  title?: NormalizedTitle;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ title }) => {
  const navigate = useNavigate();
  const { t, isInWatchlist, toggleWatchlist } = useApp();
  const [imgAttempt, setImgAttempt] = useState(0);

  useEffect(() => {
    setImgAttempt(0);
  }, [title?.id]);

  if (!title) {
    return (
      <div className="relative w-full h-[65vh] min-h-[480px] bg-gradient-to-b from-[#181B27] to-[#090A0F] flex items-center justify-center">
        <div className="w-12 h-12 rounded-full border-2 border-[#8B5CF6] border-t-transparent animate-spin" />
      </div>
    );
  }

  const inWatchlist = isInWatchlist(title.id);
  const detailPath = title.mediaType === 'tv' ? `/tv/${encodeURIComponent(title.id)}` : `/movie/${encodeURIComponent(title.id)}`;
  const watchPath = `/watch/${title.mediaType}/${encodeURIComponent(title.id)}`;

  // Determine current image source based on attempt stage
  const getBackdropSrc = (): string => {
    const rawBackdrop = title.backdrop;
    const rawPoster = title.poster;

    if (imgAttempt === 0 && rawBackdrop) {
      return rawBackdrop;
    }
    if (imgAttempt <= 1 && rawPoster) {
      return rawPoster;
    }
    // Attempt with Cloudflare weserv proxy if original wasn't already proxied
    if (imgAttempt === 2 && (rawBackdrop || rawPoster)) {
      const target = rawBackdrop || rawPoster || '';
      if (!target.includes('wsrv.nl') && target.startsWith('http')) {
        return `https://wsrv.nl/?url=${encodeURIComponent(target)}&q=85`;
      }
    }
    return DEFAULT_BACKDROP;
  };

  const backdropSrc = getBackdropSrc();

  return (
    <div className="relative w-full min-h-[550px] lg:h-[75vh] max-h-[750px] overflow-hidden flex items-end bg-[#090A0F]">
      {/* Background Image with Depth Gradients */}
      <div className="absolute inset-0 z-0">
        <img
          key={backdropSrc}
          src={backdropSrc}
          alt={title.title}
          loading="eager"
          referrerPolicy="no-referrer"
          onError={() => setImgAttempt((prev) => prev + 1)}
          className="w-full h-full object-cover object-center filter brightness-[0.8] contrast-[1.05]"
        />
        {/* Measured Scrims */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#090A0F] via-[#090A0F]/60 to-transparent pointer-events-none" />
        <div className="absolute inset-0 bg-gradient-to-r from-[#090A0F]/90 via-[#090A0F]/40 to-transparent pointer-events-none" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 max-w-7xl mx-auto w-full px-4 sm:px-6 lg:px-8 pb-12 sm:pb-16 pt-32">
        <div className="max-w-2xl space-y-4">
          {/* Metadata line with typographic separators */}
          <div className="flex flex-wrap items-center gap-2 text-xs sm:text-sm text-slate-300 font-medium">
            <span className="text-[#38BDF8] uppercase tracking-wider font-semibold">
              {title.mediaType === 'tv' ? 'Series' : 'Feature Film'}
            </span>
            {title.year && (
              <>
                <span aria-hidden="true">·</span>
                <span>{title.year}</span>
              </>
            )}
            {title.runtime && (
              <>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>{title.runtime} {t.common.minutes}</span>
                </span>
              </>
            )}
            {title.rating > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span className="flex items-center gap-1 text-amber-300 font-semibold">
                  <Star className="w-3.5 h-3.5 fill-amber-300 text-amber-300" />
                  <span className="tabular-nums">{title.rating.toFixed(1)}</span>
                </span>
              </>
            )}
            {title.genres && title.genres.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span>{title.genres.slice(0, 2).map((g) => g.name).join(', ')}</span>
              </>
            )}
          </div>

          {/* Title */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-[1.1] font-['Manrope']">
            {title.title}
          </h1>

          {/* Overview Prose */}
          <p className="text-slate-300 text-sm sm:text-base line-clamp-3 leading-relaxed max-w-xl">
            {title.overview}
          </p>

          {/* Functional Actions */}
          <div className="flex flex-wrap items-center gap-3 pt-2">
            <button
              onClick={() => navigate(watchPath)}
              className="flex items-center gap-2 px-6 py-3 rounded-xl bg-[#8B5CF6] hover:bg-[#7c4def] text-white font-semibold text-sm transition-all shadow-lg shadow-[#8B5CF6]/25 hover:scale-[1.02] active:scale-[0.98]"
            >
              <Play className="w-4 h-4 fill-current ml-0.5" />
              <span>{t.common.watchNow}</span>
            </button>

            <Link
              to={detailPath}
              className="flex items-center gap-2 px-5 py-3 rounded-xl bg-[#181B27]/90 hover:bg-[#181B27] border border-[#292D3A] text-white font-medium text-sm transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Info className="w-4 h-4 text-slate-300" />
              <span>{t.common.moreDetails}</span>
            </Link>

            <button
              onClick={() =>
                toggleWatchlist({
                  id: title.id,
                  title: title.title,
                  poster: title.poster,
                  backdrop: title.backdrop,
                  mediaType: title.mediaType,
                  releaseDate: title.releaseDate,
                  rating: title.rating,
                  genres: title.genres,
                })
              }
              aria-label={inWatchlist ? t.common.removeFromWatchlist : t.common.addToWatchlist}
              className={`p-3 rounded-xl border transition-all ${
                inWatchlist
                  ? 'bg-[#8B5CF6] border-[#8B5CF6] text-white'
                  : 'bg-[#181B27]/90 hover:bg-[#181B27] border-[#292D3A] text-slate-300 hover:text-white'
              }`}
              title={inWatchlist ? t.common.inWatchlist : t.common.addToWatchlist}
            >
              <Bookmark className={`w-4 h-4 ${inWatchlist ? 'fill-current' : ''}`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
