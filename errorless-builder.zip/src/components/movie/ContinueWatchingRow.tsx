import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { Play, X, Clock } from 'lucide-react';
import { DEFAULT_POSTER } from '../../services/normalizer';

export const ContinueWatchingRow: React.FC = () => {
  const navigate = useNavigate();
  const { continueWatching, removeProgress, t } = useApp();

  if (!continueWatching || continueWatching.length === 0) return null;

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
  };

  return (
    <section className="my-8 px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight font-['Manrope']">
            {t.home.continueWatchingRow}
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">Pick up where you left off on this device</p>
        </div>
      </div>

      <div className="flex gap-4 overflow-x-auto no-scrollbar scroll-smooth py-1">
        {continueWatching.map((item) => (
          <div
            key={item.id}
            className="group relative w-[220px] sm:w-[260px] shrink-0 rounded-xl overflow-hidden bg-[#181B27] border border-[#292D3A] hover:border-[#8B5CF6]/50 transition-all shadow-md"
          >
            {/* Card Thumbnail Box */}
            <div className="relative aspect-video w-full bg-[#11131B] overflow-hidden">
              <img
                src={item.poster || DEFAULT_POSTER}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                loading="lazy"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-black/40 group-hover:bg-black/20 transition-colors flex items-center justify-center">
                <button
                  onClick={() => navigate(`/watch/${item.mediaType}/${encodeURIComponent(item.id)}`)}
                  className="w-10 h-10 rounded-full bg-[#8B5CF6] text-white flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform"
                  aria-label={`Resume ${item.title}`}
                >
                  <Play className="w-4 h-4 fill-current ml-0.5" />
                </button>
              </div>

              {/* Dismiss from continue watching */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  removeProgress(item.id);
                }}
                className="absolute top-2 right-2 p-1 rounded-full bg-black/60 text-slate-300 hover:text-white hover:bg-red-500/80 transition-colors"
                title="Remove from Continue Watching"
              >
                <X className="w-3.5 h-3.5" />
              </button>

              {/* Progress bar */}
              <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/60">
                <div
                  className="h-full bg-[#8B5CF6]"
                  style={{ width: `${item.percentage}%` }}
                />
              </div>
            </div>

            {/* Info */}
            <div className="p-3">
              <h3 className="font-semibold text-white text-xs sm:text-sm truncate" title={item.title}>
                {item.title}
              </h3>
              <div className="flex items-center justify-between text-[11px] text-slate-400 mt-1">
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3 text-slate-500" />
                  <span className="tabular-nums">{formatTime(item.currentTime)} / {formatTime(item.duration)}</span>
                </span>
                <span className="tabular-nums font-medium text-[#38BDF8]">{item.percentage}%</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
