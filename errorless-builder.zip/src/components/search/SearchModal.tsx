import React, { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { ApiClient } from '../../services/apiClient';
import { NormalizedTitle } from '../../types';
import { StorageManager } from '../../storage';
import { Search, X, History, Film, Star, ArrowRight, Loader2 } from 'lucide-react';
import { DEFAULT_POSTER } from '../../services/normalizer';

export const SearchModal: React.FC = () => {
  const { searchOpen, setSearchOpen, t } = useApp();
  const navigate = useNavigate();

  const [query, setQuery] = useState('');
  const [results, setResults] = useState<NormalizedTitle[]>([]);
  const [loading, setLoading] = useState(false);
  const [filterType, setFilterType] = useState<'all' | 'movie' | 'tv' | 'archive'>('all');
  const [searchHistory, setSearchHistory] = useState<string[]>(() => StorageManager.getSearchHistory());

  const abortControllerRef = useRef<AbortController | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Focus input on open
  useEffect(() => {
    if (searchOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      setSearchHistory(StorageManager.getSearchHistory());
    } else {
      setQuery('');
      setResults([]);
    }
  }, [searchOpen]);

  // Close on Escape
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && searchOpen) {
        setSearchOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [searchOpen, setSearchOpen]);

  // Debounced search with AbortController
  useEffect(() => {
    if (!query.trim()) {
      setResults([]);
      setLoading(false);
      return;
    }

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    const controller = new AbortController();
    abortControllerRef.current = controller;

    setLoading(true);

    const timer = setTimeout(async () => {
      try {
        const data = await ApiClient.search(
          query.trim(),
          { type: filterType },
          controller.signal
        );
        setResults(data);
      } catch (err: any) {
        if (err.name !== 'AbortError') {
          setResults([]);
        }
      } finally {
        setLoading(false);
      }
    }, 280);

    return () => {
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, filterType]);

  if (!searchOpen) return null;

  const handleSelectTitle = (item: NormalizedTitle) => {
    StorageManager.addSearchQuery(query.trim() || item.title);
    setSearchOpen(false);
    const path = item.mediaType === 'tv' ? `/tv/${encodeURIComponent(item.id)}` : `/movie/${encodeURIComponent(item.id)}`;
    navigate(path);
  };

  const handleHistorySelect = (historyQuery: string) => {
    setQuery(historyQuery);
  };

  const handleClearHistory = () => {
    StorageManager.clearSearchHistory();
    setSearchHistory([]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center pt-12 sm:pt-20 px-4">
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/80 backdrop-blur-md transition-opacity"
        onClick={() => setSearchOpen(false)}
      />

      {/* Modal Dialog Card */}
      <div className="relative w-full max-w-2xl bg-[#11131B] border border-[#292D3A] rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-[#292D3A] flex items-center gap-3">
          <Search className="w-5 h-5 text-slate-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search movies, TV shows, directors, public-domain classics..."
            className="w-full bg-transparent text-white text-sm sm:text-base focus:outline-none placeholder:text-slate-500 font-medium"
          />
          {loading && <Loader2 className="w-4 h-4 text-[#8B5CF6] animate-spin shrink-0" />}
          {query && (
            <button
              onClick={() => setQuery('')}
              className="p-1 rounded-md text-slate-400 hover:text-white transition-colors shrink-0"
              aria-label="Clear input"
            >
              <X className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => setSearchOpen(false)}
            className="p-1 rounded-md text-slate-400 hover:text-white transition-colors shrink-0"
            aria-label="Close search"
          >
            <span className="text-xs px-2 py-1 rounded bg-[#181B27] border border-[#292D3A]">Esc</span>
          </button>
        </div>

        {/* Filter Tabs (Interactive Filter Controls) */}
        <div className="flex items-center gap-1 px-4 py-2 bg-[#181B27]/50 border-b border-[#292D3A] overflow-x-auto no-scrollbar">
          {(['all', 'movie', 'tv', 'archive'] as const).map((type) => (
            <button
              key={type}
              onClick={() => setFilterType(type)}
              className={`px-3 py-1 rounded-md text-xs font-medium transition-colors whitespace-nowrap ${
                filterType === type
                  ? 'bg-[#8B5CF6] text-white shadow-sm'
                  : 'text-slate-400 hover:text-white'
              }`}
            >
              {type === 'all' && 'All Cinema'}
              {type === 'movie' && 'Movies'}
              {type === 'tv' && 'TV Series'}
              {type === 'archive' && 'Public Domain Archive'}
            </button>
          ))}
        </div>

        {/* Results Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          {query.trim().length === 0 ? (
            /* Search History & Shortcuts */
            <div className="space-y-4">
              {searchHistory.length > 0 && (
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span className="flex items-center gap-1 font-semibold uppercase tracking-wider text-[10px]">
                      <History className="w-3.5 h-3.5 text-slate-500" />
                      Recent Searches
                    </span>
                    <button
                      onClick={handleClearHistory}
                      className="text-slate-500 hover:text-slate-300 text-[10px]"
                    >
                      Clear
                    </button>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {searchHistory.map((item, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleHistorySelect(item)}
                        className="px-2.5 py-1 rounded-lg bg-[#181B27] border border-[#292D3A] text-xs text-slate-300 hover:text-white hover:border-[#8B5CF6] transition-colors"
                      >
                        {item}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {/* Suggestions */}
              <div>
                <p className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
                  Popular Searches
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs text-slate-300">
                  {['Night of the Living Dead', 'Metropolis', 'Inception', 'Breaking Bad', 'Interstellar', 'Dune'].map((s) => (
                    <button
                      key={s}
                      onClick={() => setQuery(s)}
                      className="p-2 rounded-lg bg-[#181B27] border border-[#292D3A]/60 text-left hover:border-[#8B5CF6] hover:text-white transition-all flex items-center justify-between"
                    >
                      <span>{s}</span>
                      <ArrowRight className="w-3 h-3 text-slate-500" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ) : results.length > 0 ? (
            /* Result Items List */
            <div className="space-y-2">
              {results.map((item) => (
                <div
                  key={item.id}
                  onClick={() => handleSelectTitle(item)}
                  className="group flex items-center gap-3 p-2.5 rounded-xl hover:bg-[#181B27] border border-transparent hover:border-[#292D3A] cursor-pointer transition-all"
                >
                  <img
                    src={item.poster || DEFAULT_POSTER}
                    alt={item.title}
                    className="w-10 h-14 object-cover rounded-md bg-[#090A0F] shrink-0"
                    loading="lazy"
                    referrerPolicy="no-referrer"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-semibold text-white text-sm truncate group-hover:text-[#38BDF8] transition-colors">
                      {item.title}
                    </h4>
                    <div className="flex items-center gap-2 text-xs text-slate-400 mt-0.5">
                      <span>{item.mediaType === 'tv' ? 'TV' : 'Movie'}</span>
                      {item.year && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span>{item.year}</span>
                        </>
                      )}
                      {item.rating > 0 && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="flex items-center gap-0.5 text-amber-300">
                            <Star className="w-3 h-3 fill-amber-300" />
                            <span className="tabular-nums">{item.rating.toFixed(1)}</span>
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-500 group-hover:text-white transition-colors shrink-0" />
                </div>
              ))}
            </div>
          ) : (
            /* No Results */
            <div className="py-12 text-center text-slate-400">
              <Film className="w-10 h-10 mx-auto text-slate-600 mb-2" />
              <p className="font-semibold text-white text-sm">No cinema matching &ldquo;{query}&rdquo;</p>
              <p className="text-xs text-slate-500 mt-1">Try searching for standard titles, actors, or public domain archives.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
