import React, { createContext, useContext, useEffect, useState } from 'react';
import { AppSettings, PlaybackProgress, WatchlistItem } from '../types';
import { DEFAULT_SETTINGS, StorageManager } from '../storage';
import { getTranslation, TranslationKey } from '../i18n';

interface AppContextType {
  settings: AppSettings;
  updateSettings: (partial: Partial<AppSettings>) => void;
  language: 'en' | 'hi';
  setLanguage: (lang: 'en' | 'hi') => void;
  t: TranslationKey;
  watchlist: WatchlistItem[];
  toggleWatchlist: (item: Omit<WatchlistItem, 'addedAt'>) => boolean;
  isInWatchlist: (id: string) => boolean;
  continueWatching: PlaybackProgress[];
  saveProgress: (progress: Omit<PlaybackProgress, 'lastWatched' | 'percentage'>) => void;
  removeProgress: (id: string) => void;
  searchOpen: boolean;
  setSearchOpen: (open: boolean) => void;
  announcementVisible: boolean;
  dismissAnnouncement: () => void;
}

const AppContext = createContext<AppContextType | null>(null);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [settings, setSettings] = useState<AppSettings>(() => StorageManager.getSettings());
  const [watchlist, setWatchlist] = useState<WatchlistItem[]>(() => StorageManager.getWatchlist());
  const [continueWatching, setContinueWatching] = useState<PlaybackProgress[]>(() => StorageManager.getContinueWatching());
  const [searchOpen, setSearchOpen] = useState(false);
  const [announcementVisible, setAnnouncementVisible] = useState(() => !StorageManager.getSettings().announcementDismissed);

  // Initialize storage
  useEffect(() => {
    StorageManager.init();
  }, []);

  const language = settings.language;
  const t = getTranslation(language);

  const updateSettings = (partial: Partial<AppSettings>) => {
    const updated = StorageManager.updateSettings(partial);
    setSettings(updated);
  };

  const setLanguage = (lang: 'en' | 'hi') => {
    updateSettings({ language: lang });
  };

  const toggleWatchlist = (item: Omit<WatchlistItem, 'addedAt'>) => {
    const added = StorageManager.toggleWatchlist(item);
    setWatchlist(StorageManager.getWatchlist());
    return added;
  };

  const isInWatchlist = (id: string) => {
    return watchlist.some((i) => i.id === id);
  };

  const saveProgress = (progress: Omit<PlaybackProgress, 'lastWatched' | 'percentage'>) => {
    StorageManager.saveProgress(progress);
    setContinueWatching(StorageManager.getContinueWatching());
  };

  const removeProgress = (id: string) => {
    StorageManager.removeProgress(id);
    setContinueWatching(StorageManager.getContinueWatching());
  };

  const dismissAnnouncement = () => {
    updateSettings({ announcementDismissed: true });
    setAnnouncementVisible(false);
  };

  // Keyboard shortcut Ctrl+K / Cmd+K for search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
        e.preventDefault();
        setSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <AppContext.Provider
      value={{
        settings,
        updateSettings,
        language,
        setLanguage,
        t,
        watchlist,
        toggleWatchlist,
        isInWatchlist,
        continueWatching,
        saveProgress,
        removeProgress,
        searchOpen,
        setSearchOpen,
        announcementVisible,
        dismissAnnouncement,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
}
