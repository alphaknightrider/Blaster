import { TitleNormalizer } from '../src/services/normalizer';
import { CURATED_PUBLIC_DOMAIN_CINEMA, CURATED_CLASSIC_CARTOONS } from '../src/services/providers/archive';
import { AnimeUniverseService } from '../src/services/providers/animeUniverse';

function runTests() {
  console.log('🧪 [CYRUS MOVIES] Running Core Unit Tests...');
  let passed = 0;
  let failed = 0;

  function assert(condition: boolean, message: string) {
    if (condition) {
      console.log(`  ✅ PASS: ${message}`);
      passed++;
    } else {
      console.error(`  ❌ FAIL: ${message}`);
      failed++;
    }
  }

  // Test 1: TMDB Normalization
  try {
    const rawTmdbMovie = {
      id: 550,
      title: 'Fight Club',
      overview: 'An insomniac office worker...',
      poster_path: '/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg',
      backdrop_path: '/hZkgoQYus5vegHoetLkCJzb17zJ.jpg',
      release_date: '1999-10-15',
      vote_average: 8.433,
      vote_count: 27000,
      genre_ids: [18, 53],
      original_language: 'en',
    };

    const normalized = TitleNormalizer.normalizeTmdb(rawTmdbMovie, 'movie');
    assert(normalized.id === 'tmdb:movie:550', 'TMDB qualified ID format');
    assert(normalized.title === 'Fight Club', 'Title extracted correctly');
    assert(normalized.rating === 8.4, 'Rating rounded to 1 decimal place');
    assert(normalized.year === 1999, 'Year extracted from release_date');
    assert(normalized.genres.length === 2, 'Genres mapped from genre_ids');
    assert(normalized.poster.includes('https://image.tmdb.org/t/p/w500'), 'Poster URL formatted correctly');
  } catch (e: any) {
    assert(false, `TMDB Normalization threw error: ${e.message}`);
  }

  // Test 2: Internet Archive Normalization
  try {
    const curated = CURATED_PUBLIC_DOMAIN_CINEMA[0];
    const normalizedArchive = TitleNormalizer.normalizeArchive(curated);
    assert(normalizedArchive.id === `ia:${curated.identifier}`, 'Archive qualified ID format');
    assert(normalizedArchive.availability?.publicDomain === true, 'Public domain flag enabled');
    assert(normalizedArchive.availability?.free === true, 'Free stream flag enabled');
    assert(normalizedArchive.availability?.downloadOptions?.length! > 0, 'Download options attached');
  } catch (e: any) {
    assert(false, `Archive Normalization threw error: ${e.message}`);
  }

  // Test 3: Curated Public Domain Cinema count
  assert(CURATED_PUBLIC_DOMAIN_CINEMA.length >= 10, 'Curated public domain archive catalog is populated');

  // Test 4: Classic Golden Age Cartoons count & normalization
  try {
    assert(CURATED_CLASSIC_CARTOONS.length >= 8, 'Classic cartoons catalog is populated');
    const superman = CURATED_CLASSIC_CARTOONS[0];
    const normCartoon = TitleNormalizer.normalizeArchive(superman);
    normCartoon.mediaType = 'cartoon';
    assert(normCartoon.id === `ia:${superman.identifier}`, 'Cartoon qualified ID is correct');
    assert(normCartoon.mediaType === 'cartoon', 'Cartoon mediaType is preserved');
  } catch (e: any) {
    assert(false, `Cartoon test threw error: ${e.message}`);
  }

  // Test 5: TVmaze Normalization
  try {
    const rawShow = {
      id: 139,
      name: 'Girls',
      type: 'Scripted',
      language: 'English',
      genres: ['Drama', 'Comedy', 'Romance'],
      premiered: '2012-04-15',
      rating: { average: 6.6 },
      image: { medium: 'https://static.tvmaze.com/uploads/images/medium_portrait/31/78286.jpg' },
      summary: '<p>This is a summary</p>',
    };
    const normTvmaze = TitleNormalizer.normalizeTvmaze(rawShow);
    assert(normTvmaze.id === 'tvmaze:139', 'TVmaze ID format');
    assert(normTvmaze.title === 'Girls', 'TVmaze title extracted');
    assert(normTvmaze.overview === 'This is a summary', 'TVmaze HTML tags stripped');
    assert(normTvmaze.year === 2012, 'TVmaze premier year extracted');
  } catch (e: any) {
    assert(false, `TVmaze test threw error: ${e.message}`);
  }

  // Test 6: AniList Normalization
  try {
    const rawAnime = {
      id: 16498,
      title: { english: 'Attack on Titan', romaji: 'Shingeki no Kyojin', native: '進撃の巨人' },
      coverImage: { extraLarge: 'https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx16498-73IhOXpJZiMF.png' },
      description: 'Centuries ago, mankind was slaughtered...',
      seasonYear: 2013,
      episodes: 25,
      genres: ['Action', 'Fantasy', 'Mystery'],
      averageScore: 85,
    };
    const normAnime = TitleNormalizer.normalizeAniList(rawAnime);
    assert(normAnime.id === 'anilist:16498', 'AniList ID format');
    assert(normAnime.title === 'Attack on Titan', 'AniList title matches English');
    assert(normAnime.rating === 8.5, 'AniList rating scaled to 10');
    assert(normAnime.mediaType === 'anime', 'AniList mediaType is anime');
  } catch (e: any) {
    assert(false, `AniList test threw error: ${e.message}`);
  }

  // Test 7: Anime Quotes & AOT Quotes Engine
  try {
    const quote = AnimeUniverseService.getRandomQuote('aot');
    assert(quote && quote.anime.includes('Attack on Titan'), 'AOT Quote returned');
    assert(quote.quote.length > 10, 'AOT Quote text is valid');
  } catch (e: any) {
    assert(false, `Anime Quotes test error: ${e.message}`);
  }

  // Test 8: Anime Facts & Lore
  try {
    const facts = AnimeUniverseService.getFacts();
    assert(facts.length >= 6, 'Anime facts populated');
    assert(facts[0].fact.length > 20, 'Anime fact content verified');
  } catch (e: any) {
    assert(false, `Anime Facts test error: ${e.message}`);
  }

  // Test 9: External Anime Databases Links Generator
  try {
    const links = AnimeUniverseService.getExternalDatabaseLinks('Attack on Titan', 16498, 16498);
    assert(links.length === 7, 'All 7 external anime databases generated');
    const anidb = links.find((l) => l.name === 'AniDB');
    const shikimori = links.find((l) => l.name === 'Shikimori');
    const animePlanet = links.find((l) => l.name === 'Anime-Planet');
    const ann = links.find((l) => l.name === 'Anime News Network');
    assert(!!anidb && anidb.url.includes('anidb.net'), 'AniDB link generated');
    assert(!!shikimori && shikimori.url.includes('shikimori.one'), 'Shikimori link generated');
    assert(!!animePlanet && animePlanet.url.includes('anime-planet.com'), 'Anime-Planet link generated');
    assert(!!ann && ann.url.includes('animenewsnetwork.com'), 'Anime News Network link generated');
  } catch (e: any) {
    assert(false, `External Anime Links test error: ${e.message}`);
  }

  console.log(`\nResults: ${passed} passed, ${failed} failed.`);
  if (failed > 0) process.exit(1);
}

runTests();
