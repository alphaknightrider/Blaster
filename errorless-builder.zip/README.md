# CYRUS MOVIES — Your World of Cinema

> **Ultra Master Full-Stack Zero-Database, Multi-API Movie & Television Discovery and Authorized Streaming Platform.**

---

## 🌟 Overview

**Cyrus Movies** is a modern, high-contrast cinematic web application built with **React 19, TypeScript, Vite, and Tailwind CSS**. It discovers films, TV shows, anime, documentaries, and short films across multiple third-party APIs (TMDB, Internet Archive, Watchmode, YouTube, and Wikidata) **without requiring a traditional cloud database**.

---

## 🚀 Key Architectural Features

1. **Zero-Database Persistence**:
   - No Supabase, Firebase, or SQL database required.
   - User watchlist, playback checkpoints, viewing history, and preferences are saved 100% client-side via `localStorage` and `IndexedDB`.
   - Built-in data backup export and import as portable JSON files.
2. **Multi-API Provider Federation & Failover**:
   - **TMDB (The Movie Database)**: Real-time trending, popular, top-rated, upcoming, cast credits, video trailers, and watch providers.
   - **Internet Archive**: Authorized public-domain cinema with verified direct MP4 streaming links and compliant file downloads.
   - **Watchmode**: Real-time regional streaming availability across platforms (Netflix, Apple TV, Prime Video, Disney+).
   - **Wikidata**: Semantic metadata and structured director/creator facts.
   - **YouTube**: Official theatrical trailers and teasers via the YouTube Iframe Player API.
3. **Cinematic Custom Player & Continue Watching**:
   - Play/pause, scrubbing, volume/mute, playback rate, fullscreen, and automatic timestamp resumption.
   - Real-time progress updates saved to local storage with completion thresholds.
4. **Authorized Download Center**:
   - Direct download links for public-domain classics with file sizes and licensing metadata.
5. **Localization (English & Hindi)**:
   - Complete dictionary support with seamless language toggling.
6. **Mobile-First Android Phone Optimization**:
   - Safe-area bottom navigation, compact touch targets (>44px), debounced search overlay (Ctrl+K), and responsive cards.
7. **Local Admin Diagnostic Console**:
   - Real-time provider ping benchmarks, latency meters, cache purge actions, and session logs.

---

## 🛠️ Vercel Deployment Instructions

1. **Clone the repository**:
   ```bash
   git clone https://github.com/your-username/cyrus-movies.git
   cd cyrus-movies
   ```

2. **Install dependencies**:
   ```bash
   npm install
   ```

3. **Configure Environment Variables** (Optional, falls back to public access keys):
   - In your Vercel Dashboard -> Project Settings -> Environment Variables, add:
     - `VITE_TMDB_PUBLIC_KEY` (Optional client key)
     - `TMDB_API_KEY` (Serverless proxy key)
     - `WATCHMODE_API_KEY` (Optional)
     - `YOUTUBE_API_KEY` (Optional)

4. **Deploy**:
   ```bash
   npx vercel
   ```

---

## ⚖️ Rights & Copyright Notice

Cyrus Movies strictly respects global intellectual property and digital rights. Direct playback and downloads are provided exclusively for materials in the public domain or under open cultural licenses. For commercial and studio-copyrighted films, Cyrus Movies provides verified links to authorized streaming providers rather than hosting unauthorized media.
