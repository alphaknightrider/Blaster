import express from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { Readable } from 'stream';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const isProduction = process.env.NODE_ENV === 'production';
const PORT = Number(process.env.PORT) || 3000;
const TMDB_API_KEY = process.env.TMDB_API_KEY || '15d2ea6d0dc1d476efbca3eba2b9bbfb';

async function main() {
  const app = express();
  app.use(express.json());

  // 1. TMDB Proxy endpoint - bypasses all ISP DNS blocks globally!
  app.get('/api/tmdb/*', async (req, res) => {
    try {
      const endpoint = (req.params as any)[0] || '';
      const queryParams = new URLSearchParams(req.query as Record<string, string>);
      if (!queryParams.has('api_key')) {
        queryParams.set('api_key', TMDB_API_KEY);
      }

      const targetUrl = `https://api.themoviedb.org/3/${endpoint}?${queryParams.toString()}`;
      const upstream = await fetch(targetUrl, {
        headers: { Accept: 'application/json' },
      });

      const data = await upstream.json();
      res.status(upstream.status).json(data);
    } catch (err: any) {
      res.status(500).json({ error: err.message || 'TMDB proxy error' });
    }
  });

  // 2. Image Proxy endpoint - serves movie posters/backdrops with high-speed caching & ISP unblocking
  app.get('/api/image-proxy', async (req, res) => {
    try {
      const targetUrl = req.query.url as string;
      if (!targetUrl || !targetUrl.startsWith('http')) {
        return res.status(400).send('Invalid url');
      }

      const upstream = await fetch(targetUrl, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        },
      });

      if (!upstream.ok) {
        return res.status(upstream.status).send('Failed to fetch image');
      }

      const contentType = upstream.headers.get('content-type') || 'image/jpeg';
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=86400, immutable');

      const arrayBuffer = await upstream.arrayBuffer();
      res.send(Buffer.from(arrayBuffer));
    } catch (err: any) {
      res.status(500).send('Image proxy error');
    }
  });

  // 3. Real Video Stream Downloader route with direct redirect to video stream
  app.get('/api/download', async (req, res) => {
    try {
      const targetUrl = req.query.url as string;
      if (!targetUrl || !targetUrl.startsWith('http')) {
        return res.status(400).send('Invalid url');
      }
      // Instant 302 redirect so browser native download manager handles it directly without hanging Node.js
      return res.redirect(302, targetUrl);
    } catch {
      res.status(500).json({ error: 'Download failed' });
    }
  });

  // 3. Vite development server middleware or production static files
  if (!isProduction) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running at http://0.0.0.0:${PORT}`);
  });
}

main().catch(console.error);
